public class TempConverter {
	public static void main (String [] args){
		double cel=25, fah;

		fah=(9.0/5) * cel + 32;

		System.out.println("Celsius: " + cel + ", fahrenheit: " + fah);

	}
}