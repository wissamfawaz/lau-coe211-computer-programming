import javax.swing.JOptionPane;

public class JOptionPaneDemo {
	public static void main(String[] args) {
		String num1AsString = JOptionPane.showInputDialog("Enter num1: ");
		String num2AsString = JOptionPane.showInputDialog("Enter num2: ");

		int sum = Integer.parseInt(num1AsString) + Integer.parseInt(num2AsString);

		JOptionPane.showMessageDialog(null, "The sum of the two value: " + sum);


	}
}