public class RunTimeErrorDemo {
	public static void main(String[] args) {
		// This implementation generates a run-time error: NumberFormatException
		double value = Double.parseDouble("23.5c");
		System.out.println(value);

	}
}