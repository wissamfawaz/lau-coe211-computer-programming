import java.util.Scanner;
import java.text.DecimalFormat;
public class Quadratic {
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		DecimalFormat fmt = new DecimalFormat("0.###");
		int a, b, c;
		double root1, root2;
		double delta;

		System.out.println("Enter a: ");
		a = scan.nextInt();
		System.out.println("Enter b: ");
		b = scan.nextInt();
		System.out.println("Enter c: ");
		c = scan.nextInt();

		delta = Math.pow(b, 2) - 4*a*c;
		root1 = (-b + Math.sqrt(delta)) / (2*a);
		root2 = (-b - Math.sqrt(delta)) / (2*a);
		
		String root1Formatted = fmt.format(root1);
		String root2Formatted = fmt.format(root2);
		double sumOfFormattedRoots = 
			Double.parseDouble(root1Formatted) + 
			Double.parseDouble(root2Formatted);

		System.out.println("Root1: " + root1Formatted);
		System.out.println("Root2: " + root2Formatted);
		System.out.println("Sum of formatted roots: " + sumOfFormattedRoots);	

	}
}