import java.util.Scanner;

public class GradeReport {
	public static void main(String[] args) {
		int grade;
		int category;
		Scanner scan = new Scanner(System.in);
	
		do {
			System.out.println("Enter a valid numeric grade: ");
			grade = scan.nextInt();
		} while(grade < 0 || grade > 100);

		/*if(grade == 100) {
			System.out.println("Excellent job!");
		} else if(grade >= 90 && grade < 100) { 
			System.out.println("Well above average");
		} else if(grade >= 80 && grade < 90) {
			System.out.println("Above average");
		} else if(grade >= 70 && grade < 80) {
			System.out.println("Average");
		} else if(grade >= 60 && grade < 70) {
			System.out.println("Below average");
		} else {
			System.out.println("Not passing");
		}*/


		category = grade / 10;

		switch(category) {
			case 10:
				System.out.println("Excellent!");
				break;
			case 9:
				System.out.println("Well above average");
				break;
			case 8:
				System.out.println("Above average");
				break;
			case 7:
				System.out.println("Average");
				break;
			case 6:
				System.out.println("Below average");
				break;
			default:
				System.out.println("Not passing!");
		}

	}
}