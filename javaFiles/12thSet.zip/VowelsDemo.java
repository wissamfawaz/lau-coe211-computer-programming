import java.util.Scanner;

public class VowelsDemo {
	public static void main(String[] args) {
		String line;
		String vowels = "aeouiAEOUI";
		char initial;
		Scanner scan = new Scanner(System.in);

		System.out.println("Enter a line of text: ");
		line = scan.nextLine();

		initial = line.charAt(0);

		//if(initial == 'a' || initial == 'e' || initial == 'i' ...)		
		if(vowels.contains(initial + "")) {
			System.out.println(line + " begins with a vowel.");
		} else {
			System.out.println(line + " does not begin with a vowel");
		}		
	}
}