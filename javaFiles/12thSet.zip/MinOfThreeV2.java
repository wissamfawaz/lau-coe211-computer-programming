import java.util.Scanner;

public class MinOfThreeV2 {
	public static void main(String[] args) {
		int num1, num2, num3;
		int min;
		Scanner scan = new Scanner(System.in);

		System.out.println("Enter num1: ");
		num1 = scan.nextInt();

		System.out.println("Enter num2: ");
		num2 = scan.nextInt();
		
		System.out.println("Enter num3: ");
		num3 = scan.nextInt();
		
		if(num1 < num2) 
			if(num1 < num3) 
				min = num1;
			else // num1 >= num3
				min = num3;
		else // num2 <= num1
			if(num2 < num3) 
				min = num2;
			else // num3 <= num2
				min = num3;
		
		System.out.println("Min: " + min);


	}
}