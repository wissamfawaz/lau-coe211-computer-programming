public class WhileDemo {
	public static void main(String[] args) {
		int counter = 1;

		while(counter <= 100) {
			/*if(counter % 2 == 1) {
				System.out.println(counter);
			}*/
			System.out.println(counter);
			counter+=2;
		}



	}

}