public class Main {
	public static void main(String[] args) {
		Dictionary webster = new Dictionary(1500, 52500);

		System.out.println("Nb. of pages: " + webster.getPages());
		System.out.println("Nb. of definitions: " + webster.getDefinitions());
		System.out.println("Nb. of definitions per page: " + webster.defsPerPage());

	}
}