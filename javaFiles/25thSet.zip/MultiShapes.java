public class MultiShapes {

	public static void main(String[] args) {
		Triangle t = new Triangle();
		Circle c = new Circle();
		Rectangle r = new Rectangle();

		t.draw();
		c.draw();
		r.draw();
	}
}