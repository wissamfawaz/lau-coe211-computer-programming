public class Rectangle extends Shape {
	public void draw() {
		System.out.println("Rectangle draw.");
	}

}