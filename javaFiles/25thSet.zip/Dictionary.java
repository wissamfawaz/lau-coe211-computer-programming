public class Dictionary extends Book {
	//int definitions = 52500;
	private int definitions;

	public Dictionary(int pages, int definitions) {
		super(pages);
		this.definitions = definitions;
	}

	public double defsPerPage() {
		return (double) definitions / pages;
	}

	public int getDefinitions() {
		return definitions;
	}

	public void setDefinitions(int definitions) {
		this.definitions = definitions;
	}
}