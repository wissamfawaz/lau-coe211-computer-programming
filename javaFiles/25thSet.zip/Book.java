public class Book {
	// protected int pages = 1500;
	protected int pages;

	public Book(int pages) {
		this.pages = pages;
	}

	public int getPages() {
		return pages;
	}

	public void setPages(int pages) {
		this.pages = pages;
	}
}