public class SecondSmallestValue {
	public static void main(String[] args) {
		int[] array = {2, 1, 4, 3};

		int secondSmallestValue = get2ndSmallestValue(array);

		if(secondSmallestValue != Integer.MAX_VALUE) 
			System.out.println("Second smallest value: " + secondSmallestValue);
		else
			System.out.println("Could not find second smallest value!");

	}

	private static int get2ndSmallestValue(int[] array) {
		int smallestValue = Integer.MAX_VALUE, secondSmallestValue = Integer.MAX_VALUE;

		for(int val : array) {
			if(val < smallestValue) {
				secondSmallestValue = smallestValue;
				smallestValue = val;
			} else if(val < secondSmallestValue && val != smallestValue) {
				secondSmallestValue = val;
			}
		}
	
		return secondSmallestValue;
	} 

}