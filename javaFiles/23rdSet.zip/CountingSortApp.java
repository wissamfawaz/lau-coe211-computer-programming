import java.util.Arrays;
public class CountingSortApp {
	public static void main(String[] args) {
		int[] array = {1, 2, 1, 2, 4, 3};

		System.out.println("Before: " + Arrays.toString(array));
		int[] sortedArray = countSort(array);
		System.out.println("After: " + Arrays.toString(sortedArray));		
	}

	private static int[] countSort(int[] array) {
		// Handle the edge cases
		if(array == null || array.length == 0) {
			return new int[] {};
		}


		// Preprocessing step#1: find the max in array
		// int max = Collections.max(Arrays.asList(array));
		int max = findMax(array);

		// Preprocessing step#2: do the counting
		int[] counts = new int[max + 1];
		for(int val : array) {
			counts[val]++;
		}		

		for(int idx = 1; idx < counts.length; idx++) {
			counts[idx] = counts[idx] + counts[idx-1];
		}

		// Do the sorting
		int[] sortedArray = new int[array.length];
		int current, sortedArrayIdx;

		for(int idx = array.length - 1; idx >= 0; idx--) {
			current = array[idx];
			counts[current]--;
			sortedArrayIdx = counts[current];
			sortedArray[sortedArrayIdx] = current;

		}

		return sortedArray;


	}

	private static int findMax(int[] array) {
		int max = Integer.MIN_VALUE;

		for(int val : array) {
			if(val > max) {
				max = val;
			}
		}

		return max;
	} 

	
}