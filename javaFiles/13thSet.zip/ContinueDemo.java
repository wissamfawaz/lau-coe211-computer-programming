public class ContinueDemo {
	public static void main(String[] args) {
		int counter = 1;

		while(counter <= 10) {
			if(counter == 5 || counter == 7) {
				counter++;
				continue;
			}
			System.out.println(counter);
			counter++;
		}


	}
}