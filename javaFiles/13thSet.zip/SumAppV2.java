import java.util.Scanner;

public class SumAppV2 {
	public static void main(String[] args) {
		int sum = 0, counter = 0;
		Scanner scan = new Scanner(System.in);
		int num;

		System.out.println("Enter num (0 to quit): ");
		num = scan.nextInt();

		while(num != 0) {
			sum+=num;
			counter++;
			System.out.println("Enter num (0 to quit): ");
			num = scan.nextInt();
		}

		if(counter != 0) {
			double avg = (double) sum / counter;
			System.out.println("Avg: " + avg);
		} else {
			System.out.println("You did not enter any value!");
		}
	}
}