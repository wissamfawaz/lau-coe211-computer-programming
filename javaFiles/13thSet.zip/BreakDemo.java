public class BreakDemo {
	public static void main(String[] args) {
		int counter = 1;

		while(true) {
			if(counter > 5) break;
			System.out.println(counter);
			counter++;
		}



	}
}