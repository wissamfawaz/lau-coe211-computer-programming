import java.util.Scanner;

public class ReverseNumber {
	public static void main(String[] args) {
		int val, reverse = 0, rightMostDigit;
		Scanner scan = new Scanner(System.in);

		System.out.println("Enter a number to reverse: ");
		val = scan.nextInt();

		do {
			rightMostDigit = val % 10;
			reverse = reverse * 10 + rightMostDigit;			
			val = val / 10;
		} while(val != 0);

		System.out.println("That number reversed: " + reverse);
	}
}