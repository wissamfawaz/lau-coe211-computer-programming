import java.util.Scanner;

public class SumAppV1 {
	public static void main(String[] args) {
		int num, sum = 0;
		int counter = 1;
		final int COUNT;
		Scanner scan = new Scanner(System.in);

		System.out.println("How many values do you wish to enter?");
		COUNT = scan.nextInt();

		while(counter <= COUNT) {
			System.out.println("Enter num: ");
			num = scan.nextInt();
			sum += num;
			counter++;
		}

		System.out.println("Sum: " + sum);		

	}
}