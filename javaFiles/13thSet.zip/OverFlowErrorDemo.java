public class OverFlowErrorDemo {
	public static void main(String[] args) {
		int counter = 1000000;

		while(counter >= 0) {
			counter += 100000000;
			System.out.println(counter);
		}

	}
}