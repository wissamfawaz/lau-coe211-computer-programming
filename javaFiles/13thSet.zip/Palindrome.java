import java.util.Scanner;

public class Palindrome {
	public static void main(String[] args) {
		String original, reverse = "";
		Scanner scan = new Scanner(System.in);

		System.out.println("Enter string to validate: ");
		original = scan.nextLine();

		int idx = original.length() - 1;

		while(idx >= 0) {
			reverse += original.charAt(idx);
			idx--;
		}

		if(reverse.equalsIgnoreCase(original)) {
			System.out.println("Input is a palindrome");
		} else {
			System.out.println("Input is not a palindrome");
		}

	}
}