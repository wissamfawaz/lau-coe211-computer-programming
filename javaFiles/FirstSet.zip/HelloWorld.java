/* This code demonstrates
 the basic structure of a Java program
*/

public class HelloWorld {
	public static void main(String[] args) {
		System.out.print("Hello ");
		System.out.println("World!"); 
	}
}