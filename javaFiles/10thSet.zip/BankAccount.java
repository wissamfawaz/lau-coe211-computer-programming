public class BankAccount {
	private double balance;
	private String owner;
	private int acctNb;
	private final double RATE;

	public BankAccount(String owner, double balance, int acctNb) {
		this.owner = owner;
		this.balance = balance;
		this.acctNb = acctNb;
		RATE = 0.05;
	} 	

	public double getBalance() {
		return balance;
	}

	public String getOwner() {
		return owner;
	}

	public void setOwner(String owner) {
		this.owner = owner;
	}

	public void setAcctNb(int nb) {
		acctNb = nb;
	}

	public void deposit(double amount) {
		balance += amount;
	}

	public void withdraw(double amount) {
		balance -= amount;
	}

	public void addInterest() {
		double interest = RATE * balance;
		balance += interest;
	}

	public String toString() {
		String output = "Owner: " + owner + "\n" + 
		"Balance: " + balance + "\n" + 
		"Account nb: " + acctNb;
		return output;
	}







	
}