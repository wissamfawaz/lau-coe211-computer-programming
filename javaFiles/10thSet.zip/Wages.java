import java.util.Scanner;

public class Wages {
	public static void main(String[] args) {
		int hrs;
		Scanner scan = new Scanner(System.in);
		final double HOURLY = 8.25;
		double wages;

		System.out.println("Enter nb of hours worked: ");
		hrs = scan.nextInt();

		if(hrs <= 40) {
			wages = hrs * HOURLY;
		} else {
			wages = 40 * HOURLY + (hrs - 40) * HOURLY * 1.5;
		}

		System.out.println("Wages: " + wages);
	}
}