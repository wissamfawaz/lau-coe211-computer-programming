public class LoopDemo {
	public static void main(String[] args) {
		int counter = 1;

		while(counter <= 5) {
			System.out.println(counter);
			counter++;
		}
		
		System.out.println(counter); // 6

	}
}