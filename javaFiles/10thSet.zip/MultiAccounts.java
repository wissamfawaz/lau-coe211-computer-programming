public class MultiAccounts {
	public static void main(String[] args) {
		BankAccount momAccount = new BankAccount("Mona", 1000.0, 1234);
		BankAccount wifeAccount = new BankAccount("Leila", 200.0, 2345);

		momAccount.deposit(100);
		momAccount.withdraw(500);
		momAccount.addInterest();

		wifeAccount.deposit(400);
		wifeAccount.withdraw(500);
		wifeAccount.addInterest();


		System.out.println("Mom's account: ");
		System.out.println(momAccount);		
		System.out.println("-------------------------------------------------");
		System.out.println("Wife's account: ");
		System.out.println(wifeAccount);


	} 
}