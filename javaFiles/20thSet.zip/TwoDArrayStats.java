public class TwoDArrayStats {
	public static void main(String[] args) {
		int[][] mat = {
			{0, 1, 2},
			{10, 11, 12},
			{20, 21, 22}
		};
		final int ROWS = mat.length, COLS = mat[0].length;
		double[] rowAvgs = new double[ROWS], colAvgs = new double[COLS];

		// Calculate the row sums
		for(int row = 0; row < ROWS; row++) {
			for(int col = 0; col < COLS; col++) {
				rowAvgs[row] += mat[row][col];
			}
		}

		// Calcuate the column sums
		for(int col = 0; col < COLS; col++) {
			for(int row = 0; row < ROWS; row++) {
				colAvgs[col] += mat[row][col];
			}
		}
	
		// Find the row averages
		for(int row = 0; row < ROWS; row++) {
			rowAvgs[row] /= COLS;
			System.out.println("Row#" + (row + 1) + ": " + rowAvgs[row]);
		}
		
		// Find the column averages
		for(int col = 0; col < COLS; col++) {
			colAvgs[col] /= ROWS;
			System.out.println("Col#" + (col + 1) + ": " + colAvgs[col]); 
		}



	}
}