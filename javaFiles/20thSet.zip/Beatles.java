import java.util.ArrayList;

public class Beatles {
	public static void main(String[] args) {
		ArrayList<String> band = new ArrayList<>();
		System.out.println("Initial size: " + band.size());

		band.add("John");
		band.add("Pete");
		band.add("Georges");
		band.add("Paul");

		System.out.println(band);

		int location = band.indexOf("Pete");
		band.remove(location);
		System.out.println("After removal of Pete: " + band);



	}
} 