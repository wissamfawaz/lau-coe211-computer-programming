public class ConcatenationDemo {
	public static void main(String[] args) {
		System.out.println("Whatever you are," + " be a good one");

	}
}