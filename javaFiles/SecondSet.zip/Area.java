public class Area {
	public static void main(String[] args) {
		// Section1: Create the variables
		double radius = 5.0, area;
		final double PI = 3.14;

		// Section2: Business logic
		area = PI * radius * radius;

		// Section3: Produce out
		System.out.println("Radius: " + radius + ", area: " + area);

	}
}