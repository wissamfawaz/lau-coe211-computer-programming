public class Volume {
	public static void main(String[] args) {
		// 1st Section: Create the variables
		double radius = 5.0, volume; 
		final double PI = 3.14;

		// 2nd Section: Business logic
		volume = (4.0 / 3.0) * PI * radius * radius * radius;		

		// 3rd Section
		System.out.println("Radius: " + radius + ", volume: " + volume);

	}
}