public class FloatDemo {
	// KISS: Keep It Silly Simple
	public static void main(String[] args) {
		float val = 45.6F;
		
		System.out.println(val);

	}
}