import java.util.Scanner;
import java.io.File; 
import java.io.IOException;
import java.util.StringTokenizer;
public class URLDissector {
	public static void main(String[] args) throws IOException {
		Scanner fileScan = new Scanner(new File("urls.inp"));
		Scanner urlScan;
		String url;
		StringTokenizer st;
		while(fileScan.hasNext()) {
			url = fileScan.next(); // fileScan.nextLine()
			System.out.println(url);
			/*
			urlScan = new Scanner(url);
			urlScan.useDelimiter("/");
			while(urlScan.hasNext()) {
				System.out.println(urlScan.next());
			} 
			*/

			st = new StringTokenizer(url, "/");			

			while(st.hasMoreTokens()) {
				System.out.println(st.nextToken());
			}



		}


	}
}