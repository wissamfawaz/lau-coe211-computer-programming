import java.io.FileWriter;
import java.io.BufferedWriter;
import java.io.PrintWriter;
import java.util.Random;
import java.io.IOException;
public class LottoGrids {
	public static void main(String[] args) throws IOException {
		String fileName = "lotto.txt";
		Random rnd = new Random();
		FileWriter fw = new FileWriter(fileName);
		BufferedWriter bw = new BufferedWriter(fw);
		PrintWriter outToFile = new PrintWriter(bw);
		int rndValue;

		for(int row = 1; row <= 6; row++) {
			for(int col = 1; col <= 6; col++) {
				rndValue = rnd.nextInt(42) + 1;
				outToFile.print(rndValue + " ");
			}

			outToFile.println();
		}

		outToFile.close();


	}

}