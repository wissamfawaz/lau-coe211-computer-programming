import java.util.Scanner;

public class PrimeApp {
	public static void main(String[] args) {
		int num;
		Scanner scan = new Scanner(System.in);

		System.out.println("Enter an int: ");
		num = scan.nextInt();

		if(isPrime2(num)) {
			System.out.println("Input value is prime");
		} else {
			System.out.println("Input value is not prime");
		}
	}

	private static boolean isPrime1(int num) {
		if(num <= 1) {
			return false;
		}
		int counter = 0;
		for(int divisor = 1; divisor <= num; divisor++) {
			if(num % divisor == 0) counter++;

		}

		/*if(counter == 2) return true;
		else return false;*/

		return counter == 2;

	}

	private static boolean isPrime2(int num) {
		if(num <= 1) return false;

		for(int divisor = 2; divisor <= num/2; divisor++) {
			if(num % divisor == 0) return false;

		}

		return true;
	}





}