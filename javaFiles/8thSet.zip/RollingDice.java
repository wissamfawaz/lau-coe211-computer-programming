public class RollingDice {
	public static void main(String[] args) {
		Die die1 = new Die();
		Die die2 = new Die();

		System.out.println("Die1: " + die1);
		System.out.println("Die2: " + die2);

		die1.roll();
		die2.roll();

		System.out.println("Die1: " + die1.getFaceValue());
		System.out.println("Die2: " + die2.getFaceValue());

		die1.setFaceValue(6);
		die2.setFaceValue(6);

		System.out.println("Die1: " + die1.getFaceValue());
		System.out.println("Die2: " + die2.getFaceValue());


	}
}