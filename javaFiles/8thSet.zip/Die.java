public class Die {
	// State
	int faceValue;

	// Behavior
	Die() {
		faceValue = 5;
	}

	int getFaceValue() {
		return faceValue;
	}

	void setFaceValue(int val) {
		faceValue = val;
	}

	void roll() {
		faceValue = (int) (Math.random()*6 + 1);
	}

	public String toString() {
		return Integer.toString(faceValue);

	}


}