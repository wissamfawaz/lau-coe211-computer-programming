import java.util.Scanner;
import java.io.File;
import java.io.IOException;
public class URLDissector {
	public static void main(String[] args) throws IOException {
		Scanner fileScan = new Scanner(new File("urls.inp"));
		
		while(fileScan.hasNext()) {
			System.out.println(fileScan.nextLine());
		}

	}
}