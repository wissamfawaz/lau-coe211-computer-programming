public class Triangle {
	public static void main(String[] args) {
		final int ROWS = 4;

		for(int row = 1; row <= ROWS; row++) {
			for(int col = 1; col <= row; col++) {
				System.out.print("*");
			}
			System.out.println();
		}


	}
}