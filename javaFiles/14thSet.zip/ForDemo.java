// Print values from 20 to 1
public class ForDemo {
	public static void main(String[] args) {
		int counter = 20;
		for(; counter >= 1; ) {
			System.out.println(counter);
			counter--;
		}
		// System.out.println(counter);
	}
}