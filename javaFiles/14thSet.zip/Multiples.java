import java.util.Scanner;

public class Multiples {
	public static void main(String[] args) {
		int value, upper, counter = 0;
		final int PERLINE = 4;	
		Scanner scan = new Scanner(System.in);

		System.out.println("Enter an int value: ");
		value = scan.nextInt();
		System.out.println("Enter an upper bound: ");
		upper = scan.nextInt();

		for(int mult = value; mult <= upper; mult += value) {
			System.out.print(mult + " ");
			counter++;
			if(counter % PERLINE == 0) {
				System.out.println();
			}
		}		


	}
}