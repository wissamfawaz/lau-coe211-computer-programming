import java.util.Scanner;
import java.util.Arrays;
public class SearchingApp {
	public static void main(String[] args) {
		int[] pool = {1, 7, 9, 13, 24, 45, 67};
		Scanner scan = new Scanner(System.in);
		int target;

		System.out.println("Enter a target value: ");
		target = scan.nextInt();

		if(binarySearch(pool, target)) {
			System.out.println(target + " found");
		} else {
			System.out.println(target + " not found!");
		}

		if(Arrays.binarySearch(pool, target) >= 0) {
			System.out.println(target + " found");
		} else {
			System.out.println(target + " not found!");
		}
		
	}

	private static boolean binarySearch(int[] pool, int target) {
		boolean found = false;
		int left = 0, right = pool.length - 1;
		int middle;
		while(!found && left <= right) {
			middle = left + (right - left) / 2;

			if(pool[middle] == target) {
				found = true;
			} else if(pool[middle] < target) {
				left = middle + 1;
			} else {
				right = middle - 1;
			}
		}

		return found;
	}
}