import java.util.Scanner;
import java.util.Arrays;

public class BinarySearchDemo {
	public static void main(String[] args) {
		int target;
		Scanner scan = new Scanner(System.in);
		int[] pool = {1, 7, 9, 24, 36, 47};

		System.out.println("Enter a target value: ");
		target = scan.nextInt();

		if(Arrays.binarySearch(pool, target) >= 0) {
			System.out.println(target + " found");
		} else {
			System.out.println(target + " not found!");
		}



	}


}