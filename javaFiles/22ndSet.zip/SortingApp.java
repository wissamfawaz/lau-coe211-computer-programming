import java.util.Arrays;
public class SortingApp {
	public static void main(String[] args) {
		int[] array = {2, 10, 5, 6, 1};
		
		//System.out.println("Before: " + Arrays.toString(array));
		//selectionSort(array);
		//System.out.println("After: " + Arrays.toString(array));

		System.out.println("Before: " + Arrays.toString(array));
		insertionSort(array);
		System.out.println("After: " + Arrays.toString(array));
		
	}

	private static void selectionSort(int[] array) {
		int idxMinVal;
		for(int idx = 0; idx < array.length-1; idx++) { 
			idxMinVal = idx;
			for(int scan = idx + 1; scan < array.length; scan++) {
				if(array[scan] < array[idxMinVal]) {
					idxMinVal = scan;
				}
			}

			swap(array, idx, idxMinVal);
		}
	}

	private static void insertionSort(int[] array) {
		int n = array.length;
		int scan;
		for(int idx = 1; idx < n; idx++) {
			scan = idx;

			while(scan > 0 && array[scan] < array[scan-1]) {
				swap(array, scan, scan-1);
				scan--;
			}
		}
	}

	private static void swap(int[] array, int idx1, int idx2) {
		int temp = array[idx1];
		array[idx1] = array[idx2];
		array[idx2] = temp;

	}


}