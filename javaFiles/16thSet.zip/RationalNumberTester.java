public class RationalNumberTester {
	public static void main(String[] args) {
		RationalNumber r1 = new RationalNumber(1, 4);
		RationalNumber r2 = new RationalNumber(1, 2);

		RationalNumber sum = r1.add(r2);
		RationalNumber product = r1.multiply(r2);
		RationalNumber ratio = r1.divide(r2);
		RationalNumber difference = r1.subtract(r2);

		System.out.println("Sum: " + sum);
		System.out.println("Product: " + product);
		System.out.println("Ratio: " + ratio);
		System.out.println("Difference: " + difference);

	}
}