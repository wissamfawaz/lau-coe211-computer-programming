public class MultiSlogans {
	public static void main(String[] args) {

		Slogan slg1 = new Slogan("Talk is cheap"); // count: 3
		Slogan slg2 = new Slogan("Live free or die"); 
		Slogan slg3 = new Slogan("Just do it");

		System.out.println("Slogans count: " + Slogan.getCount());


	}
}