public class Slogan {
	private String phrase;
	private static int count=0;

	public Slogan(String phrase) {
		this.phrase = phrase;
		count++;		
	} 

	public static int getCount() {
		return phrase.length();
	}

	public String toString() {
		return phrase;
	}
}