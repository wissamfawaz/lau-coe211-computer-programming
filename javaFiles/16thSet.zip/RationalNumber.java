public class RationalNumber {
	private int numerator;
	private int denominator;

	public RationalNumber(int num, int denom) {
		if(denom == 0) denom = 1;

		if(denom < 0) {
			num *= -1;
			denom *= -1;
		}

		numerator = num;
		denominator = denom;	

		reduce();	
	}

	public int getNumerator() {
		return numerator;
	}

	public int getDenominator() {
		return denominator;
	}

	public RationalNumber add(RationalNumber op2) {
		int common= denominator * op2.getDenominator();
		int sum = numerator * op2.getDenominator() + op2.getNumerator() * denominator;
		
		return new RationalNumber(sum, common);
	}

	public RationalNumber subtract(RationalNumber op2) {
		int common= denominator * op2.getDenominator();
		int difference = numerator * op2.getDenominator() - op2.getNumerator() * denominator;
		
		return new RationalNumber(difference, common);
	}

	public RationalNumber multiply(RationalNumber op2) {
		int common= denominator * op2.getDenominator();
		int product = numerator * op2.getNumerator();
		
		return new RationalNumber(product, common);
	}

	public RationalNumber divide(RationalNumber op2) {
		int common= denominator * op2.getNumerator();
		int product = numerator * op2.getDenominator();
		
		return new RationalNumber(product, common);
	}

	public String toString() {
		if(numerator == 0) {
			return "0";
		} else if(denominator == 1) {
			return Integer.toString(numerator);
		} else {
			return numerator + "/" + denominator;
		}
	}	


	private void reduce() {
		if(numerator != 0) {	
			int gcd = gcd(Math.abs(numerator), denominator);	
			numerator /= gcd;
			denominator /= gcd;
		}
	}

	private int gcd(int num1, int num2) {
		while(num1 != num2) {
			if(num1 > num2) {
				num1 = num1 - num2;
			} else {
				num2 = num2 - num1;
			}
		}
		return num1;


	}











}