import java.util.Scanner;

public class Frequencies{
	public static void main(String[] args){
		int[] lower =new int[26];
		int[] upper = new int[26];
		int other = 0;
		String line;
		char current;
		Scanner scan = new Scanner(System.in);

		System.out.println("Enter a line of text: ");
		line = scan.nextLine();

		for(int idx = 0; idx < line.length(); idx++) {
			current = line.charAt(idx);
			if(current >= 'a' && current <= 'z') {
				lower[current-'a']++;
			} else if(current >= 'A' && current <= 'Z') {
				upper[current - 'A']++;
			} else {
				other++;
			}
		}		

		for(int rowIdx = 0; rowIdx < lower.length; rowIdx++) {
			System.out.print((char) (rowIdx + 'a'));
			System.out.print(": " + lower[rowIdx] + "\t");
			System.out.print((char) (rowIdx + 'A'));
			System.out.println(": " + upper[rowIdx]);
		}

		System.out.println("Nb of non-alphabetic characters: " + other);
	}
}