public class ArrayDemo {
	public static void main(String[] args) {
		int[] arr = new int[10];

		// Populate the array
		for(int idx = 0; idx < arr.length; idx++) {
			arr[idx] = idx * 10;
		} 

		// Produce an output 
		for(int idx = 0; idx < arr.length; idx++) {
			System.out.print(arr[idx] + " ");
		} 

		/*for(int value : arr) {
			System.out.print(value + " ");
		}*/
	}
}