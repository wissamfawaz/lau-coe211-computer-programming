import java.util.Scanner;

public class Reverse{
	public static void main(String[] args){

		int count;
		Scanner scan=new Scanner(System.in);
		int[] arr;

		System.out.println("Enter the number of values:");
		count=scan.nextInt();

		arr=new int[count];


		for(int idx=0; idx<arr.length; idx++){
			System.out.println("Enter an int:");
			arr[idx]=scan.nextInt();
		}

		System.out.println("These values in reverse order: ");
		for(int idx=arr.length -1; idx >= 0; idx--){
			System.out.println(arr[idx]);
		}








	}
}