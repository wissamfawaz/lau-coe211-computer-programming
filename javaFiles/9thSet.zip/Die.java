public class Die {
	private int faceValue;

	public Die(int faceValue) {
		this.faceValue = faceValue; // this.faceValue is the instance variable
	}

	public int getFaceValue() {
		return faceValue;
	}

	public void setFaceValue(int val) {
		faceValue = val;
	}

	public void roll() {
		faceValue = getRndValue();
	}

	private int getRndValue() {
		return (int) (Math.random() * 6 + 1);
	}


	public String toString() {
		return Integer.toString(faceValue);
	}
}