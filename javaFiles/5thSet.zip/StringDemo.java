public class StringDemo {
	public static void main(String[] args) {
		String first = "Wissam", last = new String("Fawaz");

		int len = first.length();
		System.out.println("Length of first name: " + len);

		// String full = first + " " + last;
		String full = first.concat(" ").concat(last);
		System.out.println("Full name: " + full);
		
		char initialFirst = first.charAt(0);
		char lastCharLast = last.charAt(last.length()-1);

		String combination = "" + initialFirst + lastCharLast;
		System.out.println("After combining first and last chars: " + combination);

		String firstCapitalized = first.toUpperCase();
		System.out.println("First name capitalized: " + firstCapitalized);

		boolean areEqual = first.equals(firstCapitalized);
		System.out.println("Are equal? " + areEqual);

		areEqual = first.equalsIgnoreCase(firstCapitalized);
		System.out.println("Are equal? " + areEqual);

		/*String firstExtracted = full.substring(0, 6);
		System.out.println("First name extracted: " + firstExtracted);*/

		int idxOfSpace = full.indexOf(' ');
		String firstExtracted = full.substring(0, idxOfSpace);
		//String lastExtracted = full.substring(idxOfSpace + 1, full.length());
		String lastExtracted = full.substring(idxOfSpace + 1);
		System.out.println("First name extracted: " + firstExtracted);
		System.out.println("Last name extracted: " + lastExtracted);
		




				

	}
}