import java.util.Scanner;

public class MinOfThree {
	public static void main(String[] args) {
		int value;
		int min = Integer.MAX_VALUE;
		Scanner scan = new Scanner(System.in);

		System.out.println("Enter first value: ");
		value = scan.nextInt();
		
		if(value < min) 
			min = value;

		System.out.println("Enter second value: ");
		value = scan.nextInt();
		
		if(value < min) 
			min = value;
		
		System.out.println("Enter third value: ");
		value = scan.nextInt();
		
		if(value < min) 
			min = value;
		
		
		System.out.println("Min: " + min);
	}

}