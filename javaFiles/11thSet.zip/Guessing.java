import java.util.Scanner;

public class Guessing {
	public static void main(String[] args) {
		int guess, answer;
		final int MIN = 1, MAX = 10;
		Scanner scan = new Scanner(System.in);

		answer = (int) (Math.random() * (MAX - MIN + 1) + MIN);

		System.out.println("I am thinking of a value between "  + MIN + 
			" and " + MAX + ", guess what it is: ");
		guess = scan.nextInt();

		if(guess == answer) {
			System.out.println("You got it! Good guessing!");
		} else {
			System.out.println("That is not correct, sorry!");
			System.out.println("The number was " + answer);
		}		
	}
}