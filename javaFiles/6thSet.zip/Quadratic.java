import java.util.Scanner;
public class Quadratic {
	public static void main(String[] args) {
		int a, b, c;
		Scanner scan = new Scanner(System.in);
		double root1, root2;

		System.out.println("Enter a: ");
		a = scan.nextInt();
		System.out.println("Enter b: ");
		b = scan.nextInt();
		System.out.println("Enter c: ");
		c = scan.nextInt();

		root1 = (-b + Math.sqrt(Math.pow(b, 2) - 4*a*c)) / (2*a);
		root2 = (-b - Math.sqrt(Math.pow(b, 2) - 4*a*c)) / (2*a);

		System.out.println("Root1: " + root1);
		System.out.println("Root2: " + root2);
	}
}