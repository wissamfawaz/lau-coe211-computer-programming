import java.util.Random;

public class RandomDemo {
	public static void main(String[] args) {
		int rndNum1, rndNum2;
		Random rnd = new Random();

		rndNum1 = rnd.nextInt(6) + 1;
		//rndNum2 = rnd.nextInt(6) + 1;
		rndNum2 = (int) (rnd.nextFloat() * 6 + 1);

		System.out.println("Die#1: " + rndNum1);
		System.out.println("Die#2: " + rndNum2);

	

	}
}