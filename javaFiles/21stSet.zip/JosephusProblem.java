import java.util.ArrayList;
import java.util.Scanner;

public class JosephusProblem {
	public static void main(String[] args) {
		String[] players = {"Kris", "Joseph", "Tania"};
		int k;
		Scanner scan = new Scanner(System.in);

		System.out.println("Enter k: ");
		k = scan.nextInt();

		String winner = solve(players, k);
		if(winner != null) 
			System.out.println("Winner: " + winner);
		else
			System.out.println("Game did not converge!");
	}

	private static String solve(String[] players, int k) {
		ArrayList<String> playersList = new ArrayList<>();
		String winner = null;
		for(int idx = 0; idx < players.length; idx++) {
			playersList.add(players[idx]);
		}

		while(playersList.size() > 1) {
			System.out.println("Active players: " + playersList);

			for(int count = 1; count <= k; count++) {
				playersList.add(playersList.remove(0));
			}

			System.out.println(playersList.remove(0) + " is out");
		}
		if(playersList.size() == 1) 
			winner = playersList.get(0);
		
		return winner;

	}


}