import java.util.ArrayList;

public class Beatles {
	public static void main(String[] args) {
		ArrayList<String> band = new ArrayList<>();

		System.out.println("Is list empty? " + band.isEmpty());
		System.out.println("Size of the list: " + band.size());

		band.add("John");
		band.add("Pete");
		band.add("Georges");
		band.add("Paul");

		System.out.println("Band: " + band);

		int location = band.indexOf("Pete");
		band.remove(location);

		System.out.println("After removal: " + band);

		band.add(location, "Ringo");
		System.out.println("After adding Ringo: " + band);
		 

	}
}