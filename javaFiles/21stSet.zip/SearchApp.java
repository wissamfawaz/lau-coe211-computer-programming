import java.util.Scanner;

public class SearchApp {
	public static void main(String[] args) {
		int[] pool = {4, 15, 23, 35, 46};
		int target;
		Scanner scan = new Scanner(System.in);

		System.out.println("Enter a target value: ");
		target = scan.nextInt();

		if(linearSearch(pool, target)) {
			System.out.println(target + " found linearly");
		} else {
			System.out.println(target + " not found linearly");
		}

		if(binarySearch(pool, target)) {
			System.out.println(target + " found using binary search");
		} else {
			System.out.println(target + " not found using binary search");
		}
	}

	private static boolean linearSearch(int[] pool, int target) {
		boolean found = false;
		int idx = 0;

		while(!found && idx < pool.length) {	
			if(pool[idx] == target) {
				found = true;
			} else {
				idx++;
			}
		}


		return found;
	}

	private static boolean binarySearch(int[] pool, int target) {
		boolean found = false;
		int left = 0, right = pool.length - 1;
		int middle;

		while(!found && left <= right) {
			middle = left + (right - left) / 2;

			if(pool[middle] == target) {
				found = true;
			} else if(pool[middle] < target) {
				left = middle + 1;
			} else {
				right = middle - 1;
			}
		}

		return found;

	}






}