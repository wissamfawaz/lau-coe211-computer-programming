import java.util.Scanner;
public class PigLatinTranslatorDriver {
	public static void main(String[] args) {
		String phrase;
		String phraseInPigLatin;
		Scanner scan = new Scanner(System.in);		

		System.out.println("Enter an English phrase: ");
		phrase = scan.nextLine();

		phraseInPigLatin = PigLatinTranslator.translate(phrase);
					
		System.out.println("That phrase in Pig Latin: " + phraseInPigLatin);

	}

}