import java.util.Scanner;
public class Quiz {
	public static void main(String[] args) {
		String potential;
		Scanner scan = new Scanner(System.in);
		Question question1 = new Question("What is the capital of Jamaica?", "Kingston");
		question1.setComplexity(10);
		Question question2 = new Question("What is the capital of Australia?", "Canberra");
		question2.setComplexity(8);

		System.out.println(question1.getPrompt() + " (" + question1.getComplexity() + ")");
		potential = scan.nextLine();

		if(question1.isAnswerCorrect(potential)) {
			System.out.println("Answer is correct!");
		} else {
			System.out.println("Answer is not correct!");
			System.out.println(question1);
		}

		System.out.println(question2.getPrompt() + " (" + question2.getComplexity() + ")");
		potential = scan.nextLine();

		if(question2.isAnswerCorrect(potential)) {
			System.out.println("Answer is correct!");
		} else {
			System.out.println("Answer is not correct!");
			System.out.println(question2);
		}



	}
}