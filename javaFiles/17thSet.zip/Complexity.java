public interface Complexity {
	public void setComplexity(int level);
	public int getComplexity();
}