public class Question implements Complexity {
	private String prompt, answer;
	private int complexity;

	public Question(String prompt, String answer) {
		this.prompt = prompt;
		this.answer = answer;
		complexity = 1;
	}

	public int getComplexity() {
		return complexity;
	}

	public void setComplexity(int level) {
		complexity = level;
	}

	public String getPrompt() {
		return prompt;
	}

	public String getAnswer() {
		return answer;	
	}

	public boolean isAnswerCorrect(String potential) {
		return potential.equalsIgnoreCase(answer);
	}

	public String toString() {
		return "Question: " + prompt + "\n" +
			"Correct answer: " + answer + "\n" + 
			"Complexity level: " + complexity;

	}


}