import java.util.StringTokenizer;

public class PigLatinTranslator {
	public static String translate(String phrase) {
		String output = "";
		StringTokenizer st = new StringTokenizer(phrase);

		while(st.hasMoreTokens()) {
			output += translateWord(st.nextToken()) + " ";
		}
		
		return output;
	}

	private static String translateWord(String word) {
		String output;
		
		if(beginsWithVowel(word)) {
			output = word + "yay";
		} else {
			output = word.substring(1) + word.charAt(0) + "ay";
		}


		return output;
	}

	private static boolean beginsWithVowel(String word) {
		String vowels = "aeouiAEOUI";

		return vowels.indexOf(word.charAt(0)) != -1;


	} 




}