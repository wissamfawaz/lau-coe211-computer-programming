public class Int {
	private int val;

	public Int(int val) {
		this.val = val;
	}

	public int getVal() {
		return val;
	}

	public void setVal(int val) {
		this.val = val;
	}

	public String toString() {
		return val + "";
	}
}