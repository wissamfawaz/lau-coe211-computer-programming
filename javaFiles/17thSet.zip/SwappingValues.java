public class SwappingValues {
	public static void main(String[] args) {
		/*int val1 = 2, val2 = 7;
		
		System.out.println("Before swapping: ");
		System.out.println("Val1: " + val1 + ", val2: " + val2);
		swap(val1, val2);
		System.out.println("After swapping: ");
		System.out.println("Val1: " + val1 + ", val2: " + val2);*/

		Int val1 = new Int(2), val2 = new Int(7);
		System.out.println("Before swapping: ");
		System.out.println("Val1: " + val1 + ", val2: " + val2);

		swap_modified(val1, val2);

		System.out.println("After swapping: ");
		System.out.println("Val1: " + val1 + ", val2: " + val2);
		
	}

	private static void swap(int val1, int val2) {
		int temp = val1;
		val1 = val2;
		val2 = temp;	
	}

	private static void swap_modified(Int val1, Int val2) {
		int temp = val1.getVal();
		val1.setVal(val2.getVal());
		val2.setVal(temp);

	}





}