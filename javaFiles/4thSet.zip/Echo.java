import java.util.Scanner;

public class Echo {
	public static void main(String[] args) {
		String line;
		Scanner scan = new Scanner(System.in);


		System.out.println("Please enter a line of text: ");
		line = scan.nextLine();

		System.out.println("You typed: " + line);		
	}
}