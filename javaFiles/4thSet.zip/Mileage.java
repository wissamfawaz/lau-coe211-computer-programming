import java.util.Scanner;
public class Mileage{
	public static void main(String[] args){
		Scanner scan = new Scanner(System.in);
		int miles, gallons;
		double mileage;

		System.out.print("Enter number of miles: ");
		miles = scan.nextInt();
		System.out.print("Enter number of gallons: ");
		gallons = scan.nextInt();
		mileage = miles / gallons;

		System.out.println("Mileage: " + mileage + " mpg");
		
	}
}