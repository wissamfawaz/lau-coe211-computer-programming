public class ArgsDemo {
	public static void main(String[] args) {
		if(args.length >= 2) {
			System.out.println(args[0]);
			System.out.println("My name is " + args[1]);
		}
	}
}