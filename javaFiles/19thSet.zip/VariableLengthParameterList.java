public class VariableLengthParameterList {
	public static void main(String[] args) {
		System.out.println(sum(1, 2, 3));
		System.out.println(sum(1, 2));
		System.out.println(sum());
	}

	private static int sum(int... arr) {
		int sum = 0;

		for(int val : arr) {
			sum += val;
		}

		return sum;
	}
}