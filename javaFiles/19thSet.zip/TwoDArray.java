import java.util.Arrays;
public class TwoDArray {
	public static void main(String[] args) {
		int[][] mat = new int[3][3];
		final int ROWS = mat.length;
		final int COLS = mat[0].length;
		
		for(int row = 0; row < ROWS; row++) {
			for(int col = 0; col < COLS; col++) {
				mat[row][col] = row * 10 + col;
			}
		}

		for(int row = 0; row < ROWS; row++) {
			for(int col = 0; col < COLS; col++) {
				System.out.print(mat[row][col] + " ");
			}
			System.out.println();
		}

		/*for(int[] row : mat) {
			System.out.println(Arrays.toString(row));
		}*/

	}
}