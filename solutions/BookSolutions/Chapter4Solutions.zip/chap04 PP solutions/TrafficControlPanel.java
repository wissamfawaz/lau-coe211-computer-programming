//********************************************************************
//  TrafficControlPanel.java       Author: Lewis/Loftus
//
//  Solution to Programming Project 4.15 (5E, p. 205)
//********************************************************************

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class TrafficControlPanel extends JPanel
{
   TrafficLightPanel light;

   public TrafficControlPanel()
   {
      setLayout(new BorderLayout());
      light = new TrafficLightPanel();
      add(light, BorderLayout.CENTER);

      JButton change = new JButton("Change Light");
      change.addActionListener(new ChangeListener());
      add(change, BorderLayout.SOUTH);
   }

   class ChangeListener implements ActionListener
   {
      public void actionPerformed(ActionEvent event)
      {
         light.change();
      }
   }
}
