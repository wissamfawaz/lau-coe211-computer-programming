//********************************************************************
//  Flight.java       Author: Lewis and Loftus
//
//  Solution to Programming Project 4.5 (5E, p. 203)
//********************************************************************

public class Flight
{
   private String airline, origin, destination;
   private int flightNumber;

   //-----------------------------------------------------------------
   //  Sets up this Flight object with the specified data.
   //-----------------------------------------------------------------
   public Flight (String airline, String origin, String destination, int
	            flightNumber)
   {
      this.airline = airline;
      this.origin = origin;
      this.destination = destination;
      this.flightNumber = flightNumber;
   }

   //-----------------------------------------------------------------
   //  Accessors.
   //-----------------------------------------------------------------
   public String getAirline ()
   {
	   return airline;
   }

   public String getOrigin ()
   {
	   return origin;
   }

   public String getDestination ()
   {
	   return destination;
   }

   public int getFlightNumber ()
   {
	   return flightNumber;
   }

   //-----------------------------------------------------------------
   //  Mutators.
   //-----------------------------------------------------------------
   public void setAirline (String airline)
   {
	   this.airline = airline;
   }

   public void setOrigin (String origin)
   {
	   this.origin = origin;
   }

   public void setDestination (String destination)
   {
	   this.destination = destination;
   }

   public void setFlightNumber (int flightNumber)
   {
	   this.flightNumber = flightNumber;
   }

   //-----------------------------------------------------------------
   //  Returns a string representation of this flight.
   //-----------------------------------------------------------------
   public String toString ()
   {
      return airline + " " + flightNumber + " --  From: " + origin +
             ", To: " + destination;
   }
}
