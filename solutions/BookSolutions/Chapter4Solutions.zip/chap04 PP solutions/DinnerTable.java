//********************************************************************
//  DinnerTable.java       Author: Lewis and Loftus
//
//  Solution to Programming Project 4.9 (5E, p. 204)
//********************************************************************

import javax.swing.JApplet;
import java.awt.Graphics;
import java.awt.Color;

public class DinnerTable extends JApplet
{
   private final int APPLET_WIDTH = 400;
   private final int APPLET_HEIGHT = 300;
   private final Color MALE = Color.cyan, FEMALE = Color.pink;

   private Diner diner1, diner2, diner3, diner4;
   private Diner diner5, diner6, diner7, diner8;

   //----------------------------------------------------------------
   //  Creates diners of various types.
   //----------------------------------------------------------------
   public void init()
   {
      diner1 = new Diner ("Matt", MALE, 80, 50);
      diner2 = new Diner ("Cathy", FEMALE, 150, 50);
      diner3 = new Diner ("Mike", MALE, 220, 50);
      diner4 = new Diner ("Jenn", FEMALE, 290, 50);
      diner5 = new Diner ("Nick", MALE, 80, 200);
      diner6 = new Diner ("Laurie", FEMALE, 150, 200);
      diner7 = new Diner ("Brian", MALE, 220, 200);
      diner8 = new Diner ("Liz", FEMALE, 290, 200);

      setBackground(Color.black);
      setSize(APPLET_WIDTH, APPLET_HEIGHT);
   }

   //----------------------------------------------------------------
   //  Paints the diners and the table.
   //----------------------------------------------------------------
   public void paint(Graphics page)
   {
      page.setColor(Color.gray);
      page.fillRect (80, 100, 260, 100);

      diner1.draw (page);
      diner2.draw (page);
      diner3.draw (page);
      diner4.draw (page);
      diner5.draw (page);
      diner6.draw (page);
      diner7.draw (page);
      diner8.draw (page);
   }
}
