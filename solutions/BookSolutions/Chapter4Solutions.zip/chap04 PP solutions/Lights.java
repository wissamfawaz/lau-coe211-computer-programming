//********************************************************************
//  Lights.java       Author: Lewis and Loftus
//
//  Solution to Programming Project 4.6 (5E, p. 203)
//********************************************************************

class Lights
{
   //-----------------------------------------------------------------
   //  Creates and exercises some Bulb objects.
   //-----------------------------------------------------------------
   public static void main (String[] args)
   {
      Bulb b1 = new Bulb();
      Bulb b2 = new Bulb();
      Bulb b3 = new Bulb();

      System.out.println ("Is b2 on? " + b2.isOn());

      b2.setOn (true);
      b1.setOn (true);

      System.out.println (b1);
      System.out.println (b2);
      System.out.println (b3);
   }
}
