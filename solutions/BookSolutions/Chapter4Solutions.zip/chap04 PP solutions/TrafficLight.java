//********************************************************************
//  TrafficLight.java       Author: Lewis/Loftus
//
//  Solution to Programming Project 4.15 (5E, p. 205)
//********************************************************************

import javax.swing.*;

public class TrafficLight
{
   //-----------------------------------------------------------------
   //  Creates and presents the program frame.
   //-----------------------------------------------------------------
   public static void main (String[] args)
   {
      JFrame lightFrame = new JFrame ("Traffic Light");
      lightFrame.setDefaultCloseOperation (JFrame.EXIT_ON_CLOSE);

      lightFrame.getContentPane().add (new TrafficControlPanel());

      lightFrame.setSize(160,250);
      lightFrame.setVisible(true);
   }
}