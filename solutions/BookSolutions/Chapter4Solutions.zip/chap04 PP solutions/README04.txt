This folder contains solutions to the Programming Projects from
Chapter 4 of Java Software Solutions, 5th Ed, by Lewis and Loftus.

Project     File(s)
-------     -------

4.1         MultiSphere.java
            Sphere.java

4.2         Kennel.java
            Dog.java

4.3         BoxTest.java
            Box.java

4.4         Bookshelf.java
            Book.java

4.5         FlightTest.java
            Flight.java

4.6         Lights.java
            Bulb.java

4.7         RollingDice2.java
            PairOfDice.java
            Die.java

4.8         Skyline.java
            Building.java
            Skyline.html

4.9         DinnerTable.java
            Diner.java
            DinnerTable.html

4.10        CrayonBox.java
            Crayon.java
            CrayonBox.html

4.11        NightSky.java
            Star.java
            NightSky.html

4.12        Fahrenheit.java
            FahrenheitGUI.java

4.13        RandomDisplay.java
            RandomGUI.java

4.14        IncDec.java
            IncDecGUI.java

4.15        TrafficLight.java
            TrafficControlPanel.java
            TrafficLightPanel.java

4.16        not provided


