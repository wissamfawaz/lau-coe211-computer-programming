//********************************************************************
//  Diner.java       Author: Lewis and Loftus
//
//  Solution to Programming Project 4.9 (5E, p. 204)
//********************************************************************

import java.awt.Graphics;
import java.awt.Color;

public class Diner
{
   private final int DINER_SIZE = 50;

   private String name;
   private Color gender;
   private int locationX, locationY;

   //-----------------------------------------------------------------
   //  Sets up this diner with the specified characteristics.
   //-----------------------------------------------------------------
   public Diner (String dinerName, Color genderColor, int x, int y)
   {
      name = dinerName;
      gender = genderColor;
      locationX = x;
      locationY = y;
   }

   //-----------------------------------------------------------------
   //  Draws the diner.
   //-----------------------------------------------------------------
   public void draw (Graphics page)
   {
      page.setColor (gender);
      page.fillOval (locationX, locationY, DINER_SIZE, DINER_SIZE);
      page.setColor (Color.black);
      page.drawString (name, (locationX+10), (locationY+30));
   }
}
