//********************************************************************
//  CrayonBox.java       Author: Lewis and Loftus
//
//  Solution to Programming Project 4.10 (5E, p. 204)
//********************************************************************

import javax.swing.JApplet;
import java.awt.*;

public class CrayonBox extends JApplet
{
   private final int APPLET_WIDTH = 350;
   private final int APPLET_HEIGHT = 300;

   private Crayon c1, c2, c3, c4, c5, c6, c7, c8;

   //-----------------------------------------------------------------
   //  Create several Crayon objects of varying characteristics.
   //-----------------------------------------------------------------
   public void init()
   {
      c1 = new Crayon (Color.cyan, 100, 50);
      c2 = new Crayon (Color.blue, 75, 80);
      c3 = new Crayon (Color.gray, 100, 110);
      c4 = new Crayon (Color.green, 90, 140);
      c5 = new Crayon (Color.magenta, 82, 170);
      c6 = new Crayon (Color.orange, 100, 200);
      c7 = new Crayon (Color.pink, 68, 230);
      c8 = new Crayon (Color.red, 100, 260);

      setBackground (Color.black);
      setSize (APPLET_WIDTH, APPLET_HEIGHT);
   }

   //-----------------------------------------------------------------
   //  Paints the crayons and the box.
   //-----------------------------------------------------------------
   public void paint (Graphics page)
   {
      c1.draw (page);
      c2.draw (page);
      c3.draw (page);
      c4.draw (page);
      c5.draw (page);
      c6.draw (page);
      c7.draw (page);
      c8.draw (page);

      page.setColor (Color.yellow);
      page.fillRect (45, 150, 245, 90);

      page.setColor (Color.black);
      page.drawString ("Crayola", 150, 200);
   }
}
