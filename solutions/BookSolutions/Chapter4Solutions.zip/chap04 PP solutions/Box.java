//********************************************************************
//  Box.java       Author: Lewis and Loftus
//
//  Solution to Programming Project 4.3 (5E, p. 203)
//********************************************************************

public class Box
{
   private int height, width, depth;
   private boolean full;

   //-----------------------------------------------------------------
   //  Sets up this Box object with the specified data.
   //-----------------------------------------------------------------
   public Box (int height, int width, int depth)
   {
      this.height = height;
      this.width = width;
      this.depth = depth;
      full = false;
   }

   //-----------------------------------------------------------------
   //  Accessors.
   //-----------------------------------------------------------------
   public int getHeight ()
   {
	   return height;
   }

   public int getWidth ()
   {
	   return width;
   }

   public int getDepth ()
   {
	   return depth;
   }

   public boolean isFull ()
   {
	   return full;
   }

   //-----------------------------------------------------------------
   //  Mutators.
   //-----------------------------------------------------------------
   public void setHeight (int height)
   {
	   this.height = height;
   }

   public void setWidth (int width)
   {
	   this.width = width;
   }

   public void setDepth (int depth)
   {
	   this.depth = depth;
   }

   public void setFull (boolean full)
   {
	   this.full = full;
   }

   //-----------------------------------------------------------------
   //  Returns a string representation of this box.
   //-----------------------------------------------------------------
   public String toString ()
   {
      return "Box size: " + height + " H x " + width + " W x " + depth
             + " D";
   }
}
