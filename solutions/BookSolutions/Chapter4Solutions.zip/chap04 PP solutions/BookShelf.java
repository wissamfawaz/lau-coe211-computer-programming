//********************************************************************
//  Bookshelf.java       Author: Lewis and Loftus
//
//  Solution to Programming Project 4.4 (5E, p. 203)
//********************************************************************

class Bookshelf
{
   //-----------------------------------------------------------------
   //  Creates and exercises some Book objects.
   //-----------------------------------------------------------------
   public static void main (String[] args)
   {
      Book b1 = new Book ("Java Software Solutions", "Lewis & Loftus",
           "Addison-Wesley", 2007);
      Book b2 = new Book ("Joel on Software", "Joel Spolsky",
           "APress", 2004);
      Book b3 = new Book ("Purple Cow", "Seth Godin", "Portfolio", 2002);

      System.out.println (b1);
      System.out.println (b2);
      System.out.println (b3);
   }
}
