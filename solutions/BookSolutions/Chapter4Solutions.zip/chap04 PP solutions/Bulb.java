//********************************************************************
//  Bulb.java       Author: Lewis and Loftus
//
//  Solution to Programming Project 4.6 (5E, p. 203)
//********************************************************************

public class Bulb
{
   private boolean on;

   //-----------------------------------------------------------------
   //  Sets up this Bulb object with the light off.
   //-----------------------------------------------------------------
   public Bulb ()
   {
      on = false;
   }

   //-----------------------------------------------------------------
   //  Returns true if this bulb is currently on.
   //-----------------------------------------------------------------
   public boolean isOn ()
   {
	   return on;
   }

   //-----------------------------------------------------------------
   //  Sets the "on" status of this bulb.
   //-----------------------------------------------------------------
   public void setOn (boolean status)
   {
	   on = status;
   }

   //-----------------------------------------------------------------
   //  Returns a string representation of this bulb.
   //-----------------------------------------------------------------
   public String toString ()
   {
      return "Bulb on: " + on;
   }
}
 	