//********************************************************************
//  NightSky.java       Author: Lewis and Loftus
//
//  Solution to Programming Project 4.11 (5E, p. 204)
//********************************************************************

import javax.swing.JApplet;
import java.awt.*;

public class NightSky extends JApplet
{
   Star star1, star2, star3, star4, star5;
   Star star6, star7, star8, star9, star10;

   //----------------------------------------------------------------
   //  Creates the pattern objects for the quilt.
   //----------------------------------------------------------------
   public void init ()
   {
      star1 = new Star (4, 5, 20, 20);
      star2 = new Star (5, 7, 100, 40);
      star3 = new Star (6, 10, 220, 80);
      star4 = new Star (4, 6, 350, 50);
      star5 = new Star (6, 12, 380, 30);
      star6 = new Star (5, 8, 190, 70);
      star7 = new Star (5, 10, 50, 50);
      star8 = new Star (6, 10, 300, 40);
      star9 = new Star (6, 8, 120, 60);
      star10 = new Star (4, 4, 270, 30);

      setSize (400, 300);
      setBackground (Color.black);
   }

   //----------------------------------------------------------------
   //  Draws the quilt.
   //----------------------------------------------------------------
   public void paint (Graphics page)
   {
      star1.draw (page);
      star2.draw (page);
      star3.draw (page);
      star4.draw (page);
      star5.draw (page);
      star6.draw (page);
      star7.draw (page);
      star8.draw (page);
      star9.draw (page);
      star10.draw (page);
   }
}
