//********************************************************************
//  Crayon.java       Author: Lewis and Loftus
//
//  Solution to Programming Project 4.10 (5E, p. 204)
//********************************************************************

import java.awt.*;

public class Crayon
{
   private final int BOTTOM = 150;
   private final int WIDTH = 25;

   private Color shade;
   private int length, location;

   //-----------------------------------------------------------------
   //  Sets up this crayon with the specfied characteristics.
   //-----------------------------------------------------------------
   public Crayon (Color crayonColor, int crayonLength, int position)
   {
      shade = crayonColor;
      length = crayonLength;
      location = position;
   }

   //-----------------------------------------------------------------
   //  Draws this crayon.
   //-----------------------------------------------------------------
   public void draw(Graphics page)
   {
      page.setColor (shade);
      page.fillRect (location, BOTTOM-length, WIDTH, length);
   }
}

