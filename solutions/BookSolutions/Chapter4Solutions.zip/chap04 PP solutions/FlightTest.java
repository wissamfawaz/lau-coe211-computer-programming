//********************************************************************
//  FlightTest.java       Author: Lewis and Loftus
//
//  Solution to Programming Project 4.5 (5E, p. 203)
//********************************************************************

class FlightTest
{
   //-----------------------------------------------------------------
   //  Creates and exercises some Flight objects.
   //-----------------------------------------------------------------
   public static void main (String[] args)
   {
      Flight f1 = new Flight ("US Air", "Boston", "Los Angeles", 347);
      Flight f2 = new Flight ("Delta", "Philadelphia", "London", 212);
      Flight f3 = new Flight ("Continental", "Atlanta", "Chicago", 822);

      System.out.println (f1);
      System.out.println (f2);
      System.out.println (f3);
   }
}
