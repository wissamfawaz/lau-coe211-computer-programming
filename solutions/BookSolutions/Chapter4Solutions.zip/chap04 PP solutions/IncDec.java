//********************************************************************
//  IncDec.java       Author: Lewis/Loftus
//
//  Solution to Programming Project 4.14 (5E, p. 204)
//********************************************************************

public class IncDec
{
   //-----------------------------------------------------------------
   //  Creates and displays the increment / decrement  GUI.
   //-----------------------------------------------------------------
   public static void main (String[] args)
   {
      IncDecGUI id = new IncDecGUI();
      id.display();
   }
}
