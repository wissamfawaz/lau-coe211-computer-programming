//********************************************************************
//  RandomDisplay.java       Author: Lewis/Loftus
//
//  Solution to Programming Project 4.13 (5E, p. 204)
//********************************************************************

public class RandomDisplay
{
   //-----------------------------------------------------------------
   //  Creates and displays the random number GUI.
   //-----------------------------------------------------------------
   public static void main (String[] args)
   {
      RandomGUI rand = new RandomGUI();
      rand.display();
   }
}
