//********************************************************************
//  Book.java       Author: Lewis and Loftus
//
//  Solution to Programming Project 4.4 (5E, p. 203)
//********************************************************************

public class Book
{
   private String title, author, publisher;
   private int copyright;

   //-----------------------------------------------------------------
   //  Sets up this Book object with the specified data.
   //-----------------------------------------------------------------
   public Book (String title, String author, String publisher, int
	            copyright)
   {
      this.title = title;
      this.author = author;
      this.publisher = publisher;
      this.copyright = copyright;
   }

   //-----------------------------------------------------------------
   //  Accessors.
   //-----------------------------------------------------------------
   public String getTitle ()
   {
	   return title;
   }

   public String getAuthor ()
   {
	   return author;
   }

   public String getPublisher ()
   {
	   return publisher;
   }

   public int getCopyright ()
   {
	   return copyright;
   }

   //-----------------------------------------------------------------
   //  Mutators.
   //-----------------------------------------------------------------
   public void setTitle (String title)
   {
	   this.title = title;
   }

   public void setAuthor (String author)
   {
	   this.author = author;
   }

   public void setPublisher (String publisher)
   {
	   this.publisher = publisher;
   }

   public void setCopyright (int copyright)
   {
	   this.copyright = copyright;
   }

   //-----------------------------------------------------------------
   //  Returns a string representation of this book.
   //-----------------------------------------------------------------
   public String toString ()
   {
      return "Title: " + title + "\nAuthor: " + author + "\nPulbisher: " 
             + publisher + "\nCopyright: " + copyright + "\n";
   }
}
