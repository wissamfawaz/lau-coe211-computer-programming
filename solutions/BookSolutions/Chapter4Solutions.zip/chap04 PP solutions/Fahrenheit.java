//********************************************************************
//  Fahrenheit.java       Author: Lewis/Loftus
//
//  Solution to Programming Project 4.12 (5E, p. 204)
//********************************************************************

public class Fahrenheit
{
   //-----------------------------------------------------------------
   //  Creates and displays the temperature converter GUI.
   //-----------------------------------------------------------------
   public static void main (String[] args)
   {
      FahrenheitGUI converter = new FahrenheitGUI();
      converter.display();
   }
}
