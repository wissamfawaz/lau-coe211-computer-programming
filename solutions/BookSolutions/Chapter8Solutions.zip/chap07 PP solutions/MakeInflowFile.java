//*********************************************************************
//  MakeInflowFile.java       Author: Lewis and Loftus
//
//  Support for Programming Project 7.26 (5E, p. 436) solution.
//*********************************************************************

import java.io.*;
import java.util.*;

public class MakeInflowFile
{
   //-----------------------------------------------------------------
   //  Makes data file with random data for hospital analysis program.
   //-----------------------------------------------------------------
   public static void main (String [] args)
   {
      try
      {
         Random gen = new Random();

         PrintWriter out = new PrintWriter (
                           new BufferedWriter (
                           new FileWriter (
                           new File (args[0]))));

         for (int week = 0; week < 4; week++)
         {
            for (int day = 0; day < 7; day++)
            {
               for (int hour = 0; hour < 24; hour++)
                  out.print (gen.nextInt(5) + " ");
               out.println ();
            }
            out.println ();
         }

         out.close ();
      }
      catch (Exception ex)
      {
         ex.printStackTrace (System.err);
         System.out.println ("Usage: java MakeInflowFile filename");
      }
   }
}
