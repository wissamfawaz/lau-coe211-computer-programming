//********************************************************************
//  Circle.java       Author: Lewis/Loftus
//
//  Solution to Programming Project 7.16 (5E, p. 434)
//********************************************************************

import java.awt.Graphics;
import java.awt.Color;

public class Circle
{
   private int radius;
   private int x, y;
   private Color color;

   //-----------------------------------------------------------------
   //  Creates a circle object
   //-----------------------------------------------------------------
   public Circle(int centerX, int centerY, int circleRadius)
   {
      radius = circleRadius;
      x = centerX;
      y = centerY;
      color = Color.black;
   }

   //-----------------------------------------------------------------
   //  Returns true if this circle overlaps the specified circle.
   //-----------------------------------------------------------------
   public boolean overlap (Circle other)
   {
      double distance = Math.sqrt((x - other.getX()) * (x - other.getX()) +
                                  (y - other.getY()) * (y - other.getY()));

      return (distance < (radius + other.getRadius()));
   }

   //-----------------------------------------------------------------
   //  Sets the color of the circle
   //-----------------------------------------------------------------
   public void setColor (Color c)
   {
      color = c;
   }

   //-----------------------------------------------------------------
   //  Returns the x coordinate of the circle's center point
   //-----------------------------------------------------------------
   public int getX()
   {
      return x;
   }

   //-----------------------------------------------------------------
   //  Returns the y coordinate of the circle's center point
   //-----------------------------------------------------------------
   public int getY()
   {
      return y;
   }

   //-----------------------------------------------------------------
   //  Returns the circle's radius
   //-----------------------------------------------------------------
   public int getRadius()
   {
      return radius;
   }

   //-----------------------------------------------------------------
   //  Draws the circle with the graphics context page
   //-----------------------------------------------------------------
  public void draw(Graphics page)
   {
      int xLocation = x - radius;
      int yLocation = y - radius;
      page.setColor(color);
      page.fillOval(xLocation, yLocation, 2*radius, 2*radius);
      page.setColor(Color.black);
      page.drawOval(xLocation, yLocation, 2*radius, 2*radius);
   }
}

