//******************************************************************************
//  NameAndZip.java       Author: Lewis and Loftus
//
//  Solution to Programming Project 7.8 (5E, p. 433)
//******************************************************************************

import java.text.*;

public class NameAndZip
{
   private String firstName = "";
   private String lastName = "";
   private int zipCode;
   private static DecimalFormat form = new DecimalFormat("00000");

   //---------------------------------------------------------------------------
   //  Sets up the adress book entry by entering the first and last
   //  name and the zip code
   //---------------------------------------------------------------------------
   public NameAndZip (String fName, String lName, int zCode)
   {
      firstName = fName;
      lastName = lName;
      zipCode = zCode;
   }

   //---------------------------------------------------------------------------
   //  Returns the string value of firstName
   //---------------------------------------------------------------------------
   public String getFName () 
   {
      return firstName;
   }

   //---------------------------------------------------------------------------
   //  Returns the string value of lastName
   //---------------------------------------------------------------------------
   public String getLName () 
   {
      return lastName;
   }

   //---------------------------------------------------------------------------
   //  Returns the int value of zipCode
   //---------------------------------------------------------------------------
   public int getZCode () 
   {
      return zipCode;
   }

   //---------------------------------------------------------------------------
   //  Returns the address book entry in a one line format
   //---------------------------------------------------------------------------
   public String toString () 
   {
      return firstName + " " + lastName + "\t" + form.format(zipCode);
   }
}
