//********************************************************************
//  CarTest.java       Author: Lewis and Loftus
//
//  Solution to Programming Project 7.13 (5E, p. 434)
//********************************************************************

import javax.swing.JApplet;
import java.awt.Graphics;

public class CarTest extends JApplet
{
   private Car car1;
   private Car car2;

   //-----------------------------------------------------------------
   //  Sets up the applet
   //-----------------------------------------------------------------
   public void init()
   {
      car1 = new Car(200, 150);
      car2 = new Car(50, 50);

      setVisible (true);
      setSize (450, 250);
   }

   //-----------------------------------------------------------------
   //  Draws the car.
   //-----------------------------------------------------------------
   public void paint (Graphics page)
   {
      car1.draw (page);
      car2.draw (page);
   }
}
