//********************************************************************
//  CountClicksPanel.java       Author: Lewis and Loftus
//
//  Solution to Programming Project 7.20 (5E, p. 435)
//********************************************************************

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class CountClicksPanel extends JPanel
{
   private int count;

   public CountClicksPanel ()
   {
      addMouseListener(new ClickListener());

      setBackground (Color.orange);
   }

   //-----------------------------------------------------------------
   //  Displays the number of times the mouse is pressed.
   //-----------------------------------------------------------------
   public void paintComponent (Graphics page)
   {
      super.paintComponent(page);
      page.setColor(Color.blue);
      page.drawString("Clicks: " + count, 75, 100);
   }

   //*****************************************************************
   //  Represents a listener for the mouse click event
   //*****************************************************************
   class ClickListener extends MouseAdapter
   {
      //-----------------------------------------------------------------
      //  Counts the number of times the mouse is pressed.
      //-----------------------------------------------------------------
      public void mouseClicked (MouseEvent event)
      {
         count++;
         repaint();
      }

   }
}
