//********************************************************************
//  Quiz2.java       Author: Lewis and Loftus
//
//  Solution to Programming Project 7.11 (5E, p. 434)
//********************************************************************

import java.util.Scanner;

public class Quiz2
{
   private final int MAX_QUESTIONS = 25;

   private Question[] questions;
   private int current, correct, incorrect;

   //-----------------------------------------------------------------
   //  Sets up an initially empty quiz.
   //-----------------------------------------------------------------
   public Quiz2()
   {
      questions = new Question[MAX_QUESTIONS];
      current = 0;
      correct = incorrect = 0;
   }

   //-----------------------------------------------------------------
   //  Adds the specified question to this quiz.
   //-----------------------------------------------------------------
   public void add (Question newQuestion)
   {
      if (current < MAX_QUESTIONS)
         questions[current++] = newQuestion;
   }

   //-----------------------------------------------------------------
   //  Administers this quiz.
   //-----------------------------------------------------------------
   public void giveQuiz()
   {
      Scanner scan = new Scanner (System.in);
	  
	  for (int i = 0; i < current; i++)
	  {
         System.out.println(questions[i].getQuestion());
         if (questions[i].answerCorrect(scan.nextLine()))
            correct++;
         else
            incorrect++;

      }
   }

   //-----------------------------------------------------------------
   //  Administers this quiz, using only questions in the specified
   //  complexity range.
   //-----------------------------------------------------------------
   public void giveQuiz (int minComplexity, int maxComplexity)
   {
      Scanner scan = new Scanner (System.in);
	  
	  for (int i = 0; i < current; i++)
      {
         int complexity = questions[i].getComplexity();
         if (complexity >= minComplexity && complexity <= maxComplexity)
         {
            System.out.println(questions[i].getQuestion());
            if (questions[i].answerCorrect(scan.nextLine()))
               correct++;
            else
               incorrect++;
          }
      }

      if (correct == 0 && incorrect == 0)
         System.out.println("Sorry, no questions fall within the specified complexity range");
   }

   //-----------------------------------------------------------------
   //  Returns the number of correct answers.
   //-----------------------------------------------------------------
   public int getNumCorrect()
   {
      return correct;
   }

   //-----------------------------------------------------------------
   //  Returns the number of incorrect answers.
   //-----------------------------------------------------------------
   public int getNumIncorrect()
   {
      return incorrect;
   }
}
