//********************************************************************
//  LLBank.java             Author: Lewis and Loftus
//
//  Solution to Programming Project 7.6 (5E, p. 433)
//********************************************************************

import java.util.Scanner;

public class LLBank
{
   private final int MAX = 30;
   private double INTEREST = 1.03;  // 3% interest
   private LLBankCustomer[] customers = new LLBankCustomer[MAX];
   private int count = 0;
   
   //-----------------------------------------------------------------
   //  Sets up an initially empty bank.
   //-----------------------------------------------------------------
   public LLBank()
   {
      for (int idx = 0; idx < MAX; idx++)
         customers[idx] = null;
   }

   //-----------------------------------------------------------------
   //  Create a new account.
   //-----------------------------------------------------------------
   public void create ()
   {
      System.out.println ("CREATING A NEW CUSTOMER ACCOUNT");
      System.out.print ("Account number? ");
	  
	  Scanner scan = new Scanner (System.in);
      int acct = scan.nextInt();
      String flush = scan.nextLine();  // flush line
      int index = findAccount(acct);
      if (index != -1)
         System.out.println ("Account number already in use.");
      else
      {
         System.out.print ("Name of new customer? ");
         String name = scan.nextLine();
         System.out.print ("Phone number of new customer? ");
         String phone = scan.nextLine();
         customers[count] = new LLBankCustomer(acct, name, phone, 0.0);
         count++;
      }
   }

   //-----------------------------------------------------------------
   //  Prompt for deposit information, verify, and process.
   //-----------------------------------------------------------------
   public void deposit ()
   {
      System.out.println ("MAKING A DEPOSIT");
      System.out.print ("Account number? ");
	  
	  Scanner scan = new Scanner (System.in);
	  
      int acct = scan.nextInt();
      int index = findAccount(acct);
      if (index == -1)
         System.out.println ("Invalid account number.");
      else
      {
         System.out.print ("Amount of deposit? ");
         double amt = scan.nextDouble();
         if (amt > 0.0)
         {
            double update = customers[index].getBalance() + amt;
            customers[index].setBalance(update);
         }
         else
            System.out.println ("Invalid deposit amount.");
      }
   }

   //-----------------------------------------------------------------
   //  Prompt for withdraw information, verify, and process.
   //-----------------------------------------------------------------
   public void withdraw()
   {
      System.out.println ("MAKING A WITHDRAW");
      System.out.print ("Account number? ");
	  Scanner scan = new Scanner (System.in);
	  
      int acct = scan.nextInt();
      int index = findAccount(acct);
      if (index == -1)
         System.out.println ("Invalid account number.");
      else
      {
         System.out.print ("Amount of withdrawal? ");
         double amt = scan.nextDouble();
         if (customers[index].getBalance() >= amt)
            if (amt > 0.0)
            {
               double update = customers[index].getBalance() - amt;
               customers[index].setBalance(update);
            }
            else
               System.out.println ("Invalid withdrawal amount.");
         else
            System.out.println ("Insufficient balance.");
      }
   }

   //-----------------------------------------------------------------
   //  Add interest to each existing accounts.
   //-----------------------------------------------------------------
   public void interest ()
   {
      System.out.println ("ADDING INTEREST");
      for (int idx = 0; idx < count; idx++)
         customers[idx].setBalance(customers[idx].getBalance() * INTEREST);
   }

   //-----------------------------------------------------------------
   //  Returns the information about the bank as a string.
   //-----------------------------------------------------------------
   public String toString()
   {
      String result = "";
      for (int idx = 0; idx < count; idx++)
      {
         result += customers[idx];
         result += "\n";
      }
      return result;
   }

   //-----------------------------------------------------------------
   //  Searches for the specified account number. Returns -1 if not
   //  found.
   //-----------------------------------------------------------------
   public int findAccount (long target)
   {
      int result = -1, seek=0;
      boolean found = false;

      while (seek < count && !found)
      {
         if (target == customers[seek].getAccount())
         {
            found = true;
            result = seek;
         }
         seek++;
      }

      return result;
   }
}
