//********************************************************************
//  Direction3.java       Author: Lewis and Loftus
//
//  Solution to Programming Project 7.28 (5E, p. 436)
//********************************************************************

import javax.swing.*;

public class Direction3 extends JApplet
{
   //-----------------------------------------------------------------
   //  Adds the display panel to the applet.
   //-----------------------------------------------------------------
   public void init()
   {
      getContentPane().add (new DirectionPanel3(this));
   }
}
