//********************************************************************
//  Line.java       Author: Lewis and Loftus
//
//  Solution to Programming Project 7.19 (5E, p. 435)
//********************************************************************

import java.awt.Point;

public class Line
{
   private Point one, two;

   //-----------------------------------------------------------------
   //  Sets up the line by storing the coordinates of the two ends
   //  of the line.
   //-----------------------------------------------------------------
   public Line (Point a, Point b)
   {
      one = a;
      two = b;
   }

   //-----------------------------------------------------------------
   //  Returns the first (beginning) point of the line.
   //-----------------------------------------------------------------
   public Point getOne ()
   {
      return one;
   }

   //-----------------------------------------------------------------
   //  Returns the second (end) point of the line.
   //-----------------------------------------------------------------
   public Point getTwo ()
   {
      return two;
   }
}
