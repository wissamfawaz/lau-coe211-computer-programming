//********************************************************************
//  QuoteOptions3.java       Author: Lewis and Loftus
//
//  Solution to Programming Project 7.15 (5E, p. 434)
//********************************************************************

import javax.swing.*;

public class QuoteOptions3
{
   //-----------------------------------------------------------------
   //  Creates and presents the program frame.
   //-----------------------------------------------------------------
   public static void main (String[] args)
   {
      JFrame quoteFrame = new JFrame ("Quote Options");
      quoteFrame.setDefaultCloseOperation (JFrame.EXIT_ON_CLOSE);

      QuoteGUI3 gui = new QuoteGUI3();
      quoteFrame.getContentPane().add (gui.getPanel());

      quoteFrame.pack();
      quoteFrame.setVisible(true);
   }
}
