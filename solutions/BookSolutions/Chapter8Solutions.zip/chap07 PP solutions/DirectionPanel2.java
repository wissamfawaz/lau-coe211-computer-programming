//********************************************************************
//  DirectionPanel2.java       Author: Lewis and Loftus
//
//  Solution to Programming Project 7.27 (5E, p. 436)
//********************************************************************

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class DirectionPanel2 extends JPanel
{
   private final int JUMP = 10;  // increment for image movement

   private final int IMAGE_SIZE = 31;
   private final int BEGIN_POS = 200;

   private ImageIcon up, down, right, left, currentImage;
   private int x, y;

   //-----------------------------------------------------------------
   //  Sets up this panel and loads the images.
   //-----------------------------------------------------------------
   public DirectionPanel2 (JApplet applet)
   {
      applet.addKeyListener (new DirectionListener());

      x = BEGIN_POS;
      y = BEGIN_POS;

      up = new ImageIcon ("arrowUp.gif");
      down = new ImageIcon ("arrowDown.gif");
      left = new ImageIcon ("arrowLeft.gif");
      right = new ImageIcon ("arrowRight.gif");

      currentImage = right;

      setBackground (Color.black);
   }

   //-----------------------------------------------------------------
   //  Draws the image in the current location.
   //-----------------------------------------------------------------
   public void paintComponent (Graphics page)
   {
      super.paintComponent (page);
      currentImage.paintIcon (this, page, x, y);
   }

   //*****************************************************************
   //  Represents the listener for keyboard activity.
   //*****************************************************************
   private class DirectionListener implements KeyListener
   {
      //--------------------------------------------------------------
      //  Responds to the user pressing arrow keys by adjusting the
      //  image location accordingly. Keeps the image in the window.
      //--------------------------------------------------------------
      public void keyPressed (KeyEvent event)
      {
         switch (event.getKeyCode())
         {
            case KeyEvent.VK_UP:
               currentImage = up;
               if (y > 0)
                  y -= JUMP;
               break;
           case KeyEvent.VK_DOWN:
               currentImage = down;
               if (y < getHeight()-IMAGE_SIZE)
                  y += JUMP;
               break;
            case KeyEvent.VK_LEFT:
               currentImage = left;
               if (x > 0)
                  x -= JUMP;
               break;
            case KeyEvent.VK_RIGHT:
               currentImage = right;
               if (x < getWidth()-IMAGE_SIZE)
                  x += JUMP;
               break;
         }

         repaint();
      }

      //--------------------------------------------------------------
      //  Provide empty definitions for unused event methods.
      //--------------------------------------------------------------
      public void keyTyped (KeyEvent event) {}
      public void keyReleased (KeyEvent event) {}
   }
}
