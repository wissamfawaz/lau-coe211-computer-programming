//********************************************************************
//  QuizTime.java       Author: Lewis/Loftus
//
//  Solution to Programming Project 7.10 (5E, p. 433)
//********************************************************************

public class QuizTime
{
   public static void main(String[] args)
   {
      Quiz q = new Quiz();


      q.add(new Question ("What is the wind speed flight velocity of a swallow?",
                              "African or European?"));

      q.add(new Question ("What color was George Washington's white horse?",
                              "white"));

      q.add(new Question ("How much wood could a woodchuck chuck?",
                           "Wouldn't know"));

      q.add(new Question ("What's my favorite programming language?",
                           "Java"));

      q.add(new Question ("What is the capital of Bolivia?",
                           "La Paz"));

      q.add(new Question ("How many moons does the planet Venus have?",
                           "zero"));


      q.giveQuiz();

      System.out.print("\nResults:\n\tCorrect: " + q.getNumCorrect());
      System.out.println("\tIncorrect: " + q.getNumIncorrect());
   }
}