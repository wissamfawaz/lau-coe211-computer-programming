//********************************************************************
//  CarTest2.java       Author: Lewis and Loftus
//
//  Solution to Programming Project 7.14 (5E, p.434)
//********************************************************************

import javax.swing.JApplet;
import java.awt.Graphics;
import java.awt.Color;

public class CarTest2 extends JApplet
{
   private Car2 car1;
   private Car2 car2;

   //-----------------------------------------------------------------
   //  Sets up the applet.
   //-----------------------------------------------------------------
   public void init()
   {
      car1 = new Car2(200, 150, Color.red);
      car2 = new Car2(50, 50, Color.blue);

      setVisible (true);
      setSize (450, 250);
   }

   //-----------------------------------------------------------------
   //  Draws the cars.
   //-----------------------------------------------------------------
   public void paint (Graphics page)
   {
      car1.draw (page);
      car2.draw (page);
   }
}
