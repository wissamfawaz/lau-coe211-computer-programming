//********************************************************************
//  RubberCirclePanel.java       Author: Lewis and Loftus
//
//  Solution to Programming Project 7.22 (5E, p. 435)
//********************************************************************

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class RubberCirclePanel extends JPanel
{
   private Point center = null, current = null;

   //-----------------------------------------------------------------
   //  Initializes the panel
   //-----------------------------------------------------------------
   public RubberCirclePanel ()
   {
      RubberCircleListener listener = new RubberCircleListener();
      addMouseListener (listener);
      addMouseMotionListener (listener);

      setBackground (Color.black);
   }

   //-----------------------------------------------------------------
   //  Draws the current circle centered around an original point.
   //-----------------------------------------------------------------
   public void paintComponent (Graphics page)
   {
      super.paintComponent (page);
      page.setColor (Color.red);

      if (center != null && current != null)
      {
         int xDelta = center.x - current.x;
         int yDelta = center.y - current.y;
         double radius = Math.sqrt ( Math.pow(xDelta, 2) +
                                     Math.pow(yDelta, 2) );

         int height = (int)(radius*2);
         int width = (int)(radius*2);
         int top = (int)(center.x - radius);
         int left = (int)(center.y - radius);

         page.drawOval (top, left, width, height);
      }
   }

   //*****************************************************************
   //  Represents a listener for all mouse events.
   //*****************************************************************
   private class RubberCircleListener implements MouseListener,
                                                 MouseMotionListener
   {
      //--------------------------------------------------------------
      //  Stores the point the mouse was at when it is first pressed.
      //--------------------------------------------------------------
      public void mousePressed (MouseEvent event)
      {
         center = event.getPoint();
      }

      //--------------------------------------------------------------
      //  Obtains the current mouse position and records it.  And draws
      //  the circle to create the rubberband effect.
      //--------------------------------------------------------------
      public void mouseDragged (MouseEvent event)
      {
         current = event.getPoint();
         repaint();
      }

      //--------------------------------------------------------------
      //  Empty definitions for the unused event methods.
      //--------------------------------------------------------------
      public void mouseClicked (MouseEvent event) {}
      public void mouseReleased (MouseEvent event) {}
      public void mouseEntered (MouseEvent event) {}
      public void mouseExited (MouseEvent event) {}
      public void mouseMoved (MouseEvent event) {}
   }
}
