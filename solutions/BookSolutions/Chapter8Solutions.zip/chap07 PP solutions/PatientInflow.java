//*********************************************************************
//  PatientInflow.java        Author: Lewis and Loftus
//
//  Solution to Programming Project 7.26 (5E, p. 436)
//*********************************************************************

import java.io.*;
import java.util.*;

public class PatientInflow
{
   //-----------------------------------------------------------------
   //  Reads and analyzes hospital flow data. The input file is
   //  specified using a command-line argument.
   //-----------------------------------------------------------------
   public static void main (String[] args)
   {
      try
      {
         int datum;
         int[] weekly = new int[4];
         int[] daily = new int[7];
         int[] hourly = new int[24];
         int[][][] patients = new int[24][7][4];

         BufferedReader in = new BufferedReader (
                           new FileReader (
                           new File(args [0])));
         StringTokenizer reader;

         // read data and calculate totals
         for (int week = 0; week < 4; week++)
         {
            for (int day = 0; day < 7; day++)
            {
               reader = new StringTokenizer (in.readLine());
               for (int hour = 0; hour < 24; hour++)
               {
                  datum = Integer.parseInt (reader.nextToken());
                  patients [hour][day][week] = datum;
                  hourly [hour] += datum;
                  daily [day] += datum;
                  weekly [week] += datum;
               }
            }
            in.readLine();
         }

         // print the analysis results
         System.out.println ("Per Week Of The Month:");
         for (int week = 1; week <= 4; week++)
            System.out.println (week + ":\t" + weekly[week - 1]);

         System.out.println ("Per Day Of The Week:");
         for (int day = 1; day <= 7; day++)
            System.out.println (day + ":\t" + daily[day - 1]);

         System.out.println ("Per Hour Of The Day:");
         for (int hour = 0; hour < 24; hour++)
            System.out.println (hour + ":\t" + hourly[hour]);
      }
      catch (Exception ex)
      {
         ex.printStackTrace (System.err);
         System.out.println ("Usage: java PatientInflow filename");
      }
   }
}
