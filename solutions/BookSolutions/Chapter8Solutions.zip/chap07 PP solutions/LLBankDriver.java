//********************************************************************
//  LLBankDriver.java             Author: Lewis and Loftus
//
//  Solution to Programming Project 7.6 (5E, p. 433)
//********************************************************************

public class LLBankDriver
{
   //-----------------------------------------------------------------
   //  Exercises the methods of an LLBank object.
   //-----------------------------------------------------------------
   public static void main (String[] args)
   {
      System.out.println ("Welcome to the L & L Bank.\n");

      LLBank bank = new LLBank();

      bank.create();
      bank.deposit();
      bank.create();
      bank.deposit();
      bank.create();
      bank.deposit();
      bank.withdraw();

      System.out.println ("Current Status:");
      System.out.println (bank);

      bank.withdraw();
      bank.interest();

      System.out.println ("Final Status:");
      System.out.println (bank);
   }
}
