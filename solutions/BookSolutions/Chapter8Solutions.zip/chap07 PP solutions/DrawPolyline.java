//********************************************************************
//  DrawPolyline.java       Author: Lewis and Loftus
//
//  Solution to Programming Project 7.21 (5E, p. 435)
//********************************************************************

import javax.swing.JApplet;


public class DrawPolyline extends JApplet
{
   //-----------------------------------------------------------------
   //  Sets up the applet.
   //-----------------------------------------------------------------
   public void init ()
   {
      getContentPane().add(new DrawPolylinePanel());
   }
}




