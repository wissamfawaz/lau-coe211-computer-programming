//********************************************************************
//  Checkers.java       Author: Lewis and Loftus
//
//  Solution to Programming Project 7.17 (5E, p. 434)
//********************************************************************

import javax.swing.JApplet;
import java.awt.Graphics;
import java.awt.Color;
import java.util.Random;

public class Checkers extends JApplet
{
   int[][] checkerBoard;

   private int NUM_ROWS = 8,
               NUM_RED = 5,
               NUM_BLACK = 8,
               BLACK = -1,
               EMPTY = 0,
               RED_CHECKER = 1,
               BLACK_CHECKER = 2,
               INSET = 5;

   //-----------------------------------------------------------------
   //  Creates a checkboard and adds checker in random positions
   //-----------------------------------------------------------------
   public void init()
   {
      checkerBoard = new int[NUM_ROWS][NUM_ROWS];
      int j;
      for (int i=0; i<NUM_ROWS; i++)
         for (j=0; j<NUM_ROWS; j++)
            if ((i % 2 == 0) == (j % 2 == 0))
               checkerBoard[i][j] = BLACK;
            else
               checkerBoard[i][j] = EMPTY;
      populateBoard();
   }

   //-----------------------------------------------------------------
   //  Generates random checkers
   //-----------------------------------------------------------------
   public void populateBoard()
   {
      Random gen = new Random();

      int number = 0;
      // create red checkers
      while (number < NUM_RED)
      {
         int x = gen.nextInt(NUM_ROWS);
         int y = gen.nextInt(NUM_ROWS);
         if (checkerBoard[x][y] == EMPTY)
         {
            checkerBoard[x][y] = RED_CHECKER;
            number++;
         }
      }

      // create black checkers
      number = 0;
      while (number < NUM_BLACK)
      {
         int x = gen.nextInt(NUM_ROWS);
         int y = gen.nextInt(NUM_ROWS);
         if (checkerBoard[x][y] == EMPTY)
         {
            checkerBoard[x][y] = BLACK_CHECKER;
            number++;
         }
      }
   }

   //-----------------------------------------------------------------
   //  Draws the checkerboard
   //-----------------------------------------------------------------
   public void paint(Graphics page)
   {
      int size;
      if (getWidth() < getHeight())
         size = getHeight();
      else
         size = getWidth();

      size = size / NUM_ROWS;

      int j;

      for (int i=0; i<NUM_ROWS; i++)
         for (j=0; j<NUM_ROWS; j++)
         {
            if (checkerBoard[i][j] == BLACK)
            {
               page.setColor(Color.darkGray);
               page.fillRect(j*size, i*size, size, size);
            }
            else
            {
               page.setColor(Color.red);
               page.fillRect(j*size, i*size, size, size);

               page.setColor(Color.black);
               if (checkerBoard[i][j] == RED_CHECKER)
                  page.drawOval(j*size + INSET, i*size + INSET,
                                 size - INSET*2, size - INSET*2);

               if (checkerBoard[i][j] == BLACK_CHECKER)
                  page.fillOval(j*size + INSET, i*size + INSET,
                                 size - INSET*2, size - INSET*2);
            }
         }
   }
}