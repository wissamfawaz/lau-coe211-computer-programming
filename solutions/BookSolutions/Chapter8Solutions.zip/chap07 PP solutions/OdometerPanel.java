//********************************************************************
//  OdometerPanel.java       Author: Lewis and Loftus
//
//  Solution to Programming Project 7.23 (5E, p. 435)
//********************************************************************

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.text.DecimalFormat;

public class OdometerPanel extends JPanel
{
   private final int APPLET_WIDTH = 300;
   private final int APPLET_HEIGHT = 300;

   private double totalDistance;
   private Point current = null, previous = null;
   private DecimalFormat fmt;

   //-----------------------------------------------------------------
   //  Initializes the panel
   //-----------------------------------------------------------------
   public OdometerPanel ()
   {
      OdometerListener listener = new OdometerListener();
      addMouseListener (listener);
      addMouseMotionListener (listener);

      totalDistance = 0.0;

      fmt = new DecimalFormat ("0.#");

      setBackground (Color.black);
   }

   //------------------------------------------------------------------
   //  Displays the distance the mouse has traveled.
   //------------------------------------------------------------------
   public void paintComponent (Graphics page)
   {
      super.paintComponent (page);
      page.setColor(Color.green);
      String result = "Distance: " + fmt.format(totalDistance);
      page.drawString (result, 100, 100);
   }

   //*****************************************************************
   //  Represents the listener for the mouse
   //*****************************************************************
   private class OdometerListener implements MouseListener,
                                             MouseMotionListener
   {
      //--------------------------------------------------------------
      //  Updates the odometer value based on the current position
      //  of the mouse.
      //--------------------------------------------------------------
      public void mouseMoved (MouseEvent event)
      {
         current = event.getPoint();

         if(current != null && previous != null)
         {
            int xDelta = current.x - previous.x;
            int yDelta = current.y - previous.y;
            double distance = Math.sqrt( Math.pow(xDelta, 2) +
                                         Math.pow(yDelta, 2) );
            totalDistance += distance;
         }

         previous = current;
         repaint();
      }

      //--------------------------------------------------------------
      //  Determines where the mouse entered the applet.
      //--------------------------------------------------------------
      public void mouseEntered (MouseEvent event)
      {
         previous = event.getPoint();
      }

      //------------------------------------------------------------------
      //  Provides empty definitions for unused event methods.
      //------------------------------------------------------------------
      public void mouseClicked (MouseEvent event) {}
      public void mouseReleased (MouseEvent event) {}
      public void mouseExited (MouseEvent event) {}
      public void mousePressed (MouseEvent event) {}
      public void mouseDragged (MouseEvent event) {}
   }
}
