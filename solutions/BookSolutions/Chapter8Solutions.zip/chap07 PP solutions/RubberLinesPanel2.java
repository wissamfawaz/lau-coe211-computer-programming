//********************************************************************
//  RubberLinesPanel2.java       Author: Lewis and Loftus
//
//  Solution to Programming Project 7.19 (5E, p. 435)
//********************************************************************

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.Vector;

public class RubberLinesPanel2 extends JPanel
{
   private Point point1 = null, point2 = null;
   private Vector lines;

   //-----------------------------------------------------------------
   //  Sets up the applet to listen for mouse events.
   //-----------------------------------------------------------------
   public RubberLinesPanel2()
   {
      lines = new Vector();

      LineListener listener = new LineListener();
      addMouseListener (listener);
      addMouseMotionListener (listener);

      setBackground (Color.black);
   }

   //-----------------------------------------------------------------
   //  Draws the current line from the intial mouse down point to
   //  the current position of the mouse.
   //-----------------------------------------------------------------
   public void paintComponent (Graphics page)
   {
      super.paintComponent (page);

      page.setColor (Color.green);
      if (point1 != null && point2 != null)
         page.drawLine (point1.x, point1.y,
                        point2.x, point2.y);

      Line draw;
      Point from, to;
      for (int index = 0; index < lines.size (); index++)
      {
         draw = (Line) (lines.get (index));
         from = draw.getOne ();
         to = draw.getTwo ();

         page.drawLine (from.x, from.y, to.x, to.y);
      }

   }

   //*****************************************************************
   //  Represents the listener for all mouse events.
   //*****************************************************************
   private class LineListener implements MouseListener,
                                         MouseMotionListener
   {
      //--------------------------------------------------------------
      //  Captures the initial position at which the mouse button is
      //  pressed.
      //--------------------------------------------------------------
      public void mousePressed (MouseEvent event)
      {
         point1 = event.getPoint();
      }

      //--------------------------------------------------------------
      //  Gets the current position of the mouse as it is dragged and
      //  draws the line to create the rubberband effect.
      //--------------------------------------------------------------
      public void mouseDragged (MouseEvent event)
      {
         point2 = event.getPoint();
         repaint();
      }

      //--------------------------------------------------------------
      //  Adds the current line to the list of lines.
      //--------------------------------------------------------------
      public void mouseReleased (MouseEvent event)
      {
         Line newLine = new Line (point1, event.getPoint());
         lines.add (newLine);
      }

      //--------------------------------------------------------------
      //  Provide empty definitions for unused event methods.
      //--------------------------------------------------------------
      public void mouseClicked (MouseEvent event) {}
      public void mouseEntered (MouseEvent event) {}
      public void mouseExited (MouseEvent event) {}
      public void mouseMoved (MouseEvent event) {}
   }
}
