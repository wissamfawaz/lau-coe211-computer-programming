//********************************************************************
//  SpaceShipPanel.java       Author: Lewis and Loftus
//
//  Solution to Programming Project 7.25 (5E, p. 435)
//********************************************************************

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class SpaceShipPanel extends JPanel
{
   SpaceShip ship;

   //-----------------------------------------------------------------
   //  Sets up the panel. Assumes there is never more than 100
   //  points clicked
   //-----------------------------------------------------------------
   public SpaceShipPanel ()
   {
      setBackground (Color.black);

      ship = new SpaceShip();

      MouseMoveListener monitor = new MouseMoveListener();
      addMouseMotionListener (monitor);
      addMouseListener(monitor);
   }

   //-----------------------------------------------------------------
   //  Draws the space ship
   //-----------------------------------------------------------------
   public void paintComponent (Graphics page)
   {
      super.paintComponent(page);
      ship.draw(page, getWidth());
   }

   //*****************************************************************
   //  Represents the listener for the mouse movements
   //*****************************************************************
   private class MouseMoveListener implements MouseMotionListener, MouseListener
   {
      //------------------------------------------------------------------
      //  Moves the ship with the mouse
      //------------------------------------------------------------------
      public void mouseMoved(MouseEvent event)
      {
         ship.move(event.getX(), event.getY());
         repaint();
      }


      public void mouseDragged (MouseEvent event)
      {
         ship.move(event.getX(), event.getY());
         repaint();
      }

      //------------------------------------------------------------------
      //  Causes the ship to shoot
      //------------------------------------------------------------------
      public void mousePressed (MouseEvent event)
      {
         ship.setShooting(true);
         repaint();
      }

      //------------------------------------------------------------------
      //  Stops the ship shooting
      //------------------------------------------------------------------
      public void mouseReleased (MouseEvent event)
      {
         ship.setShooting(false);
         repaint();
      }

      //------------------------------------------------------------------
      //  Provides empty definitions for unused event methods.
      //------------------------------------------------------------------
      public void mouseClicked (MouseEvent event) {}
      public void mouseExited (MouseEvent event) {}
      public void mouseEntered (MouseEvent event) {}
   }
}