//********************************************************************
//  Direction2.java       Author: Lewis and Loftus
//
//  Solution to Programming Project 7.27 (5E, p. 436)
//********************************************************************

import javax.swing.*;

public class Direction2 extends JApplet
{
   //-----------------------------------------------------------------
   //  Adds the display panel to the applet.
   //-----------------------------------------------------------------
   public void init()
   {
      getContentPane().add (new DirectionPanel2(this));
   }
}
