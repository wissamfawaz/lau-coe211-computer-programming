//********************************************************************
//  OverlapCircles.java       Author: Lewis/Loftus
//
//  Solution to Programming Project 7.16 (5E, p. 434)
//********************************************************************

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.Random;

public class OverlapCircles extends JApplet
{
   Circle[] circles;
   private final int NUM_CIRCLES = 20;
   private final int MAX_RADIUS = 30;
   private final int WIDTH = 400,
                     HEIGHT = 400;

   //-----------------------------------------------------------------
   //  Creates an array of Circle objects and determines which ones
   //  overlap.
   //-----------------------------------------------------------------
   public void init()
   {
      circles = new Circle[NUM_CIRCLES];
      Random gen = new Random();

      for (int i=0; i < NUM_CIRCLES; i++)
      {
         int radius = gen.nextInt(MAX_RADIUS) + 6;
         int x = gen.nextInt(WIDTH-2*radius) + radius;
         int y = gen.nextInt(HEIGHT-2*radius) + radius;

         circles[i] = new Circle(x, y, radius);

         // check for overlap with previous circles
         boolean overlap = false;
         for (int previous = 0; previous < i; previous ++)
         {
            if (circles[previous].overlap(circles[i]))
            {
               circles[previous].setColor(Color.cyan);
               overlap = true;
            }
         }
         if (overlap)
            circles[i].setColor(Color.cyan);
      }

      setBackground(Color.white);
   }

   //-----------------------------------------------------------------
   //  Paints the set of cirles.
   //-----------------------------------------------------------------
   public void paint (Graphics page)
   {
      for (int i = 0; i<circles.length; i++)
         circles[i].draw(page);
   }
}