//********************************************************************
//  DrawStars.java       Author: Lewis and Loftus
//
//  Solution to Programming Project 7.12 (5E, p. 434)
//********************************************************************

import javax.swing.JApplet;
import java.awt.Color;
import java.awt.Point;
import java.awt.Graphics;
import java.util.Random;

public class DrawStars extends JApplet
{
   private final int APPLET_WIDTH = 200;
   private final int APPLET_HEIGHT = 200;

   private Random gen = new Random ();

   //-----------------------------------------------------------------
   //  Draws several stars of random size and color in random
   //  locations.
   //-----------------------------------------------------------------
   public void paint (Graphics page)
   {
      setBackground (Color.black);
      Star star;
      int radius, red, green, blue, xCenter, yCenter;
      Color color;
      Point center;

      for (int count = 1; count <= 10; count++)
      {
         radius = gen.nextInt(10) + 10;

         red = gen.nextInt (156) + 100;
         green = gen.nextInt (156) + 100;
         blue = gen.nextInt (156) + 100;
         color = new Color (red, green, blue);

         xCenter = gen.nextInt (180) + 10;
         yCenter = gen.nextInt (180) + 10;
         center = new Point (xCenter, yCenter);

         star = new Star (radius, color);
         star.draw (center, page);
      }
   }
}
