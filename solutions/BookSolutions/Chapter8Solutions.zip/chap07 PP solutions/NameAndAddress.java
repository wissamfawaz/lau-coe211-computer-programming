//******************************************************************************
//  NameAndAddress.java       Author: Lewis and Loftus
//
//  Solution to Programming Project 7.9 (5E, p. 433)
//******************************************************************************

import java.text.*;

public class NameAndAddress
{
   private String firstName = "";
   private String lastName = "";
   private String address = "";
   private String city = "";
   private String state = "";
   private int zipCode;
   private long phoneNum;
   private static DecimalFormat form = new DecimalFormat("00000");
   
   //---------------------------------------------------------------------------
   //  Sets up this entry with the specified data.
   //---------------------------------------------------------------------------
   public NameAndAddress (String fName, String lName, String addr, 
                          String cit, String st, int zCode, long pNum)
   {
      firstName = fName;
      lastName = lName;
      address = addr;
      city = cit;
      state = st;
      zipCode = zCode;
      phoneNum = pNum;
   }

   //---------------------------------------------------------------------------
   //  Returns the string value of firstName
   //---------------------------------------------------------------------------
   public String getFName () 
   {
      return firstName;
   }

   //---------------------------------------------------------------------------
   //  Returns the string value of lastName
   //---------------------------------------------------------------------------
   public String getLName () 
   {
      return lastName;
   }

   //---------------------------------------------------------------------------
   //  Returns the int value of zipCode
   //---------------------------------------------------------------------------
   public int getZCode () 
   {
      return zipCode;
   }

   //---------------------------------------------------------------------------
   //  Returns the int value of address
   //---------------------------------------------------------------------------
   public String getAddress () 
   {
      return address;
   }

   //---------------------------------------------------------------------------
   //  Returns the int value of city
   //---------------------------------------------------------------------------
   public String getCity () 
   {
      return city;
   }

   //---------------------------------------------------------------------------
   //  Returns the int value of state
   //---------------------------------------------------------------------------
   public String getState () 
   {
      return state;
   }
 
   //---------------------------------------------------------------------------
   //  Returns the int value of zipCode
   //---------------------------------------------------------------------------
   public long getPhone () 
   {
      return phoneNum;
   }

   //---------------------------------------------------------------------------
   //  Returns the address book entry in a multiple line format
   //---------------------------------------------------------------------------
   public String toString () 
   {
      return firstName + " " + lastName + "\n" + address + "\n" + city + ", " +
             state + " " + form.format(zipCode) + "\n" + phoneNum + "\n";
   }
}
