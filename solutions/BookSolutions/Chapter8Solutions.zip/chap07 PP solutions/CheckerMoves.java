//********************************************************************
//  CheckerMoves.java       Author: Lewis and Loftus
//
//  Solution to Programming Project 7.18 (5E, p. 434)
//********************************************************************

import javax.swing.JApplet;
import java.awt.Graphics;
import java.awt.Color;
import java.util.Random;

public class CheckerMoves extends JApplet
{
   int[][] checkerBoard;

   private final int NUM_ROWS = 8,
                     NUM_RED = 5,
                     NUM_BLACK = 8,
                     BLACK = -1,
                     EMPTY = 0,
                     RED_CHECKER = 1,
                     BLACK_CHECKER = 2,
                     INSET = 5,
                     STRING_OFFSET = 50,
                     LABEL_OFFSET = 10;

   private String[] rowLabels = {"a", "b", "c", "d", "e", "f", "g", "h" };

   //-----------------------------------------------------------------
   //  Creates a checkboard and adds checkers in random positions
   //-----------------------------------------------------------------
   public void init()
   {
      checkerBoard = new int[NUM_ROWS][NUM_ROWS];
      int j;
      for (int i=0; i<NUM_ROWS; i++)
         for (j=0; j<NUM_ROWS; j++)
            if ((i % 2 == 0) == (j % 2 == 0))
               checkerBoard[i][j] = BLACK;
            else
               checkerBoard[i][j] = EMPTY;
      populateBoard();
   }

   //-----------------------------------------------------------------
   //  Generates random checkers
   //-----------------------------------------------------------------
   public void populateBoard()
   {
      Random gen = new Random();

      int number = 0;
      // create red checkers
      while (number < NUM_RED)
      {
         int x = gen.nextInt(NUM_ROWS);
         int y = gen.nextInt(NUM_ROWS);
         if (checkerBoard[x][y] == EMPTY)
         {
            checkerBoard[x][y] = RED_CHECKER;
            number++;
         }
      }

      // create black checkers
      number = 0;
      while (number < NUM_BLACK)
      {
         int x = gen.nextInt(NUM_ROWS);
         int y = gen.nextInt(NUM_ROWS);
         if (checkerBoard[x][y] == EMPTY)
         {
            checkerBoard[x][y] = BLACK_CHECKER;
            number++;
         }
      }
   }

   //-----------------------------------------------------------------
   //  Finds valid jumps for black checkers and returns them in a string
   //-----------------------------------------------------------------
   public String getMovesString()
   {
      String move = "";

      int j;
      for (int i=0; i<NUM_ROWS; i++)
         for (j=0; j<NUM_ROWS; j++)
            if (checkerBoard[i][j] == BLACK_CHECKER)
            {
               int up = i-1 > 0 ? i-1 : i;
               int left = j-1 > 0 ? j-1 : j;
               int right = j+1 < NUM_ROWS ? j+1 : j;

               // look for moves up and left
               if (checkerBoard[up][left] == RED_CHECKER)
               {
                  int landUp = up-1 >= 0 ? up-1 : up;
                  int landLeft = left-1 >= 0 ? left-1 : left;

                  if (checkerBoard[landUp][landLeft] == EMPTY)
                     move +=  rowLabels[j] + String.valueOf(NUM_ROWS - i)
                                + " jump up & left; ";
               }
               // look for moves up and right
               if (checkerBoard[up][right] == RED_CHECKER)
               {
                  int landUp = up-1 >= 0 ? up-1 : up;
                  int landRight = right+1 < NUM_ROWS ? right+1 : right;

                  if (checkerBoard[landUp][landRight] == EMPTY)
                     move +=  rowLabels[j] + String.valueOf(NUM_ROWS- i)
                                + " jump up & right; ";
               }
            }

      return move;
   }

   //-----------------------------------------------------------------
   //  Draws the checkerboard
   //-----------------------------------------------------------------
   public void paint(Graphics page)
   {
      int size;
      if (getWidth() - 2*LABEL_OFFSET > getHeight() + 2* LABEL_OFFSET - STRING_OFFSET)
         size = getHeight() - STRING_OFFSET - 2 * LABEL_OFFSET;
      else
         size = getWidth() - 2 * LABEL_OFFSET;

      size = size / NUM_ROWS;

      int j;
      // draw the board;
      for (int i=0; i<NUM_ROWS; i++)
         for (j=0; j<NUM_ROWS; j++)
         {
            if (checkerBoard[i][j] == BLACK)
            {
               page.setColor(Color.darkGray);
               page.fillRect(j*size, i*size, size, size);
            }
            else
            {
               page.setColor(Color.red);
               page.fillRect(j*size, i*size, size, size);

               page.setColor(Color.black);
               if (checkerBoard[i][j] == RED_CHECKER)
                  page.drawOval(j*size + INSET, i*size + INSET,
                                 size - INSET*2, size - INSET*2);

               if (checkerBoard[i][j] == BLACK_CHECKER)
                  page.fillOval(j*size + INSET, i*size + INSET,
                                 size - INSET*2, size - INSET*2);
            }
         }
      // draw row labels
      for (int i = 0; i < NUM_ROWS; i++)
         page.drawString(rowLabels[i], i*size+LABEL_OFFSET, size*NUM_ROWS+LABEL_OFFSET);

      // draw column labels
      for (int i = 0; i < NUM_ROWS; i++)
         page.drawString(" " + String.valueOf(NUM_ROWS-i), size*NUM_ROWS, i*size+LABEL_OFFSET*2);

      // draw the move string
      page.drawString(getMovesString(), 0,size*NUM_ROWS + STRING_OFFSET);
   }
}