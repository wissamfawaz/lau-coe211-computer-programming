//********************************************************************
//  StatisticsDriver.java       Author: Lewis and Loftus
//
//  Solution to Programming Project 7.5 (5E, p. 432)
//********************************************************************

import java.util.Random;
import java.text.DecimalFormat;

public class StatisticsDriver
{
   private static final int MAX_COUNT = 50, MAX_VALUE = 100;

   //-----------------------------------------------------------------
   //  Demonstrates the mean and standard deviation methods.
   //-----------------------------------------------------------------
   public static void main (String args[])
   {
      DecimalFormat formatter = new DecimalFormat("#0.000");

      Random gen = new Random();

      int[] numbers = new int[MAX_COUNT];

      int count = gen.nextInt(MAX_COUNT) + 1;

      // create random numbers
      for (int i=0; i < count; i++)
         numbers[i] = gen.nextInt(MAX_VALUE) + 1;

      System.out.println("Count: " + count);
      System.out.println("Mean: " + 
         formatter.format(Statistics.mean(numbers, count)));
      System.out.println("Standard Deviation: " +
         formatter.format(Statistics.standardDeviation(numbers, count)));
   }
}