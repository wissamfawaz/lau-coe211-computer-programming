//********************************************************************
//  CountIntegers2.java       Author: Lewis and Loftus
//
//  Solution to Programming Project 7.2 (5E, p. 431)
//********************************************************************

import java.util.Scanner;

public class CountIntegers2
{
   public static void main (String [] args)
   {
      int [] occurrences = new int [51];

      System.out.println ("Enter integers in the range -25 to 25.");
      System.out.println ("Signal end of list with a number outside " +
          "the range.");
	  
	  Scanner scan = new Scanner (System.in);

      int entered = scan.nextInt ();
      while (entered >= -25 && entered <= 25)
      {
         occurrences[entered + 25]++;
         entered = scan.nextInt ();
      }

      // report all integers that were entered one or more times
      System.out.println ("Number\tTimes");
      for (int check = -25; check <= 25; check++)
         if (occurrences [check+25] >= 1)
            System.out.println (check + "\t" + occurrences [check+25]);
   }
}
