//********************************************************************
//  Complexity.java       Author: Lewis and Loftus
//
//  Solution to Programming Project 7.10 and 7.11 (5E, p. 433 and 434)
//********************************************************************

public interface Complexity
{
   public void setComplexity (int complexity);
   public int getComplexity();
}
