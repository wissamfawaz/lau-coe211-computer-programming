//******************************************************************************
//  NameAndZipList.java       Author: Lewis and Loftus
//
//  Solution to Programming Project 7.8 (5E, p. 433)
//******************************************************************************

import java.io.*;
import java.util.*;

public class NameAndZipList
{
	public static final int MAX = 25;
	
   //---------------------------------------------------------------------------
   //  Reads names and zip codes from the input file and prints the results.
   //---------------------------------------------------------------------------
   public static void main (String[] args)
   {
	 try
	 {
		 Scanner scan = new Scanner(new File("contacts.dat"));
		 NameAndZip[] contacts = new NameAndZip[MAX];
         int count = 0;
	
		 // Read the data from the input file
		 while (scan.hasNext())
		 {
			String firstName = scan.next();
			String lastName = scan.next();
			int zipCode = scan.nextInt();
			contacts[count] = new NameAndZip(firstName, lastName, zipCode);
			System.err.println(contacts[count]);
			count++;
		 }
	
		 // Print the processed data to the screen.
		 for (int index = 0; index < count; index++)
			System.out.println(contacts[index]);
			
         System.out.println ("\nTotal: " + count);
	 }
	 catch (Exception except)
	 {
		 System.err.println(except);
	 }
   }
}