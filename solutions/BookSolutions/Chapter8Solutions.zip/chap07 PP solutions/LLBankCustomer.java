//********************************************************************
//  LLBankCustomer.java             Author: Lewis and Loftus
//
//  Solution to Programming Project 7.6 (5E, p. 433)
//********************************************************************

import java.text.NumberFormat;

public class LLBankCustomer
{
   private long account;
   private String name, phone;
   private double balance;

   //-----------------------------------------------------------------
   //  Sets up the customer with the specified information.
   //-----------------------------------------------------------------
   public LLBankCustomer (long newAccount, String newName,
                          String newPhone, double newBalance)
   {
      account = newAccount;
      name = newName;
      phone = newPhone;
      balance = newBalance;
   }

   //-----------------------------------------------------------------
   //  Returns the account number.
   //-----------------------------------------------------------------
   public long getAccount ()
   {
      return account;
   }

   //-----------------------------------------------------------------
   //  Sets the balance as specified.
   //-----------------------------------------------------------------
   public void setBalance (double newBalance)
   {
      balance = newBalance;
   }

   //-----------------------------------------------------------------
   //  Returns the current balance.
   //-----------------------------------------------------------------
   public double getBalance ()
   {
      return balance;
   }

   //-----------------------------------------------------------------
   //  Returns this customer's information as a string.
   //-----------------------------------------------------------------
   public String toString ()
   {
      NumberFormat formatter = NumberFormat.getCurrencyInstance();

      return account + "\t" + name + "\t" + 
             formatter.format(balance) + "\t" + phone;
   }
}
