//********************************************************************
//  Star.java       Author: Lewis and Loftus
//
//  Solution to Programming Project 7.12 (5E, p. 434)
//********************************************************************

import java.awt.Color;
import java.awt.Point;
import java.awt.Graphics;

public class Star
{
   private int radius = 10;
   private Color color = Color.yellow;

   //-----------------------------------------------------------------
   //  Sets up the star with a specified radius and color.
   //-----------------------------------------------------------------
   public Star (int r, Color c)
   {
      radius = r;
      color = c;
   }

   //-----------------------------------------------------------------
   //  Draw the star on the specified Graphics object with the
   //  specified center point.
   //-----------------------------------------------------------------
   public void draw (Point center, Graphics page)
   {
      int[] x = new int [12];
      int[] y = new int [12];

      int oneThird = radius/3;
      int half = radius/2;
      int twoThirds = radius*2/3;

      int centerX = center.x;
      int centerY = center.y;

      x[0] = centerX;               y[0] = centerY - radius;
      x[1] = centerX + oneThird;    y[1] = centerY - oneThird;
      x[2] = centerX + twoThirds;   y[2] = centerY - twoThirds;
      x[3] = centerX + half;        y[3] = centerY;
      x[4] = centerX + twoThirds;   y[4] = centerY + twoThirds;
      x[5] = centerX + oneThird;    y[5] = centerY + oneThird;
      x[6] = centerX;               y[6] = centerY + radius;
      x[7] = centerX - oneThird;    y[7] = centerY + oneThird;
      x[8] = centerX - twoThirds;   y[8] = centerY + twoThirds;
      x[9] = centerX - half;        y[9] = centerY;
      x[10] = centerX - twoThirds;  y[10] = centerY - twoThirds;
      x[11] = centerX - oneThird;   y[11] = centerY - oneThird;

      page.setColor (color);
      page.fillPolygon (x, y, x.length);
   }
}
