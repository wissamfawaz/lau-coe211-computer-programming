//********************************************************************
//  CountIntegers.java       Author: Lewis and Loftus
//
//  Solution to Programming Project 7.1 (5E, p. 431)
//********************************************************************

import java.util.Scanner;

public class CountIntegers
{
   public static void main (String [] args)
   {
      int [] occurrences = new int[51];

      System.out.println ("Enter integers in the range 0-50.");
      System.out.println ("Signal end of list with a number outside " +         
         "the range.");
	  
	  Scanner scan = new Scanner (System.in);

      int entered = scan.nextInt ();
      while (entered >= 0 && entered <= 50)
      {
         occurrences [entered] ++;
         entered = scan.nextInt ();
      }

      // report all integers that were entered one or more times
      System.out.println ("Number\tTimes");
      for (int check = 0; check <= 50; check++)
         if (occurrences [check] >= 1)
            System.out.println (check + "\t" + occurrences [check]);
   }
}
