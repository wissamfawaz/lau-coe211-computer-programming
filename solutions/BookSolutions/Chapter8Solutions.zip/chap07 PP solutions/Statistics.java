//********************************************************************
//  Statistics.java       Author: Lewis and Loftus
//
//  Solution to Programming Project 7.5 (5E, p. 432)
//********************************************************************

public class Statistics
{
   //-----------------------------------------------------------------
   //  Computes the mean of the set of integers stored in the
   //  specified array.
   //-----------------------------------------------------------------
   public static double mean (int[] numbers, int count)
   {
      double sum = 0.0;

      for (int i=0; i < count; i++)
         sum += numbers[i];

      return sum / count;
   }

   //-----------------------------------------------------------------
   //  Computes the standard deviation of the set of integers stored
   //  in the specified array.
   //-----------------------------------------------------------------
   public static double standardDeviation (int[] numbers, int count)
   {
      double result = 0.0;
      double mean = mean(numbers, count);

      // compute summation
      for (int i=0; i < count; i++)
         result += Math.pow (numbers[i] - mean, 2);

      return Math.sqrt (result / count-1);
   }
}
