//********************************************************************
//  QuizTime2.java       Author: Lewis and Loftus
//
//  Solution to Programming Project 7.11 (5E, p. 434)
//********************************************************************

public class QuizTime2
{
   public static void main(String[] args)
   {
      Quiz2 q = new Quiz2();

      Question temp;

      temp = new Question ("What is the wind speed flight velocity of a swallow?",
                              "African or European?");
      temp.setComplexity(2);
      q.add(temp);

      temp = new Question ("What color was George Washington's white horse?",
                              "white");
      temp.setComplexity(1);
      q.add(temp);

      temp = new Question ("How much wood could a woodchuck chuck?",
                           "Wouldn't know");
      temp.setComplexity(2);
      q.add(temp);

      temp = new Question ("What's my favorite programming language?",
                           "Java");
      temp.setComplexity(1);
      q.add(temp);

      temp = new Question ("What is the capital of Bolivia?",
                           "La Paz");
      temp.setComplexity(4);
      q.add(temp);

      temp = new Question ("How many moons does the planet Venus have?",
                           "zero");
      temp.setComplexity(4);
      q.add(temp);

      temp = new Question ("Outside of the USA, what is the largest software producing country?",
                           "Ireland");
      temp.setComplexity(4);
      q.add(temp);

      temp = new Question ("What country is Mt. Everest located in?",
                           "Nepal");
      temp.setComplexity(3);
      q.add(temp);

      q.giveQuiz(3,5);

      System.out.print("\nResults:\n\tCorrect: " + q.getNumCorrect());
      System.out.println("\tIncorrect: " + q.getNumIncorrect());
   }
}