//********************************************************************
//  Odometer.java       Author: Lewis and Loftus
//
//  Solution to Programming Project 7.23 (5E, p. 435)
//********************************************************************

import javax.swing.JApplet;

public class Odometer extends JApplet
{
   public void init ()
   {
      getContentPane().add(new OdometerPanel());
   }
}
