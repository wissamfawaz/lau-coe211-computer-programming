//********************************************************************
//  SpaceShipTest.java       Author: Lewis and Loftus
//
//  Solution to Programming Project 7.25 (5E, p. 435)
//********************************************************************

import javax.swing.JApplet;


public class SpaceShipTest extends JApplet
{
   //-----------------------------------------------------------------
   //  Sets up the applet.
   //-----------------------------------------------------------------
   public void init ()
   {
      getContentPane().add(new SpaceShipPanel());
   }
}




