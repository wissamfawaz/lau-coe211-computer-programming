//******************************************************************************
//  NameAndAddressList.java       Author: Lewis and Loftus
//
//  Solution to Programming Project 7.9 (5E, p. 433)
//******************************************************************************

import java.io.*;
import java.util.*;

public class NameAndAddressList
{
	public static final int MAX = 25;
	
   //---------------------------------------------------------------------------
   //  Reads the contact data from the input file and prints the results.
   //---------------------------------------------------------------------------
   public static void main (String[] args)
   {
	 try
	 {
		 Scanner scan = new Scanner(new File("contacts2.dat"));
		 scan.useDelimiter(";");
		 ArrayList<NameAndAddress> contacts = 
		      	new ArrayList<NameAndAddress>(MAX);
	
		 // Read the data from the input file
		 while (scan.hasNext()) 
		 {
			String firstName = scan.next();
			String lastName = scan.next();
			String address = scan.next();
			String city = scan.next();
			String state = scan.next();
			int zipCode = scan.nextInt();
			long phoneNum = scan.nextLong();
			NameAndAddress entry = new NameAndAddress(firstName, lastName, address,
					city, state, zipCode, phoneNum);
			contacts.add(entry);
		 }
	
		 // Prints the processed data to the screen.
		 for (int index = 0; index < contacts.size(); index++)
			System.out.println(contacts.get(index));
			
         System.out.println ("Total: " + contacts.size());
	 }
	 catch (Exception except)
	 {
		 System.err.println(except);
	 }
   }
}
