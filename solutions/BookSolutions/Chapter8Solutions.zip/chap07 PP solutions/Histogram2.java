//********************************************************************
//  Histogram2.java         Author: Lewis and Loftus
//
//  Solution to Programming Project 7.4 (5E, p. 432)
//********************************************************************

import java.util.Scanner;

public class Histogram2
{
   public static void main (String [] args)
   {
      int[] ranges = new int [10];
      int box;

	  Scanner scan = new Scanner (System.in);

      System.out.println ("Enter some numbers between 1 and 100.");
      System.out.println ("Signal the end by entering a number outside " +
         "of that range");

      int entered = scan.nextInt ();
      while (entered >= 1 && entered <= 100)
      {
         box = (entered - 1) / 10;
         ranges[box] ++;
         entered = scan.nextInt ();
      }

      // print histogram - a star for every 5 elements
      for (box = 0; box < 10; box++)
      {
         System.out.print ((10 * box + 1) + "-");
         System.out.print ((10 * box + 10) + "\t|");
         for (int count = 5; count <= ranges[box]; count += 5)
            System.out.print ("*");
         System.out.println ();
      }
   }
}
