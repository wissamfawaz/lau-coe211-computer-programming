//********************************************************************
//  RubberLines2.java       Author: Lewis and Loftus
//
//  Solution to Programming Project 7.19 (5E, p. 435)
//********************************************************************

import javax.swing.*;

public class RubberLines2 extends JApplet
{
   private final int WIDTH = 300, HEIGHT = 200;

   //-----------------------------------------------------------------
   //  Sets up the applet to contain the drawing panel.
   //-----------------------------------------------------------------
   public void init()
   {
      getContentPane().add (new RubberLinesPanel2());

      setSize (WIDTH, HEIGHT);
   }
}
