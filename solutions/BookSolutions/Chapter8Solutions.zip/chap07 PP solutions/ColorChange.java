//********************************************************************
//  ColorChange.java       Author: Lewis and Loftus
//
//  Solution to Programming Project 7.24 (5E, p. 435)
//********************************************************************

import javax.swing.JApplet;

public class ColorChange extends JApplet
{
   public void init()
   {
      getContentPane().add(new ColorChangePanel());
   }
}

