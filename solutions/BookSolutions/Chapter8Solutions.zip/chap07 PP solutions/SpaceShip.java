//********************************************************************
//  SpaceShip.java       Author: Lewis and Loftus
//
//  Solution to Programming Project 7.25 (5E, p. 435)
//********************************************************************

import java.awt.Graphics;
import java.awt.Color;
import java.awt.Polygon;

public class SpaceShip
{
   private int x, y;
   private boolean shooting;
   private final int WIDTH = 40,
                     HEIGHT = 20;

   //------------------------------------------------------------------
   //  Moves the ship
   //------------------------------------------------------------------
   public void move(int xPos, int yPos)
   {
      x = xPos;
      y = yPos;
   }

   //------------------------------------------------------------------
   //  Sets the shooting mode of the ship
   //------------------------------------------------------------------
   public void setShooting(boolean value)
   {
      shooting = value;
   }

   //------------------------------------------------------------------
   //  Draws the ship using the graphics context page.  If ship is
   //  in shooting mode, draw laser.
   //------------------------------------------------------------------
   public void draw(Graphics page, int screenWidth)
   {
      int baseX = x-WIDTH;
      int baseY = y - HEIGHT/2;

      // antennae
      page.setColor(Color.green);
      page.drawLine(baseX + 10, baseY-10, baseX + WIDTH/2, y + HEIGHT/2);
      page.drawLine(baseX + WIDTH/2, y + HEIGHT/2, x - 10, baseY-10);

      // body
      page.setColor(Color.orange);
      page.fillArc(baseX, baseY, WIDTH, HEIGHT, 0, 180);

      page.setColor(Color.magenta);
      page.fillArc(baseX, baseY, WIDTH, HEIGHT, 0, -180);

      page.setColor(Color.blue);

      // windows
      for (int i = 0; i<4; i++)
         page.fillOval(baseX +(i+1)*7, baseY + 8, 6, 6);

      // laser
      if (shooting)
      {
         page.setColor(Color.yellow);
         page.drawLine(x, y, screenWidth, y);
      }
   }
}