This folder contains solutions to the Programming Projects from
Chapter 7 of Java Software Solutions, 5th Ed, by Lewis and Loftus.

Project     File(s)
-------     -------

7.1        CountIntegers.java

7.2        CountIntegers2.java

7.3        Histogram.java

7.4        Histogram2.java

7.5        Statistics.java
           StatisticsDriver.java

7.6        LLBankDriver.java
           LLBank.java
           LLBankCustomer.java

7.7        DeckOfCards.java
           Card.java
           CardDriver.java

7.8        NameAndZip.java
           NameAndZipList.java
           contacts.dat

7.9        NameAndAddress.java
           NameAndAddressList.java
           contacts2.dat

7.10       QuizTime.java
           Quiz.java
           Question.java
           Complexity.java

7.11       QuizTime2.java
           Quiz2.java
           Question.java
           Complexity.java

7.12       DrawStars.java
           Star.java
           DrawStars.html

7.13       CarTest.java
           Car.java
           CarTest.html
		
7.14       CarTest2.java
           Car2.java
           CarTest2.html

7.15       QuoteOptions3.java
           QuoteGUI3.java
		
7.16       OverlapCircles.java
           Circle.java
           OverlapCircles.html

7.17       Checkers.java
           Checkers.html

7.18       CheckerMoves.java
           CheckerBoardMoves.html

7.19       RubberLines2.java
           RubberLinesPanel2.java
           Line.java
           RubberLines2.html

7.20       CountClicks.java
           CountClicksPanel.java
           CountClicks.html
		
7.21       DrawPolyline.java
           DrawPolylinePanel.java
           DrawPolyline.html

7.22       RubberCircle.java
           RubberCirclePanel.java
           RubberCircle.html
		
7.23       Odometer.java
           OdometerPanel.java
           Odometer.html
		
7.24       ColorChange.java
           ColorChangePanel.java
           ColorChange.html
		
7.25       SpaceShipTest.java
           SpaceShipPanel.java
           SpaceShip.java
           SpaceShipTest.html

7.26       PatientInflow.java
           inflow.dat
           MakeInflowFile.java (support)

7.27       Direction2.java
           DirectionPanel2.java
           Direction2.html
           (plus arrow images)

7.28       Direction3.java
           DirectionPanel3.java
           Direction3.html
           (plus arrow images)



