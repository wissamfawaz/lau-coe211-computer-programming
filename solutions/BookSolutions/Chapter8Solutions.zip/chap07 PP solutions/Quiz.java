//********************************************************************
//  Quiz.java       Author: Lewis and Loftus
//
//  Solution to Programming Project 7.10 (5E, p. 433)
//********************************************************************

import java.util.Scanner;

public class Quiz
{
   private final int MAX_QUESTIONS = 25;

   private Question[] questions;
   private int current, correct, incorrect;

   //-----------------------------------------------------------------
   //  Sets up an initially empty quiz.
   //-----------------------------------------------------------------
   public Quiz()
   {
      questions = new Question[MAX_QUESTIONS];
      current = 0;
      correct = incorrect = 0;
   }

   //-----------------------------------------------------------------
   //  Adds the specified question to this quiz.
   //-----------------------------------------------------------------
   public void add (Question newQuestion)
   {
      if (current < MAX_QUESTIONS)
         questions[current++] = newQuestion;
   }

   //-----------------------------------------------------------------
   //  Administers this quiz.
   //-----------------------------------------------------------------
   public void giveQuiz()
   {
      Scanner scan = new Scanner (System.in);
	  
	  for (int i = 0; i < current; i++)
	  {
         System.out.println(questions[i].getQuestion());
         if (questions[i].answerCorrect(scan.nextLine()))
            correct++;
         else
            incorrect++;

      }
   }

   //-----------------------------------------------------------------
   //  Returns the number of correct answers.
   //-----------------------------------------------------------------
   public int getNumCorrect()
   {
      return correct;
   }

   //-----------------------------------------------------------------
   //  Returns the number of incorrect answers.
   //-----------------------------------------------------------------
   public int getNumIncorrect()
   {
      return incorrect;
   }
}
