//********************************************************************
//  QuoteGUI3.java       Author: Lewis and Loftus
//
//  Solutions to Programming Project 7.15 (5E, p. 434)
//********************************************************************

import javax.swing.*;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;

import java.awt.event.*;

public class QuoteGUI3
{
   private final int WIDTH = 550, HEIGHT = 80;
   private JPanel primary;
   private JLabel quote;
   private JRadioButton comedy, philosophy, carpentry, sciFi, einstein, work ;
   private final int COMEDY = 0,
                     PHILOSOPHY = 1,
                     CARPENTRY = 2,
                     SCIFI = 3,
                     EINSTEIN = 4,
                     WORK = 5;

   private String[] quotes = { "                    Take my wife, please.                   ",
                               "                   I think, therefore I am.                 ",
                               "                   Measure twice. Cut once.                 ",
                               "        I'm sorry Dave, I'm afraid I can't do that.         ",
                               "  Make everything as simple as possible, but not simpler.   ",
                               "I find that the harder I work, the more luck I seem to have."
                            };



   //-----------------------------------------------------------------
   //  Sets up a panel with a label and a set of radio buttons
   //  that control its text.
   //-----------------------------------------------------------------
   public QuoteGUI3()
   {
      quote = new JLabel (quotes[COMEDY]);
      quote.setFont (new Font ("Helvetica", Font.BOLD, 20));

      comedy = new JRadioButton ("Comedy",true);
      comedy.setBackground (Color.green);
      philosophy = new JRadioButton ("Philosophy");
      philosophy.setBackground (Color.green);
      carpentry = new JRadioButton ("Carpentry");
      carpentry.setBackground (Color.green);
      sciFi = new JRadioButton ("SciFi");
      sciFi.setBackground (Color.green);
      einstein = new JRadioButton ("Einstein");
      einstein.setBackground (Color.green);
      work = new JRadioButton ("Work");
      work.setBackground (Color.green);

      ButtonGroup group = new ButtonGroup();
      group.add (comedy);
      group.add (philosophy);
      group.add (carpentry);
      group.add (sciFi);
      group.add (einstein);
      group.add (work);

      QuoteListener listener = new QuoteListener();
      comedy.addActionListener (listener);
      philosophy.addActionListener (listener);
      carpentry.addActionListener (listener);
      sciFi.addActionListener (listener);
      einstein.addActionListener (listener);
      work.addActionListener (listener);

      primary = new JPanel();
      primary.add (quote);
      primary.add (comedy);
      primary.add (philosophy);
      primary.add (carpentry);
      primary.add (sciFi);
      primary.add (einstein);
      primary.add (work);
      primary.setBackground (Color.green);
      primary.setPreferredSize (new Dimension(WIDTH, HEIGHT));
   }

   //-----------------------------------------------------------------
   //  Returns the primary panel containing the GUI.
   //-----------------------------------------------------------------
   public JPanel getPanel()
   {
      return primary;
   }

   //*****************************************************************
   //  Represents the listener for all radio buttons
   //*****************************************************************
   private class QuoteListener implements ActionListener
   {
      //--------------------------------------------------------------
      //  Sets the text of the label depending on which radio
      //  button was pressed.
      //--------------------------------------------------------------
      public void actionPerformed (ActionEvent event)
      {
         Object source = event.getSource();

         if (source == comedy)
            quote.setText (quotes[COMEDY]);
         else
            if (source == philosophy)
               quote.setText (quotes[PHILOSOPHY]);
            else
               if (source == sciFi)
                  quote.setText (quotes[SCIFI]);
               else
                  if (source == einstein)
                     quote.setText (quotes[EINSTEIN]);
                  else
                     if (source == work)
                        quote.setText (quotes[WORK]);
                     else
                        quote.setText (quotes[CARPENTRY]);
      }
   }
}
