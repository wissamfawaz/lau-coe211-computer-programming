//********************************************************************
//  IntroPanel2.java       Authors: Lewis and Loftus
//
//  Solution to Programming Project 6.11 (5E, p. 368)
//********************************************************************

import java.awt.*;
import javax.swing.*;

public class IntroPanel2 extends JPanel
{
   //-----------------------------------------------------------------
   //  Sets up this panel with two labels.
   //-----------------------------------------------------------------
   public IntroPanel2()
   {
      setBackground (Color.green);

      setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));

      JLabel l1 = new JLabel ("Layout Manger Demonstration");
      JLabel l2 = new JLabel ("Choose a tab to see an example of " +
                              "a layout manager.");

      add(Box.createVerticalGlue());
      add (l1);
      add(Box.createVerticalGlue());
      add (l2);
   }
}
