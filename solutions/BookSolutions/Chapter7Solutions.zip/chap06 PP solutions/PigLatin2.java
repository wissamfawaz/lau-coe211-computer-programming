//********************************************************************
//  PigLatin2.java       Author: Lewis and Loftus
//
//  Solution to Programming Project 6.10 (5E, p. 368)
//********************************************************************

public class PigLatin2
{
   //-----------------------------------------------------------------
   //  Creates and displays the pig latin converter GUI.
   //-----------------------------------------------------------------
   public static void main (String[] args)
   {
      PigLatinGUI converter = new PigLatinGUI();
      converter.display();
   }
}
