//********************************************************************
//  BeverageOrderPanel.java       Authors: Lewis and Loftus
//
//  Solution to Programming Project 6.14 (5E, p. 368)
//********************************************************************

import java.util.ArrayList;
import javax.swing.*;
import javax.swing.border.*;
import java.awt.event.*;
import java.awt.*;
import java.text.*;

//********************************************************************
//  Helper class for representing beverages
//********************************************************************
class Beverage
{
   static final String[] BEVERAGE_TYPES = {
      "Coke",
      "Dr Pepper",
      "Sprite",
      "Lemonade",
      "Raspberry Lemonade",
      "Bottled Water"
   };

   static final float PRICE = 1.5f;

   int beverage;

   public String toString()
   {
      try
      {
         return BEVERAGE_TYPES[beverage];
      }
      catch (ArrayIndexOutOfBoundsException e)
      {
         return "";
      }
   }
}

//********************************************************************
//  Main panel for ordering beverages.
//********************************************************************
public class BeverageOrderPanel extends JPanel
{
    JTextField[] beverageQuantityTextFields;
    JLabel numBeveragesLabel;
    JLabel totalPriceLabel;
    float previousPrice;
    PizzaOrderPortal portal;

   //-----------------------------------------------------------------
   //  Set up the beverage panel GUI
   //-----------------------------------------------------------------
    public BeverageOrderPanel(PizzaOrderPortal orderPortal)
    {
       portal = orderPortal;
       previousPrice = 0.0f;
       setLayout(new BorderLayout());
       add(createBeverageList(), BorderLayout.CENTER);
       add(createOrderPanel(), BorderLayout.SOUTH);
    }

   //-----------------------------------------------------------------
   //  Create the lower panel in the beverage panel GUI
   //-----------------------------------------------------------------
   JPanel createOrderPanel()
    {
      JPanel orderPanel = new JPanel();
      orderPanel.setLayout(new BorderLayout());

      // create order button
      JButton orderButton = new JButton("Order These Beverages");
      orderButton.addActionListener(new OrderButtonListener());      // add stats
      orderPanel.add(orderButton, BorderLayout.NORTH);

      //create stat panel
      JPanel statPanel = new JPanel();
      statPanel.setLayout(new BoxLayout(statPanel, BoxLayout.Y_AXIS));
      statPanel.setBorder(new TitledBorder(new EtchedBorder(),"Current Order"));

      JPanel numBeveragesPanel = new JPanel();
      numBeveragesPanel.add(new JLabel("Number of Beverages: "));
      numBeveragesLabel = new JLabel("0");
      numBeveragesPanel.add(numBeveragesLabel);
      statPanel.add(numBeveragesPanel);

      JPanel totalPricePanel = new JPanel();
      totalPricePanel.add(new JLabel("Total Price of Beverages: "));
      totalPriceLabel = new JLabel("$0.00");
      totalPricePanel.add(totalPriceLabel);
      statPanel.add(totalPricePanel);

      orderPanel.add(statPanel, BorderLayout.CENTER);

      return orderPanel;
    }

   //-----------------------------------------------------------------
   //  Create the beverage list panel in the beverage panel GUI
   //-----------------------------------------------------------------
    JPanel createBeverageList()
    {
       int numBeverages = Beverage.BEVERAGE_TYPES.length;

       JPanel listPanel = new JPanel();
       listPanel.setLayout(new GridLayout(numBeverages+1, 2));
       listPanel.setBorder(new TitledBorder(new EtchedBorder(), "Beverages"));

       listPanel.add(new JLabel(""));
       JLabel header = new JLabel("Quantity");
       header.setHorizontalAlignment(SwingConstants.CENTER);
       listPanel.add(header);


       beverageQuantityTextFields = new JTextField[numBeverages];
       for (int i=0; i<numBeverages; i++)
       {
         listPanel.add(new JLabel(Beverage.BEVERAGE_TYPES[i]));
         JTextField quantity = new JTextField("0");
         quantity.setHorizontalAlignment(SwingConstants.CENTER);
         beverageQuantityTextFields[i] = quantity;
         listPanel.add(quantity);
       }

       JPanel outerPanel = new JPanel();
       outerPanel.add(listPanel);
       return outerPanel;
    }

   //-----------------------------------------------------------------
   //  Returns the number of beverages ordered
   //-----------------------------------------------------------------
    int getNumBeverages()
    {
      int total = 0;
      for (int i=0; i<beverageQuantityTextFields.length; i++)
      {
         try
         {
            int quantity = Integer.parseInt(beverageQuantityTextFields[i].getText());
            total += quantity;
         }
         catch (NumberFormatException e)
         {
         }
      }
      return total;
    }

   //-----------------------------------------------------------------
   //  Returns the price of the beverages ordered
   //-----------------------------------------------------------------
   float getPrice()
    {
      return getNumBeverages() * Beverage.PRICE;
    }


    //********************************************************************
    //  Represents the listener class for the order button
    //********************************************************************
    class OrderButtonListener implements ActionListener
    {
       public void actionPerformed(ActionEvent evt)
       {
          float currentPrice = getPrice();
          numBeveragesLabel.setText(String.valueOf(getNumBeverages()));
          NumberFormat money = NumberFormat.getCurrencyInstance();
          totalPriceLabel.setText(money.format(currentPrice));
          portal.updateGrandTotal(currentPrice - previousPrice);
          previousPrice = currentPrice;
       }
    }
}
