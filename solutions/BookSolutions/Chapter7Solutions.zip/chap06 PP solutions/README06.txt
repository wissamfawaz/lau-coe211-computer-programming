This folder contains solutions to the Programming Projects from
Chapter 6 of Java Software Solutions, 5th Ed, by Lewis and Loftus.

Project     File(s)
-------     -------

6.1         Account2.java
            Transactions2.java

6.2         StudentBody2.java
            Student2.java
            Address.java

6.3         School.java
            Course.java
            Student2.java
            Address.java

6.4         RationalTester2.java
            RationalNumber2.java

6.5         TaskDriver.java
            Task.java
            Priority.java

6.6         TaskDriver2.java
            Task2.java
            Priority.java
            Complexity.java

6.7         TaskDriver3.java
            Task3.java
            Priority.java
            Complexity.java

6.8         TestCoin.java
            Lockable.java
            Coin2.java

6.9         Account3.java
            Lockable.java

6.10        PigLatin2.java
            PigLatinGUI.java
            PigLatinTranslator.java

6.11		LayoutDemo2.java
            IntroPanel2.java
            BorderPanel.java
            BoxPanel.java
            GridPanel.java
            FlowPanel.java

6.12        QuoteOptions2.java
            QuoteGUI2.java

6.13        KeyPadTest.java
            NumericKeyPad.java

6.14        PizzaOrderPortal.java
            Pizza.java
            BeverageOrderPanel.java
            PizzaOrderPanel.java	
            SideOrderPanel.java 
		
		
		