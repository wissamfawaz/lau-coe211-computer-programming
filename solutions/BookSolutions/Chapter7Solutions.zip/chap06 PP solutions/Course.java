//********************************************************************
//  Course.java       Author: Lewis and Loftus
//
//  Solution to Programming Project 6.3 (5E, p. 366)
//********************************************************************

public class Course
{
   private String name;

   private int numStudents;

   private Student2 student1;
   private Student2 student2;
   private Student2 student3;
   private Student2 student4;
   private Student2 student5;

   //-----------------------------------------------------------------
   //  Sets up a Course object with the specified name.
   //-----------------------------------------------------------------
   public Course (String courseName)
   {
      name = courseName;
      numStudents = 0;
   }

   //-----------------------------------------------------------------
   //  Adds a student to the course.  If more than 5 students are
   //  enrolled, method does nothing.
   //-----------------------------------------------------------------
   public void addStudent (Student2 newStudent)
   {
      numStudents ++;
      switch (numStudents)
      {
         case 1 :
            student1 = newStudent;
            break;
         case 2 :
            student2 = newStudent;
            break;
          case 3 :
            student3 = newStudent;
            break;
         case 4 :
            student4 = newStudent;
            break;
         case 5 :
            student5 = newStudent;
            break;
         default:
            numStudents--;
      }
   }

   //-----------------------------------------------------------------
   //  Returns the average of all Student2s' test scores
   //-----------------------------------------------------------------
   public double average()
   {
      double average = 0.0;

      switch (numStudents)
      {
         case 5 : average += student5.average();
         case 4 : average += student4.average();
         case 3 : average += student3.average();
         case 2 : average += student2.average();
         case 1 : average += student1.average();
      }

      if (numStudents > 0)
        average = average / numStudents;

      return average;
   }
   //-----------------------------------------------------------------
   //  Prints out all the Student2s in the course,
   //-----------------------------------------------------------------
   public void roll()
   {
      System.out.println(name + " Class Roll");

      switch (numStudents)
      {
         case 5 : System.out.println(student5);
         case 4 : System.out.println(student4);
         case 3 : System.out.println(student3);
         case 2 : System.out.println(student2);
         case 1 : System.out.println(student1);
      }

   }
}