//********************************************************************
//  PgiLatinGUI.java       Author: Lewis/Loftus
//
//  Solution to Programming Project 5.12
//********************************************************************

import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.*;
import javax.swing.*;

public class PigLatinGUI
{
   private int WIDTH = 400;
   private int HEIGHT = 150;

   private JFrame frame;
   private JPanel panel;
   private JLabel inputLabel, outputLabel, resultLabel;
   private JTextField inputField;

   //-----------------------------------------------------------------
   //  Sets up the GUI.
   //-----------------------------------------------------------------
   public PigLatinGUI()
   {
      frame = new JFrame ("Pig Latin Conversion");
      frame.setDefaultCloseOperation (JFrame.EXIT_ON_CLOSE);

      inputLabel = new JLabel ("Enter a sentence (no punctuation):");
      outputLabel = new JLabel ("That sentence in Pig Latin is: ");
      resultLabel = new JLabel ("-------------");

      inputField = new JTextField (30);
      inputField.addActionListener (new InListener());

      panel = new JPanel();
      panel.setPreferredSize (new Dimension(WIDTH, HEIGHT));
      panel.setBackground (Color.pink);
      panel.add (inputLabel);
      panel.add (inputField);
      panel.add (outputLabel);
      panel.add (resultLabel);

      frame.getContentPane().add (panel);
   }

   //-----------------------------------------------------------------
   //  Displays the primary application frame.
   //-----------------------------------------------------------------
   public void display()
   {
      frame.pack();
      frame.setVisible(true);
   }

   //*****************************************************************
   //  Represents an action listener for the input field.
   //*****************************************************************
   private class InListener implements ActionListener
   {
      //--------------------------------------------------------------
      //  Performs the conversion when the enter key is pressed in
      //  the text field.
      //--------------------------------------------------------------
      public void actionPerformed (ActionEvent event)
      {
         resultLabel.setText (PigLatinTranslator.translate(inputField.getText()));
      }
   }
}
