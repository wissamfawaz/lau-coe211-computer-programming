//********************************************************************
//  PizzaOrderPanel.java       Authors: Lewis and Loftus
//
//  Solution to Programming Project 6.14 (5E, p. 368)
//********************************************************************

import java.util.*;
import java.awt.event.*;
import java.awt.*;
import javax.swing.*;
import javax.swing.border.*;
import java.text.NumberFormat;

public class PizzaOrderPanel extends JPanel {
   ArrayList pizzaOrder;

   ButtonGroup sizeGroup;
   ButtonGroup crustGroup;
   ButtonGroup sauceGroup;
   JCheckBox[] cheeseCheckBoxes;
   JCheckBox[] meatToppingCheckBoxes;
   JCheckBox[] veggieToppingCheckBoxes;
   JLabel numPizzasLabel;
   JLabel totalPriceLabel;
   float previousPrice;
   PizzaOrderPortal portal;

   //-----------------------------------------------------------------
   //  Set up the pizza ordering GUI
   //-----------------------------------------------------------------
   public PizzaOrderPanel(PizzaOrderPortal orderPortal) {
       portal = orderPortal;
       previousPrice = 0.0f;
       pizzaOrder = new ArrayList();

       setLayout(new BorderLayout());

       add(createSizePanel(), BorderLayout.NORTH);
       add(createPizzaPanel(),BorderLayout.CENTER);
       add(createOrderButtonPanel(), BorderLayout.SOUTH);
    }

   //-----------------------------------------------------------------
   //  Creates the pizza size panel
   //-----------------------------------------------------------------
   JPanel createSizePanel()
    {
       sizeGroup = new ButtonGroup();
       JPanel sizePanel = new JPanel();
       sizePanel.setBorder(new EtchedBorder());
       sizePanel.add(new JLabel("Size: "));

       // add sizes from class Pizza
       JRadioButton rButton;
       for (int i = 0; i < Pizza.SIZES.length; i++)
       {
          rButton = new JRadioButton(Pizza.SIZES[i]);
          rButton.setActionCommand(String.valueOf(i));
          sizeGroup.add(rButton);
          sizePanel.add(rButton);
          if (i==0)
             rButton.setSelected(true);
       }
       return sizePanel;
    }

   //-----------------------------------------------------------------
   //  Creates the upper panel in the main pizza panel
   //-----------------------------------------------------------------
    JPanel createUpperPanel()
    {
       JPanel upperPanel = new JPanel();
       JPanel container = new JPanel();
       container.setLayout(new BoxLayout(container, BoxLayout.X_AXIS));

       // set up crust choices
       crustGroup = new ButtonGroup();
       JPanel crustPanel = new JPanel();
       crustPanel.setLayout(new BoxLayout(crustPanel, BoxLayout.Y_AXIS));
       crustPanel.setBorder(new TitledBorder(new EtchedBorder(), "Crust"));

       // add crust types from class Pizza
       JRadioButton rButton;
       for (int i = 0; i < Pizza.CRUST_TYPES.length; i++)
       {
          rButton = new JRadioButton(Pizza.CRUST_TYPES[i]);
          rButton.setActionCommand(String.valueOf(i));
          crustGroup.add(rButton);
          crustPanel.add(rButton);
          if (i==0)
             rButton.setSelected(true);
       }

       container.add(crustPanel);

       // set up sauce choices
       sauceGroup = new ButtonGroup();
       JPanel saucePanel = new JPanel();
       saucePanel.setLayout(new BoxLayout(saucePanel, BoxLayout.Y_AXIS));
       saucePanel.setBorder(new TitledBorder(new EtchedBorder(), "Sauce"));

       // add sauce types from class Pizza
       for (int i = 0; i < Pizza.SAUCE_TYPES.length; i++)
       {
          rButton = new JRadioButton(Pizza.SAUCE_TYPES[i]);
          rButton.setActionCommand(String.valueOf(i));
          sauceGroup.add(rButton);
          saucePanel.add(rButton);
          if (i==0)
             rButton.setSelected(true);
       }

       container.add(saucePanel);

       // set up cheese choices
       cheeseCheckBoxes = new JCheckBox[Pizza.CHEESE_TYPES.length];
       JPanel cheesePanel = new JPanel();
       cheesePanel.setLayout(new BoxLayout(cheesePanel, BoxLayout.Y_AXIS));
       cheesePanel.setBorder(new TitledBorder(new EtchedBorder(), "Cheeses"));

       // add cheese types from class Pizza
       JCheckBox checkBox;
       for (int i = 0; i < Pizza.CHEESE_TYPES.length; i++)
       {
          checkBox = new JCheckBox(Pizza.CHEESE_TYPES[i]);
          checkBox.setActionCommand(String.valueOf(i));
          cheeseCheckBoxes[i] = checkBox;
          cheesePanel.add(checkBox);
       }

       container.add(cheesePanel);

       upperPanel.add(container);
       return upperPanel;
    }


   //-----------------------------------------------------------------
   //  Creates the lower panel in the main pizza panel
   //-----------------------------------------------------------------
    JPanel createLowerPanel()
    {
       JPanel lowerPanel = new JPanel();

       // create toppings panel
       JPanel toppingsPanel = new JPanel();
       toppingsPanel.setLayout(new BoxLayout(toppingsPanel, BoxLayout.X_AXIS));
       toppingsPanel.setBorder(new TitledBorder(new EtchedBorder(), "Toppings"));

       // create meat toppings panel
       JPanel meatToppingsPanel = new JPanel();
       meatToppingsPanel.setLayout(new BoxLayout(meatToppingsPanel, BoxLayout.Y_AXIS));
       meatToppingsPanel.setBorder(new TitledBorder(new EtchedBorder(), "Meats"));

       // add meat toppings from class Pizza
       JCheckBox checkBox;
       meatToppingCheckBoxes = new JCheckBox[Pizza.MEAT_TOPPINGS.length];
       for (int i = 0; i < Pizza.MEAT_TOPPINGS.length; i++)
       {
          checkBox = new JCheckBox(Pizza.MEAT_TOPPINGS[i]);
          checkBox.setActionCommand(String.valueOf(i));
          meatToppingCheckBoxes[i] = checkBox;
          meatToppingsPanel.add(checkBox);
       }
       toppingsPanel.add(meatToppingsPanel);

       // create veggie toppings panel
       JPanel veggieToppingsPanel = new JPanel();
       veggieToppingsPanel.setLayout(new BoxLayout(veggieToppingsPanel, BoxLayout.X_AXIS));
       veggieToppingsPanel.setBorder(new TitledBorder(new EtchedBorder(), "Veggies"));

       //create two panels to display veggies in columns
       JPanel panel1 = new JPanel();
       panel1.setLayout(new BoxLayout(panel1, BoxLayout.Y_AXIS));

       JPanel panel2 = new JPanel();
       panel2.setLayout(new BoxLayout(panel2, BoxLayout.Y_AXIS));

       // add veggie toppings from class Pizza
       int listHalf = Pizza.VEGGIE_TOPPINGS.length / 2;
       veggieToppingCheckBoxes = new JCheckBox[Pizza.VEGGIE_TOPPINGS.length];
       for (int i = 0; i < Pizza.VEGGIE_TOPPINGS.length; i++)
       {
          checkBox = new JCheckBox(Pizza.VEGGIE_TOPPINGS[i]);
          checkBox.setActionCommand(String.valueOf(i));
          veggieToppingCheckBoxes[i] = checkBox;
          if (i < listHalf)
            panel1.add(checkBox);
          else
             panel2.add(checkBox);
       }
       veggieToppingsPanel.add(panel1);
       veggieToppingsPanel.add(panel2);

       toppingsPanel.add(veggieToppingsPanel);

       lowerPanel.add(toppingsPanel);

       return lowerPanel;
    }

   //-----------------------------------------------------------------
   //  Creates the main pizza panel
   //-----------------------------------------------------------------
    JPanel createPizzaPanel()
    {
       JPanel pizzaPanel = new JPanel();

       pizzaPanel.setLayout(new GridLayout(2,1));
       pizzaPanel.add(createUpperPanel());
       pizzaPanel.add(createLowerPanel());

       return pizzaPanel;
    }

   //-----------------------------------------------------------------
   //  Creates the order button panel
   //-----------------------------------------------------------------
    JPanel createOrderButtonPanel()
    {
      JPanel orderPanel = new JPanel();
      orderPanel.setLayout(new BorderLayout());

      // add order button
      JButton orderButton = new JButton("Order This Pizza");
      orderButton.addActionListener(new OrderButtonListener());
      orderPanel.add(orderButton, BorderLayout.NORTH);

      // add stats
      JPanel statPanel = new JPanel();
      statPanel.setLayout(new BoxLayout(statPanel, BoxLayout.Y_AXIS));
      statPanel.setBorder(new TitledBorder(new EtchedBorder(),"Current Order"));

      JPanel numPizzasPanel = new JPanel();
      numPizzasPanel.add(new JLabel("Number of Pizzas: "));
      numPizzasLabel = new JLabel("0");
      numPizzasPanel.add(numPizzasLabel);
      statPanel.add(numPizzasPanel);

      JPanel totalPricePanel = new JPanel();
      totalPricePanel.add(new JLabel("Total Price of Pizzas: "));
      totalPriceLabel = new JLabel("$0.00");
      totalPricePanel.add(totalPriceLabel);
      statPanel.add(totalPricePanel);

      orderPanel.add(statPanel, BorderLayout.CENTER);

      return orderPanel;
    }

   //-----------------------------------------------------------------
   //  Resets all the checkbox options
   //-----------------------------------------------------------------
    void resetOptions()
    {
      for (int i=0;i<cheeseCheckBoxes.length;i++)
        cheeseCheckBoxes[i].setSelected(false);
      for (int i=0;i<meatToppingCheckBoxes.length;i++)
        meatToppingCheckBoxes[i].setSelected(false);
      for (int i=0;i<veggieToppingCheckBoxes.length;i++)
        veggieToppingCheckBoxes[i].setSelected(false);
    }


   //-----------------------------------------------------------------
   //  Compute the total price of the pizza order
   //-----------------------------------------------------------------
    float getTotalPrice()
    {
       float price = 0;
       for (int i=0; i<pizzaOrder.size(); i++)
          price += ((Pizza)pizzaOrder.get(i)).getPrice();
       return price;
    }

    //********************************************************************
    //  Represents the listener class for the order button
    //********************************************************************
    class OrderButtonListener implements ActionListener
    {
       public void actionPerformed(ActionEvent evt)
       {
          Pizza currentPizza = new Pizza();
          try
          {
            // get size
             String cmdString = sizeGroup.getSelection().getActionCommand();
              currentPizza.size = Integer.parseInt(cmdString);

             // get crust type
             cmdString = crustGroup.getSelection().getActionCommand();
             currentPizza.crust = Integer.parseInt(cmdString);

             // get sauce type
             cmdString = sauceGroup.getSelection().getActionCommand();
             currentPizza.sauce = Integer.parseInt(cmdString);

             // get selected cheeses
             for (int i=0; i < cheeseCheckBoxes.length; i++)
                if (cheeseCheckBoxes[i].isSelected())
                {
                   cmdString = cheeseCheckBoxes[i].getActionCommand();
                   currentPizza.cheeses.add(new Integer(cmdString));
                }

             // get selected meat toppings
             for (int i=0; i < meatToppingCheckBoxes.length; i++)
                if (meatToppingCheckBoxes[i].isSelected())
                {
                   cmdString = meatToppingCheckBoxes[i].getActionCommand();
                   currentPizza.meatToppings.add(new Integer(cmdString));
                }

             // get selected veggie toppings
             for (int i=0; i < veggieToppingCheckBoxes.length; i++)
                if (veggieToppingCheckBoxes[i].isSelected())
                {
                   cmdString = veggieToppingCheckBoxes[i].getActionCommand();
                   currentPizza.veggieToppings.add(new Integer(cmdString));
                }

          }
          catch (NumberFormatException e)
          {
          }

          // add pizza to order
          pizzaOrder.add(currentPizza);
          //update stats
          numPizzasLabel.setText(String.valueOf(pizzaOrder.size()));
          NumberFormat money = NumberFormat.getCurrencyInstance();
          float currentPrice = getTotalPrice();
          totalPriceLabel.setText(money.format(currentPrice));
          // update grand total
          portal.updateGrandTotal(currentPrice - previousPrice);
          previousPrice = currentPrice;
          resetOptions();
       }
    }
}
