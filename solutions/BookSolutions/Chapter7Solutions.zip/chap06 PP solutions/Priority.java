//********************************************************************
//  Priority.java       Author: Lewis and Loftus
//
//  Solution to Programming Project 6.5, 6.6, and 6.7 (5E, p. 367)
//********************************************************************

public interface Priority
{
   static final int MED_PRIORITY = 5;
   static final int MAX_PRIORITY = 10;
   static final int MIN_PRIORITY = 1;

   //-----------------------------------------------------------------
   //  Sets the object's priority level
   //-----------------------------------------------------------------
   public void setPriority(int value);

   //-----------------------------------------------------------------
   //  Returns the object's priority level
   //-----------------------------------------------------------------
   public int getPriority();
}