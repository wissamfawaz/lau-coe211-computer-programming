//********************************************************************
//  School.java       Author: Lewis and Loftus
//
//  Solution to Programming Project 6.3 (5E, p. 366)
//********************************************************************

import java.text.DecimalFormat;

public class School
{
   //-----------------------------------------------------------------
   //  Creates some Address and Student2 objects, adds them to a course,
   //  and prints them.
   //-----------------------------------------------------------------
   public static void main (String[] args)
   {
      Address school = new Address ("800 Lancaster Ave.", "Villanova",
                                    "PA", 19085);

      Address jHome = new Address ("21 Jump Street", "Lynchburg",
                                   "VA", 24551);
      Student2 john = new Student2 ("John", "Smith", jHome, school, 75, 88, 78);

      Address mHome = new Address ("123 Main Street", "Euclid", "OH",
                                   44132);
      Student2 marsha = new Student2 ("Marsha", "Jones", mHome, school, 100, 98, 94);

      Course zoology = new Course ("Zoology");
      zoology.addStudent (john);
      zoology.addStudent (marsha);

      zoology.roll();

      DecimalFormat formatter = new DecimalFormat("0.0#");
      System.out.println("\n-----------------------------------------------");
      System.out.println("Average test score of all tests in this course: " +
               formatter.format(zoology.average()));
   }
}