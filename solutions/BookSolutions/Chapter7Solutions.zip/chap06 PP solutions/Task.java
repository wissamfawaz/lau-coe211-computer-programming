//********************************************************************
//  Task.java       Author: Lewis and Loftus
//
//  Solution to Programming Project 6.5 (5E, p. 367)
//********************************************************************

public class Task implements Priority
{
   private int priority;
   String name;

   //-----------------------------------------------------------------
   //  Sets up the task, assigning the task's name
   //-----------------------------------------------------------------
   public Task (String taskName)
   {
      name = taskName;
      priority = MED_PRIORITY;
   }

   //-----------------------------------------------------------------
   // Returns this task's name
   //-----------------------------------------------------------------
   String getName()
   {
      return name;
   }

   //-----------------------------------------------------------------
   //  Sets this task's priority level
   //-----------------------------------------------------------------
   public void setPriority (int value)
   {
      priority = value;
   }

   //-----------------------------------------------------------------
   //  Returns this task's priority level
   //-----------------------------------------------------------------
   public int getPriority()
   {
      return priority;
   }
}