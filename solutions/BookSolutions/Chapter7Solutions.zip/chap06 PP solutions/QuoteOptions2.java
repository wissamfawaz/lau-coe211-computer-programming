//********************************************************************
//  QuoteOptions2.java       Author: Lewis and Loftus
//
//  Solution to Programming Project 6.12 (5E, p. 368)
//********************************************************************

import javax.swing.*;

public class QuoteOptions2
{
   //-----------------------------------------------------------------
   //  Creates and presents the program frame.
   //-----------------------------------------------------------------
   public static void main (String[] args)
   {
      JFrame quoteFrame = new JFrame ("Quote Options");
      quoteFrame.setDefaultCloseOperation (JFrame.EXIT_ON_CLOSE);

      QuoteGUI2 gui = new QuoteGUI2();
      quoteFrame.getContentPane().add (gui.getPanel());

      quoteFrame.pack();
      quoteFrame.setVisible(true);
   }
}
