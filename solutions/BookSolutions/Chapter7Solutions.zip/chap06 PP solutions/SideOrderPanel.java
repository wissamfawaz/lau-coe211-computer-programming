//********************************************************************
//  SideOrderPanel.java       Authors: Lewis and Loftus
//
//  Solution to Programming Project 6.14 (5E, p. 368)
//********************************************************************

import java.util.ArrayList;
import javax.swing.*;
import javax.swing.border.*;
import java.awt.event.*;
import java.awt.*;
import java.text.NumberFormat;

//********************************************************************
//  Helper class for representing side orders
//********************************************************************
class Side
{
   static final String[] SIDE_TYPES = {
      "Cheese Bread",
      "Bread Sticks",
      "Buffalo Wings",
      "Caeser Salad",
      "Greek Salad",
      "Minestrone Soup",
      "Meatballs",
      "Spaghetti"
   };

   static final float PRICE = 2.0f;

   int side;

   public String toString()
   {
      try
      {
         return SIDE_TYPES[side];
      }
      catch (ArrayIndexOutOfBoundsException e)
      {
         return "";
      }
   }
}

//********************************************************************
//  Main panel for ordering sides.
//********************************************************************
public class SideOrderPanel extends JPanel
{
    JTextField[] beverageQuantityTextFields;
    JLabel numSidesLabel;
    JLabel totalPriceLabel;
    float previousPrice;
    PizzaOrderPortal portal;

   //-----------------------------------------------------------------
   //  Set up the side order panel GUI
   //-----------------------------------------------------------------
    public SideOrderPanel(PizzaOrderPortal orderPortal)
    {
       portal = orderPortal;
       previousPrice = 0.0f;
       setLayout(new BorderLayout());
       add(createSideList(), BorderLayout.CENTER);
       add(createOrderPanel(), BorderLayout.SOUTH);
    }

   //-----------------------------------------------------------------
   //  Create the order and stat panel
   //-----------------------------------------------------------------
    JPanel createOrderPanel()
    {
      JPanel orderPanel = new JPanel();
      orderPanel.setLayout(new BorderLayout());

      // create order button
      JButton orderButton = new JButton("Order These Sides");
      orderButton.addActionListener(new OrderButtonListener());      // add stats
      orderPanel.add(orderButton, BorderLayout.NORTH);

      //create stat panel
      JPanel statPanel = new JPanel();
      statPanel.setLayout(new BoxLayout(statPanel, BoxLayout.Y_AXIS));
      statPanel.setBorder(new TitledBorder(new EtchedBorder(),"Current Order"));

      JPanel numSidesPanel = new JPanel();
      numSidesPanel.add(new JLabel("Number of Sides: "));
      numSidesLabel = new JLabel("0");
      numSidesPanel.add(numSidesLabel);
      statPanel.add(numSidesPanel);

      JPanel totalPricePanel = new JPanel();
      totalPricePanel.add(new JLabel("Total Price of Side Orders: "));
      totalPriceLabel = new JLabel("$0.00");
      totalPricePanel.add(totalPriceLabel);
      statPanel.add(totalPricePanel);

      orderPanel.add(statPanel, BorderLayout.CENTER);

      return orderPanel;
    }

   //-----------------------------------------------------------------
   //  Create the side order main panel
   //-----------------------------------------------------------------
   JPanel createSideList()
    {
       int numSides = Side.SIDE_TYPES.length;

       JPanel listPanel = new JPanel();
       listPanel.setLayout(new GridLayout(numSides+1, 2));
       listPanel.setBorder(new TitledBorder(new EtchedBorder(), "Sides"));

       listPanel.add(new JLabel(""));
       JLabel header = new JLabel("Quantity");
       header.setHorizontalAlignment(SwingConstants.CENTER);
       listPanel.add(header);


       beverageQuantityTextFields = new JTextField[numSides];
       for (int i=0; i<numSides; i++)
       {
         listPanel.add(new JLabel(Side.SIDE_TYPES[i]));
         JTextField quantity = new JTextField("0");
         quantity.setHorizontalAlignment(SwingConstants.CENTER);
         beverageQuantityTextFields[i] = quantity;
         listPanel.add(quantity);
       }

       JPanel outerPanel = new JPanel();
       outerPanel.add(listPanel);
       return outerPanel;
    }

   //-----------------------------------------------------------------
   //  Return the number of sides ordered
   //-----------------------------------------------------------------
    int getNumSides()
    {
      int total = 0;
      for (int i=0; i<beverageQuantityTextFields.length; i++)
      {
         try
         {
            int quantity = Integer.parseInt(beverageQuantityTextFields[i].getText());
            total += quantity;
         }
         catch (NumberFormatException e)
         {
         }
      }
      return total;
    }

   //-----------------------------------------------------------------
   //  Return the total price of ordered sides
   //-----------------------------------------------------------------
    float getPrice()
    {
      return getNumSides() * Side.PRICE;
    }

    //********************************************************************
    //  Represents the listener class for the order button
    //********************************************************************
    class OrderButtonListener implements ActionListener
    {
       public void actionPerformed(ActionEvent evt)
       {
          float currentPrice = getPrice();
          numSidesLabel.setText(String.valueOf(getNumSides()));
          NumberFormat money = NumberFormat.getCurrencyInstance();
          totalPriceLabel.setText(money.format(currentPrice));
          portal.updateGrandTotal(currentPrice - previousPrice);
          previousPrice = currentPrice;

       }
    }
}

