//********************************************************************
//  Task3.java       Author: Lewis and Loftus
//
//  Solution to Programming Project 6.7 (5E, p. 367)
//********************************************************************

public class Task3 implements Priority, Complexity, Comparable
{
   private int priority;
   private int complexity;
   String name;

   //-----------------------------------------------------------------
   //  Sets up the task, assigning the task's name
   //-----------------------------------------------------------------
   public Task3(String taskName)
   {
      name = taskName;
      priority = MED_PRIORITY;
   }

   //-----------------------------------------------------------------
   // Returns the task's name
   //-----------------------------------------------------------------
   String getName()
   {
      return name;
   }

   //-----------------------------------------------------------------
   //  Sets the task's priority level
   //-----------------------------------------------------------------
   public void setPriority(int value)
   {
      priority = value;
   }

   //-----------------------------------------------------------------
   //  Returns the task's priority level
   //-----------------------------------------------------------------
   public int getPriority()
   {
      return priority;
   }

   //-----------------------------------------------------------------
   //  Sets the task's complexity level
   //-----------------------------------------------------------------
   public void setComplexity (int complexity)
   {
      this.complexity = complexity;
   }

   //-----------------------------------------------------------------
   //  Returns the task's complexity level
   //-----------------------------------------------------------------
   public int getComplexity()
   {
      return complexity;
   }

   //-----------------------------------------------------------------
   //  Compares two tasks based on priority
   //-----------------------------------------------------------------
   public int compareTo(Object o)
   {
      Task3 other = (Task3)o;

      if (other.priority == this.priority)
         return 0;
      else
         if (other.priority > this.priority)
            return -1;
         else
            return 1;
   }
}