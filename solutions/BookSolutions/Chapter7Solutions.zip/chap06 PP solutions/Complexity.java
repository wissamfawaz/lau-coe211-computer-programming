//********************************************************************
//  Complexity.java       Author: Lewis and Loftus
//
//  Solution to Programming Project 6.6 and 6.7 (5E, p. 367)
//********************************************************************

public interface Complexity
{
   //-----------------------------------------------------------------
   //  Sets the object's complexity level
   //-----------------------------------------------------------------
   public void setComplexity (int complexity);

   //-----------------------------------------------------------------
   //  Returns the object's complexity level
   //-----------------------------------------------------------------
   public int getComplexity();
}
