//********************************************************************
//  PizzaOrderPortal.java       Authors: Lewis and Loftus
//
//  Solution to Programming Project 6.14 (5E, p. 368)
//********************************************************************

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.text.NumberFormat;

public class PizzaOrderPortal extends JFrame {
    JLabel grandTotalLabel;
    float grandTotal;

   //-----------------------------------------------------------------
   //  Set up the main GUI
   //-----------------------------------------------------------------
    public PizzaOrderPortal()
    {
       super("Pizza Express");

      // make the frame closeable
       setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); 

       //set up the grand total panel
       grandTotal = 0.0f;
       JPanel totalPanel = new JPanel();
       totalPanel.add(new JLabel("GRAND TOTAL: "));
       grandTotalLabel = new JLabel("$0.00");
       totalPanel.add(grandTotalLabel);
       getContentPane().add(totalPanel, BorderLayout.SOUTH);

       //create the tabbed pane
       JTabbedPane mainTabbedPane = new JTabbedPane();
       mainTabbedPane.add("Pizzas", new PizzaOrderPanel(this));
       mainTabbedPane.add("Beverages", new BeverageOrderPanel(this));
       mainTabbedPane.add("Side Orders", new SideOrderPanel(this));

       getContentPane().add(mainTabbedPane,BorderLayout.CENTER);

       // add a title panel
       JLabel title = new JLabel("Pizza Express - Java Enabled Pizza Ordering");
       title.setFont(new Font("Dialog",Font.BOLD, 18));
       JPanel titlePanel = new JPanel();
       titlePanel.add(title);
       getContentPane().add(titlePanel, BorderLayout.NORTH);

       pack();
    }

   //-----------------------------------------------------------------
   //  Utility method used by other objects to update the grand total
   //-----------------------------------------------------------------
    void updateGrandTotal(float amount)
    {
       grandTotal += amount;
       NumberFormat money = NumberFormat.getCurrencyInstance();
       grandTotalLabel.setText(money.format(grandTotal));
    }

    public static void main (String args[]) {
       new PizzaOrderPortal().setVisible(true);
    }

}
