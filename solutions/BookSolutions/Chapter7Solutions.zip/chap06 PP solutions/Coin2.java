//********************************************************************
//  Coin2.java       Author: Lewis and Loftus
//
//  Solution to Programming Project 6.8 (5E, p. 367)
//********************************************************************

import java.util.Random;

public class Coin2 implements Lockable
{
   private final int HEADS = 0;
   private final int TAILS = 1;
   private final int LOCK = 3;
   private boolean locked;
   private int coinKey;

   private int face;

   //-----------------------------------------------------------------
   //  Sets up the coin by flipping it initially.
   //-----------------------------------------------------------------
   public Coin2 ()
   {
      locked = false;
      coinKey = 0;
      flip();
   }

   //-----------------------------------------------------------------
   //  Flips the coin by randomly choosing a face value.
   //-----------------------------------------------------------------
   public void flip ()
   {
      if (!locked)
         face = (int) (Math.random() * 2);
   }

   //-----------------------------------------------------------------
   //  Returns true if the current face of the coin is heads.
   //-----------------------------------------------------------------
   public boolean isHeads ()
   {
      return (face == HEADS);
   }

   //-----------------------------------------------------------------
   //  Returns the current face of the coin as a string.
   //-----------------------------------------------------------------
   public String toString()
   {
      if (!locked)
      {
         String faceName;

         if (face == HEADS)
            faceName = "Heads";
         else
            faceName = "Tails";

         return faceName;
      }
      else
         return "LOCKED";
   }

   //-----------------------------------------------------------------
   //  Sets the object's key
   //-----------------------------------------------------------------
   public void setKey (int key)
   {
      if (!locked)
         coinKey = key;
   }

   //-----------------------------------------------------------------
   //  Locks the object
   //-----------------------------------------------------------------
   public void lock (int key)
   {
      if (key == coinKey)
         locked = true;
   }

   //-----------------------------------------------------------------
   //  Unlocks the object
   //-----------------------------------------------------------------
   public void unlock (int key)
   {
      if (key == coinKey)
         locked = false;
   }

   //-----------------------------------------------------------------
   //  Returns true it the object is locked, else returns false
   //-----------------------------------------------------------------
   public boolean locked ()
   {
      return locked;
   }
}
