//********************************************************************
//  NumericKeyPad.java       Author: Lewis and Loftus
//
//  Solution to Programming Project 6.13 (5E, p. 368)
//********************************************************************

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;

public class NumericKeyPad extends JFrame
{
   JPanel keyPanel;
   JPanel clearPanel;
   JLabel displayLabel;
   String displayText;

   //-----------------------------------------------------------------
   //  Sets up the GUI for the keypad
   //-----------------------------------------------------------------
    public NumericKeyPad() {
      super("Numeric Keypad");
      setSize(250,250);

      // make the frame closeable
       setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

       displayText = "";

       // initialize the display
       displayLabel = new JLabel(" ");
       displayLabel.setBackground(Color.white);
       displayLabel.setBorder(new BevelBorder(BevelBorder.LOWERED));
       getContentPane().add(displayLabel, BorderLayout.NORTH);

       // create the panel to hold the keys
       keyPanel = new JPanel();
       keyPanel.setLayout(new GridLayout(4,3));
       keyPanel.setBorder(new LineBorder(Color.black, 4));

       // create the buttons and add to the keyPanel
       JButton button;
       KeyListener displayKey = new KeyListener();

       button = new JButton();
       button.setText("1");
       button.setMnemonic('1');
       button.addActionListener(displayKey);
       keyPanel.add(button);

       button = new JButton();
       button.setText("2");
       button.setMnemonic('2');
       button.addActionListener(displayKey);
       keyPanel.add(button);

       button = new JButton();
       button.setText("3");
       button.setMnemonic('3');
       button.addActionListener(displayKey);
       keyPanel.add(button);

       button = new JButton();
       button.setText("4");
       button.setMnemonic('4');
       button.addActionListener(displayKey);
       keyPanel.add(button);

       button = new JButton();
       button.setText("5");
       button.setMnemonic('5');
       button.addActionListener(displayKey);
       keyPanel.add(button);

       button = new JButton();
       button.setText("6");
       button.setMnemonic('6');
       button.addActionListener(displayKey);
       keyPanel.add(button);

       button = new JButton();
       button.setText("7");
       button.setMnemonic('7');
       button.addActionListener(displayKey);
       keyPanel.add(button);

       button = new JButton();
       button.setText("8");
       button.setMnemonic('8');
       button.addActionListener(displayKey);
       keyPanel.add(button);

       button = new JButton();
       button.setText("9");
       button.setMnemonic('9');
       button.addActionListener(displayKey);
       keyPanel.add(button);

       button = new JButton();
       button.setText("*");
       button.setMnemonic('*');
       button.addActionListener(displayKey);
       keyPanel.add(button);

       button = new JButton();
       button.setText("0");
       button.setMnemonic('0');
       button.addActionListener(displayKey);
       keyPanel.add(button);

       button = new JButton();
       button.setText("#");
       button.setMnemonic('#');
       button.addActionListener(displayKey);
       keyPanel.add(button);

       getContentPane().add(keyPanel,BorderLayout.CENTER);

       // create the Clear button and add to frame
       button = new JButton();
       button.setText("Clear");
       button.setMnemonic('C');
       button.setToolTipText("Clear the display");
       button.addActionListener(new ClearListener());

       getContentPane().add(button,BorderLayout.EAST);
    }

   //-----------------------------------------------------------------
   //  Appends String value to the display
   //-----------------------------------------------------------------
    private void appendDisplay(String value)
    {
       displayText = displayText + value;
       displayLabel.setText(displayText);
    }


//********************************************************************
//  Represents the action listener for the keys.  Causes the value of
//  the key to be appended to the display
//********************************************************************
class KeyListener implements ActionListener
{
   public void actionPerformed(ActionEvent evt)
   {
      JButton source = (JButton)evt.getSource();
      appendDisplay(source.getText());
   }
}

//********************************************************************
//  Represents the action listener for the clear button.  Clears
//  the display
//********************************************************************
class ClearListener implements ActionListener
{
   //-----------------------------------------------------------------
   //  Clears the display
   //-----------------------------------------------------------------
    public void actionPerformed(ActionEvent evt)
    {
       displayText = "";
       displayLabel.setText(" ");
    }
}
}
