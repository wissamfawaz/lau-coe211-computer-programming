//********************************************************************
//  Task2.java       Author: Lewis and Loftus
//
//  Solution to Programming Project 6.6 (5E, p. 367)
//********************************************************************

public class Task2 implements Priority, Complexity
{
   private int priority;
   private int complexity;
   String name;

   //-----------------------------------------------------------------
   //  Sets up the task, assigning the task's name
   //-----------------------------------------------------------------
   public Task2 (String taskName)
   {
      name = taskName;
      priority = MED_PRIORITY;
   }

   //-----------------------------------------------------------------
   // Returns the task's name
   //-----------------------------------------------------------------
   String getName()
   {
      return name;
   }

   //-----------------------------------------------------------------
   //  Sets the task's priority level
   //-----------------------------------------------------------------
   public void setPriority (int value)
   {
      priority = value;
   }

   //-----------------------------------------------------------------
   //  Returns the task's priority level
   //-----------------------------------------------------------------
   public int getPriority()
   {
      return priority;
   }

   //-----------------------------------------------------------------
   //  Sets this task's complexity level
   //-----------------------------------------------------------------
   public void setComplexity (int complexity)
   {
      this.complexity = complexity;
   }

   //-----------------------------------------------------------------
   //  Returns this task's complexity level
   //-----------------------------------------------------------------
   public int getComplexity()
   {
      return complexity;
   }
}