//********************************************************************
//  Pizza.java       Authors: Lewis and Loftus
//
//  Solution to Programming Project 6.14 (5E, p. 368)
//********************************************************************

import java.util.ArrayList;
import java.text.NumberFormat;

//********************************************************************
//  Defines constants used in the PizzaOrderPortal.  Encapsulates the
//  pizza data type.
//********************************************************************
public class Pizza {
   int size;
   int crust;
   int sauce;
   ArrayList cheeses;
   ArrayList meatToppings;
   ArrayList veggieToppings;

   static final float BASE_PRICE = 5.00f;
   static final float SIZE_PRICE_INCREMENT = 1.0f;
   static final float PRICE_PER_TOPPING = 0.50f;
   static final float PRICE_PER_CHEESE = 1.00f;

   static final String[] SIZES = {
      "Single Serving",
      "Small",
      "Medium",
      "Large"
   };
   static final String[] CRUST_TYPES = {
      "New York-style",
      "Chicago-style",
      "Neapolitan-style",
      "Honey Whole Wheat",
      "Sourdough"
   };
   static final String[] SAUCE_TYPES = {
      "Tomato Basil",
      "Alfredo",
      "Pesto",
      "Barbecue",
      "Olive Oil and Garlic"
   };

   static final String[] CHEESE_TYPES = {
      "Mozzarella",
      "Parmesan",
      "Smoked Gouda",
      "Feta",
      "Chevre"
   };

   static final String[] MEAT_TOPPINGS = {
      "Pepperoni",
      "Italian Sausage",
      "Grilled Chicken",
      "Canadian Bacon",
      "Smoked Salmon"
   };

   static final String[] VEGGIE_TOPPINGS = {
      "Artichoke Hearts",
      "Roasted Garlic",
      "Roasted Red Peppers",
      "Red Onion",
      "Sun-dried Tomatoes",
      "Fresh Tomatoes",
      "Kalamata Olives",
      "Grilled Vegetable Assortment",
      "Mushrooms",
      "Arugula"
   };


   //-----------------------------------------------------------------
   //  Create a Pizza object
   //-----------------------------------------------------------------
    public Pizza() {
       cheeses = new ArrayList();
       meatToppings = new ArrayList();
       veggieToppings = new ArrayList();
    }

   //-----------------------------------------------------------------
   //  Computes the price of a pizza
   //-----------------------------------------------------------------
   public float getPrice()
   {
      return BASE_PRICE + size * SIZE_PRICE_INCREMENT +
         cheeses.size() * PRICE_PER_CHEESE +
         meatToppings.size() * PRICE_PER_TOPPING +
         veggieToppings.size() * PRICE_PER_TOPPING;

   }

   //-----------------------------------------------------------------
   //  Returns a string representing the price of the pizza
   //-----------------------------------------------------------------
   public String getPriceString()
   {
      float price = getPrice();
      NumberFormat formatter = NumberFormat.getCurrencyInstance();
      return formatter.format(price);
   }
}
