//********************************************************************
//  Test.java        Author: Lewis and Loftus
//
//  Solution to Programming Project 1.1 (5th Ed, p. 54)
//********************************************************************

class test
{
   //-----------------------------------------------------------------
   //  Prints a statement.
   //-----------------------------------------------------------------
   public static void main (String[] args)
   {
      System.out.println ("An Emergency Broadcast");
   }
}
