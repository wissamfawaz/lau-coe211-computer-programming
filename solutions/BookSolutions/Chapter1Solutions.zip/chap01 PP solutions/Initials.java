//********************************************************************
//  Initials.java        Author: Lewis and Loftus
//
//  Solution to Programming Project 1.8 (5th Ed, p. 55)
//********************************************************************

class Initials
{
   //-----------------------------------------------------------------
   //  Prints some initials in block letters.
   //-----------------------------------------------------------------
   public static void main (String[] args)
   {
      System.out.println ();
      System.out.println ("JJJJJJJJJJJ      A       LLL");
      System.out.println ("JJJJJJJJJJJ     AAA      LLL");
      System.out.println ("     JJJ       AA AA     LLL");
      System.out.println ("     JJJ      AA   AA    LLL");
      System.out.println ("     JJJ     AA     AA   LLL");
      System.out.println ("     JJJ     AAAAAAAAA   LLL");
      System.out.println ("     JJJ     AAAAAAAAA   LLL");
      System.out.println ("JJ   JJJ     AA     AA   LLL");
      System.out.println ("JJJJJJJJ     AA     AA   LLLLLLLLLL");
      System.out.println ("JJJJJJJJ     AA     AA   LLLLLLLLLL");
      System.out.println ();
   }
}
