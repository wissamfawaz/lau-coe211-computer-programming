This folder contains solutions to the Programming Projects from
Chapter 1 of Java Software Solutions, 5th Ed, by Lewis and Loftus.

Project     File(s)
-------     -------
1.1         Test.java

1.2         Test2.java

1.3         Info.java

1.4         Knowledge.java

1.5         WebSites.java

1.6         Lyrics.java

1.7         Diamond.java

1.8         Initials.java

