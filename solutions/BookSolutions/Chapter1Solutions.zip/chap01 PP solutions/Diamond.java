//********************************************************************
//  Diamond.java        Author: Lewis and Loftus
//
//  Solution to Programming Project 1.7  (5th Ed, p. 55)
//********************************************************************

public class Diamond
{
   //-----------------------------------------------------------------
   //  Prints a diamond
   //-----------------------------------------------------------------
   public static void main (String args[])
   {
      System.out.println("    *");
      System.out.println("   ***");
      System.out.println("  *****");
      System.out.println(" *******");
      System.out.println("*********");
      System.out.println(" *******");
      System.out.println("  *****");
      System.out.println("   ***");
      System.out.println("    *");
    }

}