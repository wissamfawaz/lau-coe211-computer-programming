//********************************************************************
//  Lyrics.java        Author: Lewis and Loftus
//
//  Solution to Programming Project 1.6 (5th Ed, p. 55)
//********************************************************************

public class Lyrics
{
   //-----------------------------------------------------------------
   //  Prints the lyrics of a song.
   //-----------------------------------------------------------------
	public static void main (String args[])
	{
		System.out.println("Jailhouse Rock");
		System.out.println();
		System.out.println("The warden threw a party in the county jail.");
		System.out.println("The prison band was there and they began to wail.");
		System.out.println("The band was jumpin' and the joint began to swing.");
		System.out.println("You should've heard those knocked out jailbirds sing.");
		System.out.println();
		System.out.println("Chorus:");
		System.out.println("Let's rock, everybody, let's rock.");
		System.out.println("Everybody in the whole cell block");
		System.out.println("was dancin' to the Jailhouse Rock.");
		System.out.println();
		System.out.println("Spider Murphy played the tenor saxophone,");
		System.out.println("Little Joe was blowin' on the slide trombone.");
		System.out.println("The drummer boy from Illinois went crash, boom, bang,");
		System.out.println("the whole rhythm section was the Purple Gang.");
		System.out.println();
		System.out.println("Repeat chorus");
	}
}