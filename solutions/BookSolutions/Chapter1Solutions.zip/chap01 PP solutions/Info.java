//********************************************************************
//  Info.java        Author: Lewis and Loftus
//
//  Solution to Programming Project 1.3 (5th Ed, p. 55)
//********************************************************************

public class Info
{
   //-----------------------------------------------------------------
   //  Prints information about the programmer.
   //-----------------------------------------------------------------
	public static void main (String args[])
	{
		System.out.println("Name     : Lara");
		System.out.println("Birthday : March 25");
		System.out.println("Hobbies  : Sailing, Cooking, Hiking");
		System.out.println("Favorite Book  : The Brothers Karamasov");
		System.out.println("Favorite Movie : Remains of the Day");
	}
}