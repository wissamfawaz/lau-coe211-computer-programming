//********************************************************************
//  BusinessCard.java       Author: Lewis and Loftus
//
//  Solution to Programming Project 2.18 (5th Ed, p. 109)
//********************************************************************

import javax.swing.JApplet;
import java.awt.*;

public class BusinessCard extends JApplet
{
   //-----------------------------------------------------------------
   //  Draws a business card.
   //-----------------------------------------------------------------
   public void paint (Graphics page)
   {
      setBackground (Color.yellow);

      page.setColor (Color.red);
      page.fillOval (10, 20, 60, 60);
      page.setColor (Color.cyan);
      page.fillRect (25, 35, 130, 25);

      page.setColor (Color.black);
      page.drawString ("James C. Kerplunk", 35, 50);
      page.drawString ("President and CEO", 85, 80);
      page.drawString ("Origin Software, Inc.", 85, 100);

      page.drawLine (225, 20, 225, 80);
      page.drawLine (195, 50, 255, 50);

      page.setColor (Color.blue);
      page.drawString ("where it all begins...", 115, 135);

   }
}
