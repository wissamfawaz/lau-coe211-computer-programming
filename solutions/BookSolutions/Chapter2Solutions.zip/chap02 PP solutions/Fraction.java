//********************************************************************
//  Fraction.java       Author: Lewis and Loftus
//
//  Solution to Programming Project 2.11 (5th Ed, p. 108)
//********************************************************************

import java.util.Scanner;

public class Fraction
{
   //-----------------------------------------------------------------
   //  Computes the floating point equivalent of a fraction.
   //-----------------------------------------------------------------
   public static void main (String[] args)
   {
      int numerator, denominator;
      float value;

	  Scanner scan = new Scanner(System.in);

      System.out.print ("Enter the numerator: ");
      numerator = scan.nextInt();
      System.out.print ("Enter the denominator: ");
      denominator = scan.nextInt();

      value = (float) numerator / denominator;

      System.out.println ("Floating point equivalent: " + value);
   }
}
