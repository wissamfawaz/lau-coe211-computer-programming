//********************************************************************
//  Seconds2.java       Author: Lewis and Loftus
//
//  Solution to Programming Project 2.7 (5th Ed, p. 107)
//********************************************************************

import java.util.Scanner;

public class Seconds2
{
   //-----------------------------------------------------------------
   //  Computes the number of hours, minutes, and seconds that are
   //  equivalent to the number of seconds entered by the user.
   //-----------------------------------------------------------------
   public static void main (String[] args)
   {
      final int SECONDS_PER_HOUR = 3600;
      final int SECONDS_PER_MINUTE = 60;

      int seconds, minutes, hours;
	  
	  Scanner scan = new Scanner(System.in);

      System.out.print ("Enter the number of seconds: ");
      seconds = scan.nextInt();

      hours = seconds / SECONDS_PER_HOUR;

      seconds = seconds % SECONDS_PER_HOUR;  // still remaining

      minutes = seconds / SECONDS_PER_MINUTE;

      seconds = seconds % SECONDS_PER_MINUTE;  // still remaining

      System.out.println ();
      System.out.println ("Hours: " + hours);
      System.out.println ("Minutes: " + minutes);
      System.out.println ("Seconds: " + seconds);
   }
}
