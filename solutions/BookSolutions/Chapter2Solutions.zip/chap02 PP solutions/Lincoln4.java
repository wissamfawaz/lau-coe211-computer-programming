//********************************************************************
//  Lincoln4.java        Author: Lewis and Loftus
//
//  Solution to Programming Project 2.1 (5th Ed, page 107)
//********************************************************************

class Lincoln4
{
   //-----------------------------------------------------------------
   //  Prints a quote from Abraham Lincoln, including quotation
   //  marks.
   //-----------------------------------------------------------------
   public static void main (String[] args)
   {
      System.out.println ("A quote by Abraham Lincoln:");

      System.out.println ("\"Whatever you are, be a good one.\"");
   }
}
