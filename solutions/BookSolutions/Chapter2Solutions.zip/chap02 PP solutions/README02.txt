This folder contains solutions to the Programming Projects from
Chapter 2 of Java Software Solutions, 5th Ed, by Lewis and Loftus.

Project     File(s)
-------     -------

2.1         Lincoln4.java

2.2         AverageOfThree.java
            AverageOfThree2.java  (alternative solution)

2.3         FloatCalculations.java

2.4         TempConverter2.java

2.5         MilesToKilometers.java

2.6         Seconds.java

2.7         Seconds2.java

2.8         ChangeCounter.java

2.9         MoneyConversion.java

2.10        SquareCalculations.java

2.11        Fraction.java

2.12        Snowman2.java
            Snowman2.html

2.13        DrawName.java
            DrawName.html

2.14        BigDipper.java
            BigDipper.html

2.15        Balloons.java
            Balloons.html

2.16        OlympicRings.java
            OlympicRings.html

2.17        HousePicture.java
            HousePicture.html

2.18        BusinessCard.java
            BusinessCard.html

2.19        ShadowName.java
            ShadowName.html

2.20        PieChart.java
            PieChart.html

