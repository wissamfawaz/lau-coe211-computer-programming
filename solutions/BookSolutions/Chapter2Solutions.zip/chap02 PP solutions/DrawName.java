//********************************************************************
//  DrawName.java       Author: Lewis and Loftus
//
//  Solution to Programming Project 2.13 (5th Ed, p. 108)
//********************************************************************

import javax.swing.JApplet;
import java.awt.*;

public class DrawName extends JApplet
{
   //-----------------------------------------------------------------
   //  Draws a name.
   //-----------------------------------------------------------------
   public void paint (Graphics page)
   {
      setBackground (Color.cyan);

      page.setColor (Color.black);
      page.drawString ("John A. Lewis", 50, 50);
   }
}
