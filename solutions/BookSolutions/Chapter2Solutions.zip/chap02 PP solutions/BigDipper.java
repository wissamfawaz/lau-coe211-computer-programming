//********************************************************************
//  BigDipper.java       Author: Lewis and Loftus
//
//  Solution to Programming Project 2.14 (5th Ed, p. 108)
//********************************************************************

import javax.swing.JApplet;
import java.awt.*;

public class BigDipper extends JApplet
{
   //-----------------------------------------------------------------
   //  Draws the Big Dipper constellation and some other stars.
   //-----------------------------------------------------------------
   public void paint (Graphics page)
   {
      setBackground (Color.black);

      page.setColor (Color.white);
      page.drawLine (100, 80, 110, 120);
      page.drawLine (110, 120, 165, 115);
      page.drawLine (165, 115, 175, 70);
      page.drawLine (100, 80, 175, 70);

      page.drawLine (175, 70, 245, 20);
      page.drawLine (245, 20, 280, 30);

      // Draw some extra stars
      page.fillOval (50, 50, 4, 4);
      page.fillOval (70, 150, 3, 3);
      page.fillOval (90, 30, 3, 3);
      page.fillOval (220, 140, 4, 4);
      page.fillOval (280, 170, 3, 3);
      page.fillOval (310, 100, 4, 4);
      page.fillOval (360, 20, 3, 3);
   }
}
