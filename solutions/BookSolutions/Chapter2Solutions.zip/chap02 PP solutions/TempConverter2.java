//********************************************************************
//  TempConverter2.java       Author: Lewis and Loftus
//
//  Solution to Programming Project 2.4 (5th Ed, p. 107)
//********************************************************************

import java.util.Scanner;

public class TempConverter2
{
   //-----------------------------------------------------------------
   //  Computes the Celsius equivalent of a Fahrenheit value read
   //  from the user. Uses the formula C = (5/9)(F - 32).
   //-----------------------------------------------------------------
   public static void main (String[] args)
   {
      final int BASE = 32;
      final double CONVERSION_FACTOR = 5.0 / 9.0;

      double celsiusTemp, fahrenheitTemp;
	  Scanner scan = new Scanner(System.in);

      System.out.print ("Enter a Fahrenheit temperature: ");
      fahrenheitTemp = scan.nextDouble();

      celsiusTemp = CONVERSION_FACTOR * (fahrenheitTemp - BASE);

      System.out.println ("Celsius Equivalent: " + celsiusTemp);
   }
}
