//********************************************************************
//  ShadowName.java       Author: Lewis and Loftus
//
//  Solution to Programming Project 2.19 (5th Ed, p. 109)
//********************************************************************

import javax.swing.JApplet;
import java.awt.*;

public class ShadowName extends JApplet
{
   //-----------------------------------------------------------------
   //  Draws a name with a slightly offset shadow.
   //-----------------------------------------------------------------
   public void paint (Graphics page)
   {
      setBackground (Color.yellow);

      page.setColor (Color.black);
      page.drawString ("John A. Lewis", 50, 50);

      page.setColor (Color.red);
      page.drawString ("John A. Lewis", 49, 49);
   }
}
