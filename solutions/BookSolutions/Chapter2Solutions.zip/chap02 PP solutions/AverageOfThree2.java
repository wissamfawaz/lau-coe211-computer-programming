//********************************************************************
//  AverageOfThree2.java        Author: Lewis and Loftus
//
//  Alternate solution to Programming Project 2.2 (5th Ed, p. 107)	
//********************************************************************

import java.util.Scanner;

class AverageOfThree2
{
   //-----------------------------------------------------------------
   //  Reads three integers from the user and prints their average.
   //-----------------------------------------------------------------
   public static void main (String[] args)
   {
      int num1, num2, num3;
      double average;
	  Scanner scan = new Scanner (System.in);

      System.out.print ("Enter three numbers: ");
      num1 = scan.nextInt();
      num2 = scan.nextInt();
      num3 = scan.nextInt();

      average = (double) (num1+num2+num3) / 3;

      System.out.println ("The average is: " + average);
   }
}
