//********************************************************************
//  DealCards.java       Author: Lewis and Loftus
//
//  Solution to Programming Project 5.41 (5E, p. 291)
//********************************************************************

public class DealCards
{
   //-----------------------------------------------------------------
   //  Creates and prints a random set of playing cards.
   //-----------------------------------------------------------------
   public static void main (String[] args)
   {
      final int NUM_CARDS = 5;
      Card card;

      for (int count=1; count <= NUM_CARDS; count++)
      {
         card = new Card();
         System.out.println (card);
      }
   }
}
