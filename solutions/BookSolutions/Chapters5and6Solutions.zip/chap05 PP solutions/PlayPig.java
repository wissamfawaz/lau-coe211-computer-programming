//********************************************************************
//  PlayPig.java       Author: Lewis and Loftus
//
//  Solution to Programming Project 5.40 (5E, p. 290)
//********************************************************************

class PlayPig
{
   //-----------------------------------------------------------------
   //  Creates the Pig game object and plays the game.
   //-----------------------------------------------------------------
   public static void main (String[] args)
   {
      Pig game = new Pig (100);

      game.play();
   }
}
