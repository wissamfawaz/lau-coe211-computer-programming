//********************************************************************
//  CharTable.java       Author: Lewis and Loftus
//
//  Solution to Programming Project 5.14 (5E, p. 287)
//********************************************************************

public class CharTable
{
   //-----------------------------------------------------------------
   //  Prints a table of Unicode characters and their numeric values.
   //-----------------------------------------------------------------
   public static void main (String[] args)
   {
      final int MIN = 32, MAX = 126, PER_LINE = 5;
      int count = 0;

      for (int chValue = MIN; chValue <= MAX; chValue++)
      {
         System.out.print (chValue + "  " + (char)chValue + "\t");

         count++;
         if (count % PER_LINE == 0)
            System.out.println();
      }
   }
}
