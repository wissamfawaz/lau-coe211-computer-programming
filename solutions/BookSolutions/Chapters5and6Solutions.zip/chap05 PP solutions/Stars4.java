//********************************************************************
//  Stars4.java       Author: Lewis and Loftus
//
//  Solution to Programming Project 5.13c (5E, p. 286)
//********************************************************************

public class Stars4
{
   //-----------------------------------------------------------------
   //  Prints a triangle shape using asterisk (star) characters.
   //-----------------------------------------------------------------
   public static void main (String[] args)
   {
      final int LIMIT = 10;

      for (int row = 1; row <= LIMIT; row++)
      {
         for (int space = 1; space <= row-1; space++)
            System.out.print (" ");

         for (int star = 1; star <= LIMIT-row+1; star++)
            System.out.print ("*");

         System.out.println();
      }
   }
}
