//********************************************************************
//  Stars2.java       Author: Lewis and Loftus
//
//  Solution to Programming Project 5.13a (5E, p. 286)
//********************************************************************

public class Stars2
{
   //-----------------------------------------------------------------
   //  Prints a triangle shape using asterisk (star) characters.
   //-----------------------------------------------------------------
   public static void main (String[] args)
   {
      final int LIMIT = 10;

      for (int row = 1; row <= LIMIT; row++)
      {
         for (int star = 1; star <= LIMIT-row+1; star++)
            System.out.print ("*");

         System.out.println();
      }
   }
}
