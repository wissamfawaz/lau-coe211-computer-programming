//********************************************************************
//  StringDown.java       Author: Lewis and Loftus
//
//  Solution to Programming Project 5.4 (5E, p. 285)
//********************************************************************

import java.util.Scanner;

public class StringDown
{
   //-----------------------------------------------------------------
   //  Reads a string from the user and prints it one character
   //  per line.
   //-----------------------------------------------------------------
   public static void main (String[] args)
   {
      String str;

	  Scanner scan = new Scanner(System.in);

      System.out.println ("Enter a string of characters:");
	  str = scan.nextLine();

      for (int index=0; index < str.length(); index++)
         System.out.println (str.charAt(index));
   }
}
