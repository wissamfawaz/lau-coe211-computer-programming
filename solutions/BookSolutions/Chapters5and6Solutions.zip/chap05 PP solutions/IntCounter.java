//********************************************************************
//  IntCounter.java                            Author: Lewis/Loftus
//
//  Solution to Programming Project 5.19 (5E, p. 288)
//********************************************************************

import java.io.*;
import java.util.Scanner;

public class IntCounter
{
   //-----------------------------------------------------------------
   //  Counts the number of integers read from a text file and then
   //  prints a table of the integers and a total count of integers
   //  found in the file.
   //-----------------------------------------------------------------
	public static void main (String[] args)
	{
		int count = 0;

		try
		{
			Scanner input = new Scanner(new File("input.txt"));
			System.out.println ();
			System.out.println ("Integers found: ");

			while (input.hasNextInt())
			{
				System.out.print (input.nextInt() + " ");
				count++;
			}
			System.out.println ();
			System.out.println ();
			System.out.println (count + " total integers found.");
		}
		catch (FileNotFoundException exception)
		{
			System.out.println ("The input file was not found!");
		}
		catch (IOException exception)
		{
			System.out.println (exception);
		}
	}
}
