//********************************************************************
//  MultTable.java       Author: Lewis and Loftus
//
//  Solution to Programming Project 5.6 (5E, p. 285)
//********************************************************************

public class MultTable
{
   //-----------------------------------------------------------------
   //  Prints a multiplication table.
   //-----------------------------------------------------------------
   public static void main (String[] args)
   {
      final int MAX = 12;

      for (int row = 1; row <= MAX; row++)
      {
         for (int column = 1; column <= MAX; column++)
            System.out.print (row*column + "\t");

         System.out.println();
      }
   }
}
