//********************************************************************
//  StyleOptions2.java       Author: Lewis and Loftus
//
//  Solution to Programming Project 5.35 (5E, p. 289)
//********************************************************************

import javax.swing.*;

public class StyleOptions2
{
   //-----------------------------------------------------------------
   //  Creates and presents the program frame.
   //-----------------------------------------------------------------
   public static void main (String[] args)
   {
      JFrame styleFrame = new JFrame ("Style Options");
      styleFrame.setDefaultCloseOperation (JFrame.EXIT_ON_CLOSE);

      StyleGUI2 gui = new StyleGUI2();
      styleFrame.getContentPane().add (gui.getPanel());

      styleFrame.pack();
      styleFrame.setVisible(true);
   }
}
