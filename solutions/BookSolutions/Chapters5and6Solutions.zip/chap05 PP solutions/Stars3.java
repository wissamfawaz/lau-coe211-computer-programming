//********************************************************************
//  Stars3.java       Author: Lewis and Loftus
//
//  Solution to Programming Project 5.13b (5E, p. 286)
//********************************************************************

public class Stars3
{
   //-----------------------------------------------------------------
   //  Prints a triangle shape using asterisk (star) characters.
   //-----------------------------------------------------------------
   public static void main (String[] args)
   {
      final int LIMIT = 10;

      for (int row = 1; row <= LIMIT; row++)
      {
         for (int space = 1; space <= LIMIT-row; space++)
            System.out.print (" ");

         for (int star = 1; star <= row; star++)
            System.out.print ("*");

         System.out.println();
      }
   }
}
