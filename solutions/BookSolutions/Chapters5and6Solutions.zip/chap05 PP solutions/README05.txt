This folder contains solutions to the Programming Projects from
Chapter 5 of Java Software Solutions, 5th Ed, by Lewis and Loftus.

Project     File(s)
-------     -------

5.1         LeapYear.java

5.2         LeapYear2.java

5.3         SumEvens.java

5.4         StringDown.java

5.5         CountDigits.java

5.6         MultTable.java

5.7         TravelingSong.java

5.8         HiLo.java

5.9         PalindromeTester2.java

5.10        BoxCars.java
            PairOfDice.java

5.11        CountFlips.java
            Coin.java

5.12        FlipRace.java
            Coin.java

5.13        Stars2.java  (part a)
            Stars3.java  (part b)
            Stars4.java  (part c)
            Stars5.java  (part d)

5.14        CharTable.java

5.15        Vowels.java

5.16        RockPaperScissors.java

5.17        TwelveDays.java

5.18        SimpleSlot.java

5.19        IntCounter.java

5.20        ParallelLines.java
            ParallelLines.html

5.21        StairSteps.java
            StairSteps.html

5.22        ColoredCircles.java
            ColoredCircles.html

5.23        ConcentricCircles.java
            ConcentricCircles.html

5.24        BrickWall.java
            BrickWall.html

5.25        not provided

5.26        Quilt2.java
            Pattern.java
            Quilt2.html

5.27        Fence.java
            Fence.html

5.28        Rainbow.java
            Rainbow.html

5.29        Points.java
            Points.html

5.30        LargestCircle.java
            LargestCircle.html

5.31        SumProduct.java

5.32		not provided

5.33		not provided

5.34		not provided

5.35        StyleOptions2.java
            StyleGUI2.java

5.36        GolfScores.java
            golf.dat

5.37        FileContrast.java
            contrast1.dat
            contrast2.dat

5.38        not provided

5.39        not provided

5.40        PlayPig.java
            Pig.java
            PigPlayer.java
            PairOfDice.java
            Die.java

5.41        DealCards.java
            Card.java









