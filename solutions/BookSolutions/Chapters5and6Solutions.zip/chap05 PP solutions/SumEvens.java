//********************************************************************
//  SumEvens.java       Author: Lewis and Loftus
//
//  Solution to Programming Project 5.3 (5E, p. 285)
//********************************************************************

import java.util.Scanner;

public class SumEvens
{
   //-----------------------------------------------------------------
   //  Computes and prints the sum of the even values between 2 and
   //  a positive value entered by the user.
   //-----------------------------------------------------------------
   public static void main (String[] args)
   {
      int sum = 0, value;

	  Scanner scan = new Scanner(System.in);

      System.out.print ("Enter a positive integer: ");
      value = scan.nextInt();

      if (value < 2)
         System.out.println ("The value must be greater than two.");
      else
      {
         for (int count = 2; count <= value; count+=2)
            sum += count;

         System.out.println ("The sum of the even integers from 2 to "
                             + value + " is " + sum);
      }
   }
}
