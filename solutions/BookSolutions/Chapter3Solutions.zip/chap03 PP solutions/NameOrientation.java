//********************************************************************
//  NameOrientation.java       Author: Lewis/Loftus
//
//  Solution to Programming Project 3.7 (5th Ed, p. 154)
//********************************************************************

import java.awt.*;
import javax.swing.*;

public class NameOrientation
{
   //-----------------------------------------------------------------
   //  Displays a name such that the orientation of the first and
   //  last names change with the size of the window.
   //-----------------------------------------------------------------
   public static void main (String[] args)
   {
      JFrame frame = new JFrame ("Name Orientation");
      frame.setDefaultCloseOperation (JFrame.EXIT_ON_CLOSE);

      ImageIcon icon = new ImageIcon ("devil.gif");

      JPanel primary = new JPanel();
      primary.setBackground (Color.cyan);
      primary.setPreferredSize (new Dimension(200, 50));

      JLabel firstName = new JLabel ("Elizabeth");
      JLabel lastName = new JLabel ("Montgomery");

      primary.add (firstName);
      primary.add (lastName);

      frame.getContentPane().add(primary);
      frame.pack();
      frame.setVisible(true);
   }
}
