//********************************************************************
//  DistanceCalculation.java       Author: Lewis and Loftus
//
//  Solution to Programming Project 3.4 (5th Ed, p. 153)
//********************************************************************

import java.util.Scanner;

public class DistanceCalculation
{
   //-----------------------------------------------------------------
   //  Computes the distance between two points using the distance
   //  formula.
   //-----------------------------------------------------------------
   public static void main (String[] args)
   {
      int x1, y1, x2, y2;
      double distance;
	  Scanner scan = new Scanner(System.in);

      System.out.println ("Enter the first coordinate values:");
      x1 = scan.nextInt();
      y1 = scan.nextInt();

      System.out.println ("Enter the second coordinate values:");
      x2 = scan.nextInt();
      y2 = scan.nextInt();

      distance = Math.sqrt( Math.pow(x2-x1, 2) + Math.pow(y2-y1, 2) );

      System.out.println ("The distance between (" + x1 + "," + y1 +
                 ") and (" + x2 + "," + y2 + ") is " + distance);
   }
}
