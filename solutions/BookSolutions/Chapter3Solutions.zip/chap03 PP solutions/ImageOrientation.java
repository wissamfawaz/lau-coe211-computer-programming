//********************************************************************
//  ImageOrientation.java       Author: Lewis/Loftus
//
//  Solution to Programming Project 3.8 (5th Ed, p. 154)
//********************************************************************

import java.awt.*;
import javax.swing.*;

public class ImageOrientation
{
   //-----------------------------------------------------------------
   //  Displays images in panels with various constraints.
   //-----------------------------------------------------------------
   public static void main (String[] args)
   {
      JFrame frame = new JFrame ("Image Orientation");
      frame.setDefaultCloseOperation (JFrame.EXIT_ON_CLOSE);

      JLabel label1 = new JLabel (new ImageIcon ("books.jpg"));
      JLabel label2 = new JLabel (new ImageIcon ("lightbulb.jpg"));
      JLabel label3 = new JLabel (new ImageIcon ("couple.jpg"));
      JLabel label4 = new JLabel (new ImageIcon ("dog.jpg"));

      JPanel panel1 = new JPanel();
      panel1.setBackground (Color.green);
      panel1.setMinimumSize (new Dimension(300, 300));
      panel1.add (label1);
      panel1.add (label2);

      JPanel panel2 = new JPanel();
      panel2.setBackground (Color.yellow);
      panel2.add (label3);
      panel2.add (label4);

      JPanel primary = new JPanel();
      primary.setBackground (Color.cyan);
      primary.add (panel1);
      primary.add (panel2);

      frame.getContentPane().add(primary);
      frame.pack();
      frame.setVisible(true);
   }
}
