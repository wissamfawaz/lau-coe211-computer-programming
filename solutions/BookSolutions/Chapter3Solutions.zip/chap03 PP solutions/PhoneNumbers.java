//********************************************************************
//  PhoneNumbers.java       Author: Lewis and Loftus
//
//  Solution to Programming Project 3.3 (5th Ed, p. 153)
//********************************************************************

import java.util.Random;

public class PhoneNumbers
{
   //-----------------------------------------------------------------
   //  Produces a random phone number with various constraints.
   //-----------------------------------------------------------------
   public static void main (String[] args)
   {
      String result = "";

      Random rand = new Random();

      // none of the first three digits is higher than 7
      result += rand.nextInt(8);
      result += rand.nextInt(8);
      result += rand.nextInt(8);

      result += "-";

      // the next set of digits cannot be greater than 742
      result += rand.nextInt(643) + 100;

      result += "-";

      result += rand.nextInt(9000) + 1000;

      System.out.println ("A random phone number: " + result);
   }
}
