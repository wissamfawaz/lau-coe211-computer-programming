//********************************************************************
//  SphereCalculations.java       Author: Lewis and Loftus
//
//  Solution to Programming Project 3.5 (5th Ed, p. 154)
//********************************************************************

import java.util.Scanner;
import java.text.DecimalFormat;

public class SphereCalculations
{
   //-----------------------------------------------------------------
   //  Computes the volume and surface area of a sphere given its
   //  radius.
   //-----------------------------------------------------------------
   public static void main (String[] args)
   {
      double radius, area, volume;
	  Scanner scan = new Scanner(System.in);

      System.out.print ("Enter the sphere's radius: ");
      radius = scan.nextDouble();

      volume = 4.0 / 3.0 * Math.PI * Math.pow(radius, 3);
      area = 4 * Math.PI * Math.pow(radius, 2);

      DecimalFormat fmt = new DecimalFormat ("0.####");
      System.out.println ("Volume: " + fmt.format(volume));
      System.out.println ("Surface area: " + fmt.format(area));
   }
}
