This folder contains solutions to the Programming Projects from
Chapter 3 of Java Software Solutions, 5th Ed, by Lewis and Loftus.

Project     File(s)
-------     -------

3.1         UsernameGenerator.java

3.2         SumOfCubes.java

3.3         PhoneNumbers.java

3.4         DistanceCalculation.java

3.5         SphereCalculations.java

3.6         TriangleArea.java

3.7         NameOrientation.java

3.8         ImageOrientation.java
            books.jpg
            lightbulb.jpg
            couple.jpg
            dog.jpg

3.9         LabelDemo2.java
            devil.gif

