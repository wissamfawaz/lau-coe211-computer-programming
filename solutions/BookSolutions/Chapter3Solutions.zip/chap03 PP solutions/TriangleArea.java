//********************************************************************
//  TriangleArea.java       Author: Lewis and Loftus
//
//  Solution to Programming Project 3.6 (5th Ed, p. 154)
//********************************************************************

import java.util.Scanner;
import java.text.DecimalFormat;

public class TriangleArea
{
   //-----------------------------------------------------------------
   //  Computes the area of a triangle given the length of each
   //  side. Uses Heron's formula.
   //-----------------------------------------------------------------
   public static void main (String[] args)
   {
      double side1, side2, side3, s, area;
	  Scanner scan = new Scanner(System.in);

      System.out.print ("Enter the length of side 1: ");
      side1 = scan.nextDouble();
      System.out.print ("Enter the length of side 2: ");
      side2 = scan.nextDouble();
      System.out.print ("Enter the length of side 3: ");
      side3 = scan.nextDouble();

      s = (side1 + side2 + side3) / 2;  // half of the perimeter
      area = Math.sqrt (s * (s-side1) * (s-side2) * (s-side3));

      DecimalFormat fmt = new DecimalFormat ("0.###");
      System.out.println ("Area: " + fmt.format(area));
   }
}
