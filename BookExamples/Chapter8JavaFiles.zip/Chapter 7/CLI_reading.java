
/* This program demonstrates another use of wrapper  *
 * classes                                           **/




public class CLI_reading {

		
		
	public static void main (String[] args) {
		
		
		
		float division;		
		int first_reading, second_reading;
	
		first_reading = Integer.parseInt (args[0]);
		second_reading = Integer.parseInt (args[1]);
		division = first_reading / second_reading;
				
		System.out.println("dividing " + first_reading + 
				   " by " + second_reading + " results in " +
				    division);		
		
	}
}


