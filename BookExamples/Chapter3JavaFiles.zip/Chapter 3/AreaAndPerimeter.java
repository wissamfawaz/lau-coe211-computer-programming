import javax.swing.JOptionPane;

public class AreaAndPerimeter {

	public static void main(String[] args) {

		double radius, area, perimeter;
		String radiusString, outputStr;
		
		// display the input dialog box with the specified message
		radiusString = JOptionPane.showInputDialog("Enter the radius");
		radius = Double.parseDouble(radiusString);


		area = Math.PI * radius * radius; 
		perimeter = 2 * Math.PI * radius;

		// construct the string containing radius, area, and perimeter of circle
		outputStr = "Radius: "+radius+"\n" 
			    + "Area: "+ area + " square units\n"
			    + "Perimeter: "+perimeter+" units";

		// Use a message dialog box to display radius, area, and perimeter

		JOptionPane.showMessageDialog(null, outputStr, "Circle", 
					      JOptionPane.INFORMATION_MESSAGE)
		
		System.exit(0); // terminates the program after the user clicks OK button

	}

}