public class Support {
	public int power (int a, int b) {
		int count=0, res=1;

		while (count < b) {
			res *= a;
			count++;
		}

		return res;

	}
}		

		