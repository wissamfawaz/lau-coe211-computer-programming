
/* This program demonstrates the use of the remaining methods   *
 * of the String class                                          **/


public class String_methods {


	public static void main (String[] args) {

		String S = "hi there";
		String S1 = "Hi There";
		
		char c;
		
		// Returns the character at the specified index (0)
		
		c = S.charAt(0);
		System.out.println("The first character of S is : " + c);
		
		// compare the strings S and S1
		
		if(S.equals(S1))
			System.out.println("S is equal to S1");
		else 
			System.out.println("S is not equal to S1");
		
		if(S.equalsIgnoreCase(S1))
			System.out.println("Ignoring case, S is equal to S1");


	}
}


