
/* This program demonstrates the use of the import   *
 * declaration                                       **/

import java.util.Scanner;

public class Import_declaration {


	public static void main (String[] args) {

		Scanner scan = new Scanner(System.in);
		int value;
		
		System.out.println("Enter an int: ");
		value = scan.nextInt();

		System.out.println("you have entered: " + value);
		


	}
}


