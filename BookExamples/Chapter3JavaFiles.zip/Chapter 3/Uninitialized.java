
/* This program demonstrates the concept of un-  *
 * initialized variables.                        **/



import java.util.Scanner;

public class Uninitialized {



	public static void main (String[] args) {

		int num;
		Scanner scan;
		
		System.out.println("value of num = " + num);
		System.out.println("value of scan = " + scan);
		
	}

}