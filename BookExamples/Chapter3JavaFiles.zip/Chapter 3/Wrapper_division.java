
/* This program demonstrates the use of wrapper classes         *
 * methods		                                        **/




public class Wrapper_division {

		
		
	public static void main (String[] args) {

		Integer intObj1 = new Integer(1);
		Integer intObj2 = new Integer (2);
		
		float division_result;
	
		String str = "ab";
		int str_int;


		division_result = intObj1.intValue() / intObj2.intValue();
		System.out.println("result of int division = " + division_result);

		division_result = intObj1.floatValue() / intObj2.floatValue();
		System.out.println("result of float division = " + division_result);
		
		str_int = Integer.parseInt(str);
		str_int++;

		System.out.println("str_int after increment = " + str_int);				

		System.out.println("value stored in intObj1 = " + intObj1);		
		
	}
}


