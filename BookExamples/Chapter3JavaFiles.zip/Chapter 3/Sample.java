public class Sample {
	public static void main(String[]  args) {
		int a = 2, b = 3;
		int result;

		Support c = new Support();
		result = c.power(2, 3);

		System.out.println("result = "+result);
	}

}