
/* This program demonstrates the use of length   *
 * method of a string object.                    **/



public class Word_length {

	// determine and return the length of a string

	public static void main (String[] args) {

		int str_length;
		String name;

		name = new String("James Bond");
		str_length = name.length();
		
		System.out.println("value of length = " + str_length);
		System.out.println("where name = " + name.toString());
		
		
	}

}