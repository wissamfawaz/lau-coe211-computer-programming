
/* This program demonstrates the use of a user-defined  *
 * class		                                **/


public class RollingDice {

	//-----------------------------------------------
	// Creates two Die objects and rolls them several
	// times.
	//-----------------------------------------------		
		
	public static void main (String[] args) {
		
		Die die1, die2;
		
		die1 = new Die();
		die2 = (Die) die1.clone();

		die2.setFaceValue(5);
		
		System.out.println(die1.getFaceValue());
		
	}
}


