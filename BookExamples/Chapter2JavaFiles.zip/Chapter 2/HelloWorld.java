

public class HelloWorld extends java.applet.Applet {

	public void paint(java.awt.Graphics g) { // g represents the entire applet window
		
		g.drawString("Hello World!", 50, 25);
		System.out.println("Hello World!");		

	}

}