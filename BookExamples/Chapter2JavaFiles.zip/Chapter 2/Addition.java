//********************************************************************
//  Addition.java       Author: Lewis/Loftus
//
//  Demonstrates the difference between the addition and string
//  concatenation operators.
//********************************************************************

public class Addition { 
	public static void main (String[] args){
      System.out.println ("24 and 45 concatenated:" + "24" + "\t" + 45);

      System.out.println ("24 and 45 added : " + (24 + 45));
   }
}
