//********************************************************************
//  PianoKeys.java       Author: Lewis/Loftus
//
//  Demonstrates the declaration, initialization, and use of an
//  integer variable.
//********************************************************************

public class PianoKeys
{
   //-----------------------------------------------------------------
   //  Prints the number of keys on a piano.
   //-----------------------------------------------------------------
   public static void main (String[] args)
   {
      int keys = "a";
      int a;
      a = 2;
      

      System.out.println ("A piano has " + keys + " keys.");
      System.out.println("The current value of a is " + a);

      keys = 89;

      System.out.println("the current value of keys " + keys);

      keys = a * 9;

      System.out.println("the current value of keys " + keys);
   }
}
